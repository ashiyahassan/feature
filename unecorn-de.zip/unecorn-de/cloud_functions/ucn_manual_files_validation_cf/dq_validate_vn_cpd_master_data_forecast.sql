CREATE OR REPLACE TABLE {} AS 

SELECT * FROM (
    SELECT 
        *,

        (CASE WHEN ean IS NULL OR ean='nan' THEN 1 ELSE 0 END) +
        (CASE WHEN LENGTH(ean) > 13 THEN 1 ELSE 0 END) +
        (CASE WHEN signature IS NULL OR signature='nan' THEN 1 ELSE 0 END) +
        (CASE WHEN brand IS NULL OR brand='nan' THEN 1 ELSE 0 END) +
        (CASE WHEN unecorn_lzd_status IS NULL OR unecorn_lzd_status='nan' THEN 1 ELSE 0 END) +
        (CASE WHEN unecorn_shp_status IS NULL OR unecorn_shp_status='nan' THEN 1 ELSE 0 END) +
        (CASE WHEN unecorn_tiktok_status IS NULL OR unecorn_tiktok_status='nan' THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(lzd_status) NOT IN ('DC', 'NEW LAUNCH', 'FUTURE LAUNCH', 'NOT IN CATALOGUE', 'ON GOING', 'TBDC') THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(shp_status) NOT IN ('DC', 'NEW LAUNCH', 'FUTURE LAUNCH', 'NOT IN CATALOGUE', 'ON GOING', 'TBDC') THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(tiktok_status) NOT IN ('DC', 'NEW LAUNCH', 'FUTURE LAUNCH', 'NOT IN CATALOGUE', 'ON GOING', 'TBDC') THEN 1 ELSE 0 END) +
        
        (CASE WHEN UPPER(shp_status) = 'FUTURE LAUNCH' AND PARSE_DATE('%Y-%m', shp_launch_month) <= DATE_TRUNC(CURRENT_DATE(), MONTH) THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(shp_status) = 'NEW LAUNCH' AND PARSE_DATE('%Y-%m', shp_launch_month) > DATE_TRUNC(CURRENT_DATE(), MONTH) THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(shp_status) = 'DC' AND PARSE_DATE('%Y-%m', shp_dc_month) >= DATE_TRUNC(CURRENT_DATE(), MONTH) THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(shp_status) = 'TBDC' AND PARSE_DATE('%Y-%m', shp_dc_month) < DATE_TRUNC(CURRENT_DATE(), MONTH) THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(shp_status) = 'ON GOING' AND shp_launch_month <> 'nan' AND shp_dc_month <> 'nan'  THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(shp_status) = 'NOT IN CATALOGUE' AND shp_launch_month <> 'nan' AND shp_dc_month <> 'nan'  THEN 1 ELSE 0 END) +

        (CASE WHEN UPPER(tiktok_status) = 'FUTURE LAUNCH' AND PARSE_DATE('%Y-%m', tiktok_launch_month) <= DATE_TRUNC(CURRENT_DATE(), MONTH) THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(tiktok_status) = 'NEW LAUNCH' AND PARSE_DATE('%Y-%m', tiktok_launch_month) > DATE_TRUNC(CURRENT_DATE(), MONTH) THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(tiktok_status) = 'DC' AND PARSE_DATE('%Y-%m', tiktok_dc_month) >= DATE_TRUNC(CURRENT_DATE(), MONTH) THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(tiktok_status) = 'TBDC' AND PARSE_DATE('%Y-%m', tiktok_dc_month) < DATE_TRUNC(CURRENT_DATE(), MONTH) THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(tiktok_status) = 'ON GOING' AND tiktok_launch_month <> 'nan' AND tiktok_dc_month <> 'nan'  THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(tiktok_status) = 'NOT IN CATALOGUE' AND tiktok_launch_month <> 'nan' AND tiktok_dc_month <> 'nan'  THEN 1 ELSE 0 END) +
        


        (CASE WHEN UPPER(lzd_status) = 'FUTURE LAUNCH' AND PARSE_DATE('%Y-%m', lzd_launch_month) <= DATE_TRUNC(CURRENT_DATE(), MONTH) THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(lzd_status) = 'NEW LAUNCH' AND PARSE_DATE('%Y-%m', lzd_launch_month) > DATE_TRUNC(CURRENT_DATE(), MONTH) THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(lzd_status) = 'DC' AND PARSE_DATE('%Y-%m', lzd_dc_month) >= DATE_TRUNC(CURRENT_DATE(), MONTH) THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(lzd_status) = 'TBDC' AND PARSE_DATE('%Y-%m', lzd_dc_month) < DATE_TRUNC(CURRENT_DATE(), MONTH) THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(lzd_status) = 'ON GOING' AND lzd_launch_month <> 'nan' AND lzd_dc_month <> 'nan' THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(lzd_status) = 'NOT IN CATALOGUE' AND lzd_launch_month <> 'nan' AND lzd_dc_month <> 'nan' THEN 1 ELSE 0 END) +
        

        (CASE WHEN UPPER(shp_status) = 'DC' AND unecorn_shp_status != 'Inactive' THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(shp_status) = 'FUTURE LAUNCH' AND unecorn_shp_status != 'Active' THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(shp_status) = 'NEW LAUNCH' AND unecorn_shp_status != 'Active' THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(shp_status) = 'TBDC' AND unecorn_shp_status != 'Active' THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(shp_status) = 'ON GOING' AND unecorn_shp_status != 'Active' THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(shp_status) = 'NOT IN CATALOGUE' AND unecorn_shp_status != 'Inactive' THEN 1 ELSE 0 END) +

        (CASE WHEN UPPER(tiktok_status) = 'DC' AND unecorn_tiktok_status != 'Inactive' THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(tiktok_status) = 'FUTURE LAUNCH' AND unecorn_tiktok_status != 'Active' THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(tiktok_status) = 'NEW LAUNCH' AND unecorn_tiktok_status != 'Active' THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(tiktok_status) = 'TBDC' AND unecorn_tiktok_status != 'Active' THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(tiktok_status) = 'ON GOING' AND unecorn_tiktok_status != 'Active' THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(tiktok_status) = 'NOT IN CATALOGUE' AND unecorn_tiktok_status != 'Inactive' THEN 1 ELSE 0 END) +
        

        
        (CASE WHEN UPPER(lzd_status) = 'DC' AND unecorn_lzd_status != 'Inactive' THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(lzd_status) = 'TBDC' AND unecorn_lzd_status != 'Active' THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(lzd_status) = 'NEW LAUNCH' AND unecorn_lzd_status != 'Active' THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(lzd_status) = 'NOT IN CATALOGUE' AND unecorn_lzd_status != 'Inactive' THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(lzd_status) = 'ON GOING' AND unecorn_lzd_status != 'Active' THEN 1 ELSE 0 END) +
        (CASE WHEN UPPER(lzd_status) = 'FUTURE LAUNCH' AND unecorn_lzd_status != 'Active' THEN 1 ELSE 0 END) AS number_of_errors,





                (CASE WHEN ean IS NULL OR ean='nan' THEN 'column ean : ean in  is null;' ELSE '' END) ||
        (CASE WHEN LENGTH(ean) > 13 THEN 'column ean : ean character limit more than 13 in ;' ELSE '' END) ||
        (CASE WHEN signature IS NULL OR signature='nan' THEN 'column signature : signature is null;' ELSE '' END) ||
        (CASE WHEN brand IS NULL  OR brand='nan' THEN 'brand is null;' ELSE '' END) ||
        (CASE WHEN unecorn_lzd_status IS NULL OR unecorn_lzd_status='nan' THEN 'column ununecorn_lzd_status : ununecorn_lzd_status is null;' ELSE '' END) ||
        (CASE WHEN unecorn_shp_status IS NULL OR unecorn_shp_status='nan' THEN 'column unecorn_shp_status : unecorn_shp_status is null;' ELSE '' END) ||
        (CASE WHEN unecorn_tiktok_status IS NULL OR unecorn_tiktok_status='nan' THEN 'column unecorn_tiktok_status : unecorn_tiktok_status is null;' ELSE '' END) ||
        (CASE WHEN UPPER(lzd_status) NOT IN ('DC', 'NEW LAUNCH', 'FUTURE LAUNCH', 'ON GOING', 'TBDC', 'NOT IN CATALOGUE') THEN 'column lzd_status : Invalid values ;' ELSE '' END) ||
        (CASE WHEN UPPER(shp_status) NOT IN ('DC', 'NEW LAUNCH', 'FUTURE LAUNCH', 'ON GOING', 'TBDC', 'NOT IN CATALOGUE') THEN 'column shp_status :  Invalid values ;' ELSE '' END) ||
        (CASE WHEN UPPER(tiktok_status) NOT IN ('DC', 'NEW LAUNCH', 'FUTURE LAUNCH', 'ON GOING', 'TBDC', 'NOT IN CATALOGUE') THEN 'column tiktok_status :  Invalid values ;' ELSE '' END) ||
        
        (CASE WHEN UPPER(shp_status) = 'FUTURE LAUNCH' AND PARSE_DATE('%Y-%m', shp_dc_month) <= CURRENT_DATE() THEN 'column shp_status : Invalid shp_launch_date for Future Launch status ;' ELSE '' END) ||
        (CASE WHEN UPPER(shp_status) = 'ON GOING' AND shp_launch_month <> 'nan' AND shp_dc_month <> 'nan' THEN 'column shp_status : Invalid shp_launch_date and  shp_dc_month for On Going status ;' ELSE '' END) ||
        (CASE WHEN UPPER(lzd_status) = 'ON GOING' AND lzd_launch_month <> 'nan' AND lzd_dc_month <> 'nan' THEN 'column lzd_status : Invalid lzd_launch_date and  lzd_dc_month for On Going status ;' ELSE '' END) ||
        (CASE WHEN UPPER(shp_status) = 'NOT IN CATALOGUE' AND shp_launch_month <> 'nan' AND shp_dc_month <> 'nan' THEN 'column shp_status : Invalid shp_launch_date and  shp_dc_month for Not In Catalogue status ;' ELSE '' END) ||
        (CASE WHEN UPPER(lzd_status) = 'NOT IN CATALOGUE' AND lzd_launch_month <> 'nan' AND lzd_dc_month <> 'nan' THEN 'column lzd_status : Invalid lzd_launch_date and  lzd_dc_month for Not In Catalogue status ;' ELSE '' END) ||
        (CASE WHEN UPPER(shp_status) = 'NEW LAUNCH' AND PARSE_DATE('%Y-%m', shp_dc_month) > CURRENT_DATE() THEN 'column shp_status : Invalid shp_launch_date  for New Launch status shp_status;' ELSE '' END) ||
        (CASE WHEN UPPER(shp_status) = 'DC' AND PARSE_DATE('%Y-%m', shp_dc_month) > CURRENT_DATE() THEN 'column shp_status : Invalid shp_dc_date for DC status shp_status;' ELSE '' END) ||
        (CASE WHEN UPPER(shp_status) = 'TBDC' AND PARSE_DATE('%Y-%m', shp_dc_month) < CURRENT_DATE() THEN 'column shp_status : Invalid shp_dc_date for TBDC status shp_status;' ELSE '' END) ||

        (CASE WHEN UPPER(tiktok_status) = 'FUTURE LAUNCH' AND PARSE_DATE('%Y-%m', tiktok_dc_month) <= CURRENT_DATE() THEN 'column tiktok_status : Invalid tiktok_launch_date for Future Launch status ;' ELSE '' END) ||
        (CASE WHEN UPPER(tiktok_status) = 'ON GOING' AND tiktok_launch_month <> 'nan' AND tiktok_dc_month <> 'nan' THEN 'column tiktok_status : Invalid tiktok_launch_date and  tiktok_dc_month for On Going status ;' ELSE '' END) ||
        (CASE WHEN UPPER(tiktok_status) = 'NOT IN CATALOGUE' AND tiktok_launch_month <> 'nan' AND tiktok_dc_month <> 'nan' THEN 'column tiktok_status : Invalid tiktok_launch_date and  tiktok_dc_month for Not In Catalogue status ;' ELSE '' END) ||
        (CASE WHEN UPPER(tiktok_status) = 'NEW LAUNCH' AND PARSE_DATE('%Y-%m', tiktok_dc_month) > CURRENT_DATE() THEN 'column tiktok_status : Invalid tiktok_launch_date  for New Launch status tiktok_status;' ELSE '' END) ||
        (CASE WHEN UPPER(tiktok_status) = 'DC' AND PARSE_DATE('%Y-%m', tiktok_dc_month) > CURRENT_DATE() THEN 'column tiktok_status : Invalid tiktok_dc_date for DC status tiktok_status;' ELSE '' END) ||
        (CASE WHEN UPPER(tiktok_status) = 'TBDC' AND PARSE_DATE('%Y-%m', tiktok_dc_month) < CURRENT_DATE() THEN 'column tiktok_status : Invalid tiktok_dc_date for TBDC status tiktok_status;' ELSE '' END) ||
        
        (CASE WHEN UPPER(lzd_status) = 'FUTURE LAUNCH' AND PARSE_DATE('%Y-%m', lzd_launch_month) <= CURRENT_DATE() THEN 'column lzd_status : Invalid Lzd_launch_date for Future Launch status  lzd_status;' ELSE '' END) ||
        (CASE WHEN UPPER(lzd_status) = 'NEW LAUNCH' AND PARSE_DATE('%Y-%m', lzd_launch_month) > CURRENT_DATE() THEN 'column lzd_status : Invalid Lzd_launch_date for New Launch status  lzd_status;' ELSE '' END) ||
        (CASE WHEN UPPER(lzd_status) = 'DC' AND PARSE_DATE('%Y-%m', lzd_dc_month) > CURRENT_DATE() THEN 'column lzd_status : Invalid Lzd_dc_date for DC status  lzd_status;' ELSE '' END) ||
        (CASE WHEN UPPER(lzd_status) = 'TBDC' AND PARSE_DATE('%Y-%m', lzd_dc_month) < CURRENT_DATE() THEN 'column lzd_status : Invalid Lzd_dc_date for TBDC status lzd_status;' ELSE '' END) ||
        
        
        (CASE WHEN UPPER(shp_status) = 'DC' AND unecorn_shp_status != 'Inactive' THEN 'column shp_status : Invalid unecorn_shp_status for DC shp_status;' ELSE '' END) ||
        (CASE WHEN UPPER(shp_status) = 'FUTURE LAUNCH' AND unecorn_shp_status != 'Active' THEN 'column shp_status : Invalid unecorn_shp_status for Future Launch shp_status;' ELSE '' END) ||
        (CASE WHEN UPPER(shp_status) = 'NEW LAUNCH' AND unecorn_shp_status != 'Active' THEN 'column shp_status : Invalid unecorn_shp_status for New Launch shp_status;' ELSE '' END) ||
        (CASE WHEN UPPER(shp_status) = 'TBDC' AND unecorn_shp_status != 'Active' THEN 'column shp_status : Invalid unecorn_shp_status for TBDC  shp_status;' ELSE '' END) ||
        (CASE WHEN UPPER(shp_status) = 'ON GOING' AND unecorn_shp_status != 'Active' THEN 'column shp_status : Invalid unecorn_shp_status for On Going shp_status;' ELSE '' END) ||
        (CASE WHEN UPPER(shp_status) = 'NOT IN CATALOGUE' AND unecorn_shp_status != 'Inactive' THEN 'column shp_status : Invalid unecorn_shp_status for Not In Catalogue shp_status;' ELSE '' END) ||

        (CASE WHEN UPPER(tiktok_status) = 'DC' AND unecorn_tiktok_status != 'Inactive' THEN 'column tiktok_status : Invalid unecorn_tiktok_status for DC tiktok_status;' ELSE '' END) ||
        (CASE WHEN UPPER(tiktok_status) = 'FUTURE LAUNCH' AND unecorn_tiktok_status != 'Active' THEN 'column tiktok_status : Invalid unecorn_tiktok_status for Future Launch tiktok_status;' ELSE '' END) ||
        (CASE WHEN UPPER(tiktok_status) = 'NEW LAUNCH' AND unecorn_tiktok_status != 'Active' THEN 'column tiktok_status : Invalid unecorn_tiktok_status for New Launch tiktok_status;' ELSE '' END) ||
        (CASE WHEN UPPER(tiktok_status) = 'TBDC' AND unecorn_tiktok_status != 'Active' THEN 'column tiktok_status : Invalid unecorn_tiktok_status for TBDC  tiktok_status;' ELSE '' END) ||
        (CASE WHEN UPPER(tiktok_status) = 'ON GOING' AND unecorn_tiktok_status != 'Active' THEN 'column tiktok_status : Invalid unecorn_tiktok_status for On Going tiktok_status;' ELSE '' END) ||
        (CASE WHEN UPPER(tiktok_status) = 'NOT IN CATALOGUE' AND unecorn_tiktok_status != 'Inactive' THEN 'column tiktok_status : Invalid unecorn_tiktok_status for Not In Catalogue tiktok_status;' ELSE '' END) ||
        
        (CASE WHEN UPPER(lzd_status) = 'DC' AND unecorn_lzd_status != 'Inactive' THEN 'column lzd_status : Invalid unecorn_lzd_status for DC lzd_status;' ELSE '' END) ||
        (CASE WHEN UPPER(lzd_status) = 'TBDC' AND unecorn_lzd_status != 'Active' THEN 'column lzd_status : Invalid unecorn_lzd_status for TBDC lzd_status;' ELSE '' END) ||
        (CASE WHEN UPPER(lzd_status) = 'ON GOING' AND unecorn_lzd_status != 'Active' THEN 'column lzd_status : Invalid unecorn_lzd_status for On Going lzd_status;' ELSE '' END) ||
        (CASE WHEN UPPER(lzd_status) = 'NEW LAUNCH' AND unecorn_lzd_status != 'Active' THEN 'column lzd_status : Invalid unecorn_lzd_status for New Launch lzd_status;' ELSE '' END) ||
        (CASE WHEN UPPER(lzd_status) = 'NOT IN CATALOGUE' AND unecorn_lzd_status != 'Inactive' THEN 'column lzd_status : Invalid unecorn_lzd_status for Not In Catalogue lzd_status;' ELSE '' END) ||
        (CASE WHEN UPPER(lzd_status) = 'FUTURE LAUNCH' AND unecorn_lzd_status != 'Active' THEN 'column lzd_status : Invalid unecorn_lzd_status for Future Launch lzd_status;' ELSE '' END) AS dq_rule,
        



    FROM 
    (SELECT 
 ean,
signature,
brand,
sub_brand,
category,
sub_category,
`group`,
sub_group,
hero,
bundle,
material_type,
material_des,
old_ean,
CASE
    WHEN UPPER(lzd_status) = "DC" THEN "DC"
    WHEN UPPER(lzd_status) = "NEW LAUNCH" THEN "New Launch"
    WHEN UPPER(lzd_status) = "FUTURE LAUNCH" THEN "Future Launch"
    WHEN UPPER(lzd_status) = "NOT IN CATALOGUE" THEN "Not In Catalogue"
    WHEN UPPER(lzd_status) = "ON GOING" THEN "On Going"
    WHEN UPPER(lzd_status) = "TBDC" THEN "TBDC"
    ELSE ""
END AS lzd_status,
CASE WHEN lzd_launch_month = 'nan' THEN null ELSE lzd_launch_month END as lzd_launch_month,
CASE WHEN lzd_dc_month = 'nan' THEN null ELSE lzd_dc_month END as lzd_dc_month,
CASE
    WHEN UPPER(shp_status) = "DC" THEN "DC"
    WHEN UPPER(shp_status) = "NEW LAUNCH" THEN "New Launch"
    WHEN UPPER(shp_status) = "FUTURE LAUNCH" THEN "Future Launch"
    WHEN UPPER(shp_status) = "NOT IN CATALOGUE" THEN "Not In Catalogue"
    WHEN UPPER(shp_status) = "ON GOING" THEN "On Going"
    WHEN UPPER(shp_status) = "TBDC" THEN "TBDC"
    ELSE ""
END AS shp_status,
CASE WHEN shp_launch_month = 'nan' THEN null ELSE shp_launch_month END as shp_launch_month,
CASE WHEN shp_dc_month = 'nan' THEN null ELSE shp_dc_month END as shp_dc_month,
CASE
    WHEN UPPER(tiktok_status) = "DC" THEN "DC"
    WHEN UPPER(tiktok_status) = "NEW LAUNCH" THEN "New Launch"
    WHEN UPPER(tiktok_status) = "FUTURE LAUNCH" THEN "Future Launch"
    WHEN UPPER(tiktok_status) = "NOT IN CATALOGUE" THEN "Not In Catalogue"
    WHEN UPPER(tiktok_status) = "ON GOING" THEN "On Going"
    WHEN UPPER(tiktok_status) = "TBDC" THEN "TBDC"
    ELSE ""
END AS tiktok_status,
CASE WHEN tiktok_launch_month = 'nan' THEN null ELSE tiktok_launch_month END as tiktok_launch_month,
CASE WHEN tiktok_dc_month = 'nan' THEN null ELSE tiktok_dc_month END as tiktok_dc_month,
unecorn_shp_status,
unecorn_lzd_status,
unecorn_tiktok_status,
country_code,
created_date,
modified_date,
active_status,


FROM `{}`

)) 
WHERE number_of_errors <> 0 order by number_of_errors desc ;
