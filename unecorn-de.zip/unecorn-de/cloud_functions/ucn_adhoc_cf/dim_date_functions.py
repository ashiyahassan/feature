import pandas as pd
import calendar as cal
import datetime as dt
import math

def format_date(date):
    # Format the date as "dd-mmm-yy"
    formatted_date = date.strftime("%d-%b-%y")
    return formatted_date.upper()

def datekey(date):
    date_string = date.strftime("%Y%m%d")
    date_key = int(date_string)
    return int(date_key)

def start_of_year(date):
    current_year = date.year
    start_date = dt.date(current_year, 1, 1)
    return start_date

def end_of_year(date):
    current_year = date.year
    end_date = dt.date(current_year, 12, 31)
    return end_date

def start_of_month(date):
    current_year = date.year
    current_month = date.month
    start_date = dt.date(current_year, current_month, 1)
    return start_date

def end_of_month(date):
    current_year = date.year
    current_month = date.month
    num_days_in_month = cal.monthrange(current_year, current_month)[1]
    end_date = dt.date(current_year, current_month, num_days_in_month)
    return end_date

def days_in_month(date):
    year,month = date.year, date.month
    num_days = cal.monthrange(year, month)[1]
    return num_days

def day_name(date):
    day_name = date.strftime("%A")
    return day_name.capitalize()

def day_of_week(date):
    day_of_week = date.weekday()
    return day_of_week

def day_of_year(date):
    return date.timetuple().tm_yday

def calendar_month_name(date):
    return date.strftime("%B").capitalize()

def calendar_quarter(date):
    quarter = math.ceil(date.month / 3)
    return quarter

def start_of_quarter(date):
    current_year = date.year
    current_month = date.month
    quarter = (current_month - 1) // 3 + 1
    start_month = (quarter - 1) * 3 + 1
    start_date = dt.date(current_year, start_month, 1)
    return start_date

def end_of_quarter(date):
    # Get the current year and month
    current_year = date.year
    current_month = date.month
    quarter = (current_month - 1) // 3 + 1
    end_month = quarter * 3
    _, last_day = cal.monthrange(current_year, end_month)
    end_date = dt.date(current_year, end_month, last_day)
    return end_date

def calendar_year_quarter_number(date):
    year = date.year
    quarter = (date.month - 1) // 3 + 1
    year_quarter = str(year) + "Q" + str(quarter)
    return year_quarter

def Custom_Calendar_week(date):
    year_start = dt.date(current_date.year, 1, 1)
    year_end = dt.date(current_date.year, 12, 31)

    first_week_end = year_start + dt.timedelta(days=(6 - year_start.weekday()))
    last_week_start = year_end - dt.timedelta(days=year_end.weekday())
    
    # Handle December 30 and 31 as the last week of the current year (Week 53)
    if current_date <= first_week_end and current_date.month == 1:
        return 1
    elif current_date >= last_week_start and current_date.month == 12:
        if (last_week_start + dt.timedelta(days=6)).year > current_date.year:
            if (last_week_start - dt.timedelta(days=6)).isocalendar()[1] == 51:
                return 52  # Week 53 of the current year
            else:
                return 53  # Week 52 of the current year
    
    # Otherwise, calculate the standard ISO week number
    # Use the ISO calendar: current_date.isocalendar()[1] gives the ISO week number
    iso_week = current_date.isocalendar()[1]
    
    return iso_week

def week_number_in_year(date): # apply gregorgian calendar
    return Custom_Calendar_week(date)

def week_of_month(date):
    week_num = (date.day - 1) // 7 + 1
    return week_num

def start_of_week(date):
    # today = dt.date(2024,2,11)
    days_to_subtract = date.weekday() # 0 for Monday, 6 for Sunday
    start_date = date - dt.timedelta(days=days_to_subtract)
    return start_date

def calendar_week_ending_date(date):
    while date.weekday() != 5:
        date += dt.timedelta(days=1)
    return date

def end_of_week(date):
    start_of_next_week = start_of_week(date) + dt.timedelta(days=7)
    end_date = start_of_next_week - dt.timedelta(days=1)
    return end_date

def calendar_year_month(date):
    # Format the date as a string representing the year and month (mm yyyy)
    year_month_string = date.strftime("%b %Y")

    return year_month_string.capitalize()

def calendar_year_month_code(date):
    # Format the date as a string representing the year and month (YYYYMM)
    year_month_string = date.strftime("%Y%m")

    return int(year_month_string)

def calendar_week_number_in_year(date):
    week_number = Custom_Calendar_week(date) #int(date.strftime("%V"))
    return 'Week '+ str(week_number)

def calendar_month_short_name(date):
    short_month_name = date.strftime("%b")
    return short_month_name.capitalize()

def month_year_format(date):
    # Format the date as "Ex-Mon-YY"
    formatted_date = f"{date.strftime('%b-%y')}"

    return formatted_date.capitalize()

def day_short_name(date):
    short_day_name = date.strftime("%a")
    return short_day_name.capitalize()

def day_number_of_quarter(date):
    quarter = (date.month - 1) // 3 + 1
    quarter_start = dt.date(date.year, 3 * quarter - 2, 1)
    days_elapsed = (date - quarter_start).days + 1
    return days_elapsed

def weekday_indicator(date):
    day_of_week = date.weekday()
    if day_of_week < 5:
        return 'TRUE'
    else:
        return 'FALSE'

def sql_date_stamp(current_datetime):
    # current_datetime = dt.datetime.now()
    sql_date_stamp = current_datetime.strftime("%Y-%m-%d %H:%M:%S")

    return sql_date_stamp

def week_year_sort(date):
    iso_year, iso_week = date.year, Custom_Calendar_week(date) #date.isocalendar()
    iso_week_year = f"{iso_year}{iso_week:02}"

    return int(iso_week_year)

def week_year(date):
    # Format the date to get the ISO week number and year
    # week_number = int(date.strftime("%V"))
    # year = date.strftime("%Y")
    iso_year, iso_week = date.year, Custom_Calendar_week(date) #date.isocalendar()

    return f"Week {iso_week:02}, {iso_year}"

def month_year_fh(date):
    # Format the date to get the month number and year
    month_year = date.strftime("%m/%Y")

    return month_year

