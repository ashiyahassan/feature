{% macro delete_m0_old_version_data(dataset_name, table_name, base_table_name) %}

{% set project_id = target.project %}

{% if execute and is_incremental() %}

    {{ print("Running delete_m0_old_version_data: "~ dataset_name ~", "~ table_name~","~project_id) }}
    EXECUTE IMMEDIATE '''DELETE FROM `{{ project_id }}.{{ dataset_name }}.{{ table_name }}`
                        WHERE forecast_date = (SELECT MAX(forecast_gen_date) 
                        FROM `{{ project_id }}.{{ dataset_name }}.{{ base_table_name }}`)
                '''


{% endif %}
{{ print("completed delete_m0_old_version_data: ") }} 
{% endmacro %}