{% macro dq_rule_query_generator(results) %}

    {% set query_parts = [] %}
    {% set column_names = [
        "dq_rule_sk",
        "last_refresh",
        "valid_rule",
        "other",
        "data_load",
        "output"
    ] %}

    {% set date_columns = ["last_refresh"] %}
    {% set timestamp_columns = ["data_load"] %}
    {% set string_columns = ["other","output"] %}
    {% set boolean_columns = ["valid_rule"] %}
    {% set integer_columns = ["dq_rule_sk"] %}
    
    {% for row in results %}
        {% set formatted_row = [] %}
        {% for col_idx in range(column_names | length) %}
            {% set col_name = column_names[col_idx] %}
            {% set value = row[col_idx] %}

            {% if value is none or value == '' or value == "" or value == '\'""\'' %}
                {% if col_name in date_columns %}
                    {% set formatted_value = "CAST(NULL AS DATE)" %}
                {% elif col_name in timestamp_columns %}
                    {% set formatted_value = "CURRENT_TIMESTAMP()" %}
                {% elif col_name in string_columns %}
                    {% set formatted_value = "CAST(NULL AS STRING)" %}  
                {% elif col_name in boolean_columns %}
                    {% set formatted_value = "CAST(NULL AS BOOL)" %}
                {% elif col_name in integer_columns %}
                    {% set formatted_value = "CAST(NULL AS INT64)" %}
                {% else %}
                    {% set formatted_value = "NULL" %}
                {% endif %}
            {% elif value is string %}
                {% if col_name in date_columns %}
                    {% set formatted_value = "PARSE_DATE('%Y-%m-%d', '{}')".format(value) %}
                {% elif col_name in timestamp_columns %}
                    {% set formatted_value = "PARSE_TIMESTAMP('%Y-%m-%d %H:%M:%E*S', '{}')".format(value) %}
                {% elif col_name in string_columns %}
                    {% set formatted_value = value %}
                {% else %}
                    {% set formatted_value = value %}
                {% endif %}
            {% else %}
                {% set formatted_value = value %}
            {% endif %}

            {% do formatted_row.append(formatted_value) %}
        {% endfor %}

        {% set select_parts = [] %}
        {% for col, val in zip(column_names, formatted_row) %}
            {%- do select_parts.append(val ~ " AS " ~ col) -%}
        {% endfor %}
        
        {%- set query_part = "SELECT " ~ select_parts | join(", ") -%}
        {%- do query_parts.append(query_part) -%}
    {% endfor %}

    {% do log("Generated Query:\n" ~ query_parts | join(" UNION ALL\n"), info=true) %}
    {{- query_parts | join(" UNION ALL\n") -}}

{% endmacro %}