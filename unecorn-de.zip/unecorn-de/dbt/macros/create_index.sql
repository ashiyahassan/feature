{% macro create_index(dataset_name, table_name, index_name, column_names) %}

{% set project_id = target.project %}
-- {% set dataset_id = dataset_name %}
{{ print("Running create index macro for: "~ dataset_name ~", "~ table_name) }}
{% if execute %}

  EXECUTE IMMEDIATE '''CREATE SEARCH INDEX IF NOT EXISTS {{index_name}}
        ON `{{ project_id }}.{{ dataset_name }}.{{ table_name }}` ({{column_names}})'''

{% endif %}

{% endmacro %}
