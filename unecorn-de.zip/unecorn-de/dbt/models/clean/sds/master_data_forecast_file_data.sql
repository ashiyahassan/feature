{{ config(materialized='table') }}

WITH master_data AS (
    SELECT
        ean,
        `signature`,
        brand,
        sub_brand,  
        'VN' AS country_code,
        material_des AS product_local_description,
        category,  
        sub_category,
        `group`,    
        sub_group,  
        wid,
        hero,
        bundle,
        material_type,
        created_date AS insert_time,    
        modified_date AS update_time,  
        active_status,
        hash_map,
        old_ean,
        CASE
            WHEN lzd_status = 'On Going' AND shp_status = 'On Going' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'On Going' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'On Going' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'On Going' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'On Going' AND tiktok_status = 'Not In Catalogue' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'On Going' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'New Launch' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'New Launch' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'New Launch' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'New Launch' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'New Launch' AND tiktok_status = 'Not In Catalogue' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'New Launch' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'TBDC' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'TBDC' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'TBDC' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'TBDC' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'TBDC' AND tiktok_status = 'Not In Catalogue' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'TBDC' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'DC' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'DC' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'DC' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'DC' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'DC' AND tiktok_status = 'Not In Catalogue' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'DC' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'Not In Catalogue' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'Future Launch' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'Future Launch' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'Future Launch' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'Future Launch' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'Future Launch' AND tiktok_status = 'Not In Catalogue' THEN 'On Going'
            WHEN lzd_status = 'On Going' AND shp_status = 'Future Launch' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'On Going' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'On Going' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'On Going' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'On Going' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'On Going' AND tiktok_status = 'Not In Catalogue' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'On Going' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'New Launch' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'New Launch' AND tiktok_status = 'New Launch' THEN 'New Launch'
            WHEN lzd_status = 'New Launch' AND shp_status = 'New Launch' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'New Launch' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'New Launch' AND tiktok_status = 'Not In Catalogue' THEN 'New Launch'
            WHEN lzd_status = 'New Launch' AND shp_status = 'New Launch' AND tiktok_status = 'Future Launch' THEN 'New Launch'
            WHEN lzd_status = 'New Launch' AND shp_status = 'TBDC' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'TBDC' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'TBDC' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'TBDC' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'TBDC' AND tiktok_status = 'Not In Catalogue' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'TBDC' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'DC' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'DC' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'DC' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'DC' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'DC' AND tiktok_status = 'Not In Catalogue' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'DC' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'New Launch' THEN 'New Launch'
            WHEN lzd_status = 'New Launch' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'Not In Catalogue' THEN 'New Launch'
            WHEN lzd_status = 'New Launch' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'Future Launch' THEN 'New Launch'
            WHEN lzd_status = 'New Launch' AND shp_status = 'Future Launch' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'Future Launch' AND tiktok_status = 'New Launch' THEN 'New Launch'
            WHEN lzd_status = 'New Launch' AND shp_status = 'Future Launch' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'Future Launch' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'New Launch' AND shp_status = 'Future Launch' AND tiktok_status = 'Not In Catalogue' THEN 'New Launch'
            WHEN lzd_status = 'New Launch' AND shp_status = 'Future Launch' AND tiktok_status = 'Future Launch' THEN 'New Launch'
            WHEN lzd_status = 'TBDC' AND shp_status = 'On Going' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'On Going' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'On Going' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'On Going' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'On Going' AND tiktok_status = 'Not In Catalogue' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'On Going' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'New Launch' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'New Launch' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'New Launch' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'New Launch' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'New Launch' AND tiktok_status = 'Not In Catalogue' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'New Launch' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'TBDC' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'TBDC' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'TBDC' AND tiktok_status = 'TBDC' THEN 'TBDC'
            WHEN lzd_status = 'TBDC' AND shp_status = 'TBDC' AND tiktok_status = 'DC' THEN 'TBDC'
            WHEN lzd_status = 'TBDC' AND shp_status = 'TBDC' AND tiktok_status = 'Not In Catalogue' THEN 'TBDC'
            WHEN lzd_status = 'TBDC' AND shp_status = 'TBDC' AND tiktok_status = 'Future Launch' THEN 'TBDC'
            WHEN lzd_status = 'TBDC' AND shp_status = 'DC' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'DC' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'DC' AND tiktok_status = 'TBDC' THEN 'TBDC'
            WHEN lzd_status = 'TBDC' AND shp_status = 'DC' AND tiktok_status = 'DC' THEN 'TBDC'
            WHEN lzd_status = 'TBDC' AND shp_status = 'DC' AND tiktok_status = 'Not In Catalogue' THEN 'TBDC'
            WHEN lzd_status = 'TBDC' AND shp_status = 'DC' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'TBDC' THEN 'TBDC'
            WHEN lzd_status = 'TBDC' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'DC' THEN 'TBDC'
            WHEN lzd_status = 'TBDC' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'Not In Catalogue' THEN 'TBDC'
            WHEN lzd_status = 'TBDC' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'Future Launch' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'Future Launch' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'Future Launch' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'Future Launch' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'Future Launch' AND tiktok_status = 'Not In Catalogue' THEN 'On Going'
            WHEN lzd_status = 'TBDC' AND shp_status = 'Future Launch' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'On Going' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'On Going' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'On Going' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'On Going' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'On Going' AND tiktok_status = 'Not In Catalogue' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'On Going' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'New Launch' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'New Launch' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'New Launch' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'New Launch' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'New Launch' AND tiktok_status = 'Not In Catalogue' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'New Launch' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'TBDC' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'TBDC' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'TBDC' AND tiktok_status = 'TBDC' THEN 'TBDC'
            WHEN lzd_status = 'DC' AND shp_status = 'TBDC' AND tiktok_status = 'DC' THEN 'TBDC'
            WHEN lzd_status = 'DC' AND shp_status = 'TBDC' AND tiktok_status = 'Not In Catalogue' THEN 'TBDC'
            WHEN lzd_status = 'DC' AND shp_status = 'TBDC' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'DC' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'DC' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'DC' AND tiktok_status = 'TBDC' THEN 'TBDC'
            WHEN lzd_status = 'DC' AND shp_status = 'DC' AND tiktok_status = 'DC' THEN 'DC'
            WHEN lzd_status = 'DC' AND shp_status = 'DC' AND tiktok_status = 'Not In Catalogue' THEN 'DC'
            WHEN lzd_status = 'DC' AND shp_status = 'DC' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'TBDC' THEN 'TBDC'
            WHEN lzd_status = 'DC' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'DC' THEN 'DC'
            WHEN lzd_status = 'DC' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'Not In Catalogue' THEN 'DC'
            WHEN lzd_status = 'DC' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'Future Launch' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'Future Launch' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'Future Launch' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'Future Launch' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'Future Launch' AND tiktok_status = 'Not In Catalogue' THEN 'On Going'
            WHEN lzd_status = 'DC' AND shp_status = 'Future Launch' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'On Going' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'On Going' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'On Going' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'On Going' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'On Going' AND tiktok_status = 'Not In Catalogue' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'On Going' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'New Launch' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'New Launch' AND tiktok_status = 'New Launch' THEN 'New Launch'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'New Launch' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'New Launch' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'New Launch' AND tiktok_status = 'Not In Catalogue' THEN 'New Launch'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'New Launch' AND tiktok_status = 'Future Launch' THEN 'New Launch'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'TBDC' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'TBDC' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'TBDC' AND tiktok_status = 'TBDC' THEN 'TBDC'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'TBDC' AND tiktok_status = 'DC' THEN 'TBDC'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'TBDC' AND tiktok_status = 'Not In Catalogue' THEN 'TBDC'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'TBDC' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'DC' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'DC' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'DC' AND tiktok_status = 'TBDC' THEN 'TBDC'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'DC' AND tiktok_status = 'DC' THEN 'DC'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'DC' AND tiktok_status = 'Not In Catalogue' THEN 'DC'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'DC' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'New Launch' THEN 'New Launch'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'TBDC' THEN 'TBDC'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'DC' THEN 'DC'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'Not In Catalogue' THEN 'Not In Catalogue'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'Future Launch' THEN 'Future Launch'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'Future Launch' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'Future Launch' AND tiktok_status = 'New Launch' THEN 'New Launch'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'Future Launch' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'Future Launch' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'Future Launch' AND tiktok_status = 'Not In Catalogue' THEN 'Future Launch'
            WHEN lzd_status = 'Not In Catalogue' AND shp_status = 'Future Launch' AND tiktok_status = 'Future Launch' THEN 'Future Launch'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'On Going' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'On Going' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'On Going' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'On Going' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'On Going' AND tiktok_status = 'Not In Catalogue' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'On Going' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'New Launch' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'New Launch' AND tiktok_status = 'New Launch' THEN 'New Launch'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'New Launch' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'New Launch' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'New Launch' AND tiktok_status = 'Not In Catalogue' THEN 'New Launch'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'New Launch' AND tiktok_status = 'Future Launch' THEN 'New Launch'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'TBDC' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'TBDC' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'TBDC' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'TBDC' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'TBDC' AND tiktok_status = 'Not In Catalogue' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'TBDC' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'DC' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'DC' AND tiktok_status = 'New Launch' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'DC' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'DC' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'DC' AND tiktok_status = 'Not In Catalogue' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'DC' AND tiktok_status = 'Future Launch' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'New Launch' THEN 'New Launch'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'Not In Catalogue' THEN 'Future Launch'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'Not In Catalogue' AND tiktok_status = 'Future Launch' THEN 'Future Launch'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'Future Launch' AND tiktok_status = 'On Going' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'Future Launch' AND tiktok_status = 'New Launch' THEN 'New Launch'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'Future Launch' AND tiktok_status = 'TBDC' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'Future Launch' AND tiktok_status = 'DC' THEN 'On Going'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'Future Launch' AND tiktok_status = 'Not In Catalogue' THEN 'Future Launch'
            WHEN lzd_status = 'Future Launch' AND shp_status = 'Future Launch' AND tiktok_status = 'Future Launch' THEN 'Future Launch'
            ELSE ''
        END AS d2c_unecorn_status
    FROM {{ db_source('src_manual_files','vn_cpd_master_data_forecast_file_data') }}
    WHERE active_status = 'Y'
),
shp_data AS (
    SELECT
        ean,
        shp_status AS status,
        SPLIT(shp_launch_month, '.')[OFFSET(0)]  AS launch_date,
        SPLIT(shp_dc_month, '.')[OFFSET(0)]  AS discontinuation_date,
        -- oms_shp_status as oms_status,
        CASE WHEN unecorn_shp_status='nan' THEN '' ELSE unecorn_shp_status END AS unecorn_status, 
        'SHOPEE_VN' AS platform
    FROM {{ db_source('src_manual_files','vn_cpd_master_data_forecast_file_data') }}
    WHERE shp_status IS NOT NULL AND active_status = 'Y'
),
 
lzd_data AS (
    SELECT
        ean,
        lzd_status AS status,
        SPLIT(lzd_launch_month, '.')[OFFSET(0)] AS launch_date,
        SPLIT(lzd_dc_month, '.')[OFFSET(0)] AS discontinuation_date,
        CASE WHEN unecorn_lzd_status='nan' THEN '' ELSE unecorn_lzd_status END AS unecorn_status, 
        -- oms_lzd_status as oms_status,
        'LAZADA_VN' AS platform
    FROM {{ db_source('src_manual_files','vn_cpd_master_data_forecast_file_data') }}
    WHERE lzd_status IS NOT NULL AND active_status = 'Y'
),

tiktok_data AS (
    SELECT
        ean,
        tiktok_status AS status,
        SPLIT(tiktok_launch_month, '.')[OFFSET(0)] AS launch_date,
        SPLIT(tiktok_dc_month, '.')[OFFSET(0)] AS discontinuation_date,
        CASE WHEN unecorn_tiktok_status='nan' THEN '' ELSE unecorn_tiktok_status END AS unecorn_status, 
        {{ variable_macro("tiktok_vn_var") }} AS platform
    FROM {{ db_source('src_manual_files','vn_cpd_master_data_forecast_file_data') }}
    WHERE tiktok_status IS NOT NULL AND active_status = 'Y'
)
 
SELECT
    mas.ean AS ean_code,    
    mas.country_code AS country,
    mas.product_local_description,
    mas.wid,
    mas.`signature`,
    mas.brand,
    mas.sub_brand,  
    mas.hero,
    mas.bundle,
    mas.material_type,
    CASE WHEN com.status='na' THEN NULL ELSE com.status END AS status,
    CASE  WHEN com.launch_date='nan' THEN NULL ELSE com.launch_date END AS launch_date,
    CASE WHEN com.discontinuation_date='nan' THEN NULL ELSE com.discontinuation_date END AS discontinuation_date,
    -- com.oms_status,
    com.platform AS marketplace_code,  
    -- mas.country,
    mas.category,  
    mas.sub_category,
    mas.group,  
    mas.sub_group,  
    mas.insert_time,    
    mas.update_time,  
    mas.old_ean,  
    -- mas.file_path,  
    mas.active_status,
    mas.hash_map,
    com.unecorn_status,
    mas.d2c_unecorn_status,
    CURRENT_TIMESTAMP() AS load_ts
FROM   
    (SELECT ean, `status`, launch_date,  discontinuation_date, unecorn_status, platform
    FROM
    (SELECT * FROM shp_data AS shp
    UNION ALL
    SELECT * FROM lzd_data AS lzd 
    UNION ALL
    SELECT * FROM tiktok_data AS tiktok)
    AS tcom)
    AS com
JOIN master_data AS mas ON com.ean = mas.ean