{% macro delete_current_month_data(dataset_name, table_name, base_table_name) %}

{% set project_id = target.project %}

{% if execute and is_incremental() %}

    {{ print("Running delete_current_month_data: "~ dataset_name ~", "~ table_name~","~project_id) }}
    EXECUTE IMMEDIATE '''DELETE FROM `{{ project_id }}.{{ dataset_name }}.{{ table_name }}`
                        WHERE forecast_gen_date = (SELECT CAST(DATE_TRUNC(MAX(load_ts), MONTH) AS DATE)
                        FROM `{{ project_id }}.{{ dataset_name }}.{{ base_table_name }}`)
                '''


{% endif %}
{{ print("completed delete_current_month_data") }} 
{% endmacro %}