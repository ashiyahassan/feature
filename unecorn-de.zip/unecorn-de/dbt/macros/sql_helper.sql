{% macro convert_string_to_datetime(column, format) %}
    CAST({{column}} AS TIMESTAMP FORMAT '{{format}}')
{% endmacro %}


{% macro convert_int_to_datetime(column, format) %}
    CAST((CAST({{column}} AS STRING)) AS TIMESTAMP FORMAT '{{format}}')
{% endmacro %}


{% macro convert_string_to_date(column, format) %}
    CAST({{column}} AS DATE FORMAT '{{format}}')
{% endmacro %}

{% macro extract_year_from_date(date_value) %}
    EXTRACT(YEAR FROM {{date_value}})
{% endmacro %}

{% macro extract_month_from_date(date_value) %}
    LPAD(CAST(EXTRACT(MONTH FROM {{date_value}}) AS STRING), 2, '0')
{% endmacro %}

{% macro extract_day_from_date(date_value) %}
    LPAD(CAST(EXTRACT(DAY FROM {{date_value}}) AS STRING), 2, '0')
{% endmacro %}