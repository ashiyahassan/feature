{%- macro bigquery__string_literal(value) -%}
    '''{{ value }}'''
{%- endmacro -%}
