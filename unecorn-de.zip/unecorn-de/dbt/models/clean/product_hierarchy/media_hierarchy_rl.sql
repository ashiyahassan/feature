{{ config(materialized='table') }}

SELECT 
    compass_code,
    division,
    signature_label,
    brand_label,
    sub_brand_label,
    reference_label,
    nuance_label,
    axe_label,
    sub_axe_label,
    metier_label,
    sub_metier_label,
    signature_code,
    brand_code,
    sub_brand_code,
    reference_code,
    nuance_code,
    axe_code,
    sub_axe_code,
    metier_code,
    sub_metier_code,
    full_hierarchy_code,
    source_system,
    CURRENT_TIMESTAMP() AS load_ts
FROM 
(
    SELECT DISTINCT 
        a.compass_code,
        b.division,
        b.signature_label,
        b.brand_label,
        b.sub_brand_label,
        b.reference_label,
        b.nuance_label,
        b.axe_label,
        b.sub_axe_label,
        b.metier_label,
        b.sub_metier_label,
        b.signature_code,
        b.brand_code,
        b.sub_brand_code,
        b.reference_code,
        b.nuance_code,
        b.axe_code,
        b.sub_axe_code,
        b.metier_code,
        b.sub_metier_code,
        b.full_hierarchy_code,
        b.source_system,
        ROW_NUMBER() OVER (PARTITION BY a.compass_code ORDER BY b.meta_validity_from DESC) AS rownumb
    FROM 
    (
        SELECT DISTINCT 
            compass_code 
        FROM {{ref('media_plan')}}
        UNION ALL
        SELECT DISTINCT 
            compass_code 
        FROM {{ref('media_plan_actual')}}
    ) AS a
    LEFT JOIN 
    (
        SELECT DISTINCT 
            sku_code,
            compass_code 
        FROM {{ref('sku_v1')}}
    ) AS c 
    ON a.compass_code = c.compass_code
    LEFT JOIN {{ref('product_hierarchy')}} AS b
    ON c.sku_code = b.sku_code
    WHERE b.source_system IN ('ECC','Elixpedia')
)
WHERE rownumb = 1
ORDER BY compass_code