{{ config(materialized='table') }}
 
{%- set target_relation = adapter.get_relation(
      database=this.database,
      schema=this.schema,
      identifier=this.name) -%}
{%- set table_exists=target_relation is not none -%}
 
WITH source_data AS (
    SELECT *
     FROM {{ref('dummy_code')}}
     where active_status = 'Y'
),
row_data AS (
    {% if table_exists %}
    {{ print("Running table_exists ") }}
    SELECT
        CASE
            WHEN nd.master_sk IS NOT NULL THEN nd.master_sk
            ELSE max_master_sk + ROW_NUMBER() OVER()  
        END AS row_num,
        rd.ean_code,rd.platform_code
    FROM
    (
        SELECT * 
        FROM
            {{ref('dummy_code')}} 
        WHERE active_status='Y'
    ) AS rd 
    LEFT JOIN
    (
        SELECT 
            ean_code, 
            platform_code, 
            master_sk 
        FROM {{this}}
    ) AS nd
    ON
    rd.ean_code = nd.ean_code
    AND rd.platform_code = nd.platform_code
    LEFT JOIN
    (
        SELECT 
            MAX(master_sk) AS max_master_sk 
        FROM {{this}}
    ) AS M
    ON 1=1
    {% else %}
    SELECT 
        10000000 + ROW_NUMBER() OVER() AS row_num, 
        ean_code,platform_code
    FROM
    (
        SELECT  DISTINCT 
            ean_code,platform_code
        FROM {{ref('dummy_code')}}
        WHERE active_status='Y'
    )
    {% endif %}  
)
 
SELECT
    rd.row_num AS master_sk,
    sd.*
FROM source_data AS sd
LEFT JOIN row_data AS rd 
ON sd.ean_code = rd.ean_code
AND sd.platform_code = rd.platform_code