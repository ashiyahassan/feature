#!/bin/sh

echo "start"
apt-get update && apt-get install -y google-cloud-sdk
echo "end"


