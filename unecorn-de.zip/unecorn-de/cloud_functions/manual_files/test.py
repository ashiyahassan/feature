import pandas as pd
from google.cloud import storage, bigquery
from datetime import datetime
 
 
bigquery_client = bigquery.Client()
project_id = 'spmena-unecorn-zn-apac-dv'
dataset_id = 'SDS'
data_bytes = 'master_data_forecast.xlsx'
file_path = data_bytes
file_name = file_path.split("/")[-1]
stage_table_id = f'{project_id}.{dataset_id}.stage_{file_name.split(".")[0]}_file_data'
schema = ["ean", "signature", "brand", "Sub Brand", "category", "sub_category", "group", "sub_group", "hero", "bundle",
          "material_type", "material_des", "Old EAN", "lzd_status", "lzd_launch_month", "lzd_dc_month", "shp_status",
          "shp_launch_month", "shp_dc_month", "unecorn_shp_status", "unecorn_lzd_status"]
 
df = pd.read_excel(data_bytes, sheet_name="masterdata" )
def insert_job(df, table_id, file_name):
    df = validate_schema_master_data(df, schema)
    print("ENTERD INSERT")
    print(table_id)
    try:
        schema_val = []
        for sch in schema:
            schema_val.append(bigquery.SchemaField(sch, "STRING"))
            print(schema_val)
        job_config = bigquery.LoadJobConfig(
            write_disposition="WRITE_TRUNCATE",
            schema=schema_val  # Define schema fields
        )
        table_id = f'{project_id}.{dataset_id}.stage_{file_name.split(".")[0]}_file_data'
        job = bigquery_client.load_table_from_dataframe(df, table_id, job_config=job_config)
        print("job config set")
        # Wait for the job to complete
        job.result()
        print('TABLE LOADED')
    except Exception as e :
        print("Error : ",e)
    print(f"Manual files Ingestion :{file_name} : ", f"File {file_name} loaded into BigQuery table {table_id}")
 
def validate_schema_master_data(df, schema):
    df['sub_category'] = df['sub-category']
    df['sub_group'] = df['sub-group']
    df = df[schema]
    print("SCHEMA VALIDATED")
    return to_string(df, schema)
 
 
def to_string(df, schema):
    for i in schema:
        df[i] = df[i].astype(str)
       
    print("schema conversion done")
    return df
 
 
 
def add_columns(df, schema):
    schema.append('wid')
    schema.append('country_code')
    schema.append('created_date')
    schema.append('modified_date')
    schema.append('active_status')
    # schema.append('hash_map')
 
    df['wid'] = get_wid()
    df['country_code'] = 'VN'
    df['created_date'] = datetime.now()
    df['modified_date'] = datetime.now()
    df['active_status'] = 'Y'
    # df['hash_map'] = 0
 
    print("COLUMNS ADDED")
    return df
 
 
def get_wid():
    try:
        query = f"""
                SELECT MAX(wid) as wid
                FROM `{project_id}.{dataset_id}.master_data_forecast_file_data`
            """
        query_job = bigquery.Client().query(query)
        result = query_job.result()
 
        # Extract the last batch ID
        wid = None
        for row in result:
            if row.wid is None:
                wid = 0
            else:
                wid = row.wid
        return int(wid) + 1
    except:
        return 1
 
 
df = add_columns(df,schema)
 
insert_job(df, stage_table_id, file_name)