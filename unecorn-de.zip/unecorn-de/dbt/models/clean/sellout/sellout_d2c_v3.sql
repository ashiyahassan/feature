{{ config(materialized='table') }}

SELECT SUBSTRING(market_code, 1, 2) AS country,
    division_code AS division,
    (CASE WHEN data_provider LIKE {{variable_macro('shp_like_var')}} THEN {{variable_macro('shopee_vn_var')}}
    WHEN data_provider LIKE {{variable_macro('lzd_like_var')}} THEN {{variable_macro('lazada_vn_var')}}
    WHEN data_provider LIKE {{variable_macro('tiktok_like_var')}} THEN {{variable_macro('tiktok_vn_var')}}
    ELSE data_provider END) AS marketplace_code,
    signature_code,
    sellout_date,
    order_delivery_date,
    order_completed_date,
    invoice_date,
    buyer_shipping_fee,
    seller_discount,
    platform_discount,
    bundle_product_id,
    bundle_quantity,
    sellout_year,
    sellout_month,
    order_number,
    detailed_order_number,
    original_order_number,
    retailer_product_code,
    sap_sku_code,
    CASE WHEN bom_header_ean_code IS NULL THEN CAST(REGEXP_REPLACE(ean_code, r'^0+', '') AS STRING) ELSE CAST(REGEXP_REPLACE(bom_header_ean_code, r'^0+', '') AS STRING)  END AS ean_code,
    sales_type,
    order_status,
    transaction_type,
    sellout_date_code,
    original_consumer_code,
    beauty_advisor_code,
    point_of_sale_code,
    sold_units,
    returned_units,
    cancelled_units,
    net_sellout_value_doc_tax_included,
    net_sellout_value_lcl_tax_included AS net_sellout_value_loc_tax_included,
    net_sellout_value_eur_tax_included,
    net_sellout_value_hub_tax_included AS net_sellout_value_usd_tax_included,
    net_sellout_value_doc_tax_excluded,
    net_sellout_value_lcl_tax_excluded AS net_sellout_value_loc_tax_excluded,
    net_sellout_value_eur_tax_excluded,
    net_sellout_value_hub_tax_excluded AS net_sellout_value_usd_tax_excluded,
    gross_sellout_value_doc_tax_included,
    gross_sellout_value_lcl_tax_included AS gross_sellout_value_loc_tax_included,
    gross_sellout_value_eur_tax_included,
    gross_sellout_value_hub_tax_included AS gross_sellout_value_usd_tax_included,
    gross_sellout_value_doc_tax_excluded,
    gross_sellout_value_lcl_tax_excluded AS gross_sellout_value_loc_tax_excluded,
    gross_sellout_value_eur_tax_excluded,
    gross_sellout_value_hub_tax_excluded AS gross_sellout_value_usd_tax_excluded,
    list_price_sellout_value_doc_tax_included,
    list_price_sellout_value_lcl_tax_included AS list_price_sellout_value_loc_tax_included,
    list_price_sellout_value_eur_tax_included,
    list_price_sellout_value_hub_tax_included AS list_price_sellout_value_usd_tax_included,
    list_price_sellout_value_doc_tax_excluded,
    list_price_sellout_value_lcl_tax_excluded AS list_price_sellout_value_loc_tax_excluded,
    list_price_sellout_value_eur_tax_excluded,
    list_price_sellout_value_hub_tax_excluded AS list_price_sellout_value_usd_tax_excluded,
    best_available_sales_doc_tax_included,
    best_available_sales_lcl_tax_included AS best_available_sales_tax_included,
    best_available_sales_eur_tax_included,
    best_available_sales_hub_tax_included AS best_available_sales_usd_tax_included,
    nmv_doc,
    nmv_lcl AS nmv,
    nmv_eur,
    nmv_hub,
    sellout_type,
    finished_goods_sold_units,
    currency_code,
    unit_price,
    data_provider,
    sdds_source,
    unique_id,
    data_insert_timestamp,
    data_update_timestamp,
    source_update_timestamp,
    CURRENT_TIMESTAMP() AS load_ts
    FROM {{db_source('src_sellout','sellout_d2c_v3')}} AS a
    LEFT JOIN
    (
        SELECT DISTINCT 
            bom_header_code,
            bom_header_ean_code 
        FROM  {{ref('bom_explosion_factor')}}
        WHERE local_bom_type_description = 'VB'
    ) AS b
    ON a.bundle_product_id=b.bom_header_code
    WHERE market_code IN {{variable_macro('country_var2')}}
    AND division_code IN {{variable_macro('division_var')}}
    AND sdds_source = {{variable_macro('sellout_source_var')}}
    AND signature_code <> '-1'