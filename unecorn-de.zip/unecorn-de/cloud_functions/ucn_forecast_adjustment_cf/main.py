import io
import subprocess
import functions_framework
import os
import csv
import json
import pandas as pd
from google.auth import compute_engine
from google.cloud import bigquery
from google.cloud import storage
from importlib.machinery import SourceFileLoader
from schema import *
from queries import *
from datetime import *
import google.auth
from google.auth import default
from google.auth.transport.requests import Request
from google.oauth2 import id_token
import requests
from google.cloud import pubsub_v1
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
import ms_to_gcs
import time
import base64
import concurrent.futures
import multiprocessing
import threading
import func_timeout




def get_id_token(audience):
    # Obtain default credentials
    credentials, project_id = default()

    # Request an ID token
    auth_req = Request()
    target_audience = audience
    id_token_credential = id_token.fetch_id_token_credentials(target_audience)

    # Refresh the credentials to get the token
    id_token_credential.refresh(auth_req)
    return id_token_credential.token


def get_access_token():
    # Obtain default credentials
    credentials, project_id = default()

    # Refresh the credentials to get the token
    auth_req = Request()
    credentials.refresh(auth_req)
    return credentials.token


# DATE FORMAT FUNCTION
def get_current_date_formatted():
    # Get the current date
    current_date = datetime.now()
    # Format the date as YYYYMMDD
    formatted_date = current_date.strftime('%Y%m%d')
    return formatted_date


# Define your BigQuery and GCS configurations
PROJECT_ID = os.getenv('project_id') if os.getenv('project_id') is not None else 'spmena-unecorn-zn-apac-dv'
ENV = os.getenv('gcp_env') if os.getenv('gcp_env') is not None else 'dv'
BQ_DATASET_ID = "cds_unecorn_raw_zn"
BQ_TABLE_ID = "de_fcst_temp_table"
AUDIT_DATASET = f"{PROJECT_ID}.cds_unecorn_audit_zn.log_forecast_adjustment"
LOG_HISTORY_TABLE_NAME = f"{PROJECT_ID}.cds_unecorn_audit_zn.log_forecast_adjustment_history"
GCS_ARCHIVE_BUCKET_NAME = f"unecornde-audit-ew1-{ENV}"
SCHEMA_FILE_PATH = "schema.py"  # File containing schema definitions
QUERIES_FILE_PATH = "queries.py"  # File containing queries
audit_bucket_name = f"unecornde-audit-ew1-{ENV}"
SUBSCRIPTION_ID = 'unecorn-webapp-topic'
TOPIC_ID = f"unecornwebapp-forecast-adjustment-ae2-{ENV}"  # Replace with your topic ID
gcloud_run_url = os.getenv('cloud_run_url') if os.getenv(
    'cloud_run_url') is not None else 'https://unecornde-gcr-crdbt-ew1-dv-nrlzva6xoq-ew.a.run.app'
CLOUD_RUN_URL = f'{gcloud_run_url}?arg1=models/ods/forecast/fact_monthly_fh_forecast.sql,ucn_forecast_adjustment_batch,{get_current_date_formatted()},I,{ENV},{audit_bucket_name}'
CLOUD_RUN_BOM_D_URL = f'{gcloud_run_url}?arg1=models/ods/forecast/fact_daily_forecast_explosion.sql,ucn_forecast_adjustment_batch,{get_current_date_formatted()},I,{ENV},{audit_bucket_name}'
CLOUD_RUN_BOM_M_URL = f'{gcloud_run_url}?arg1=models/ods/forecast/fact_monthly_forecast_explosion.sql,ucn_forecast_adjustment_batch,{get_current_date_formatted()},I,{ENV},{audit_bucket_name}'
CLOUD_RUN_BOM_FH_M_URL = f'{gcloud_run_url}?arg1=models/ods/forecast/fact_monthly_fh_forecast_explosion.sql,ucn_forecast_adjustment_batch,{get_current_date_formatted()},I,{ENV},{audit_bucket_name}'
CLOUD_RUN_KPI_URL = f'{gcloud_run_url}?arg1=models/ods/forecast/fact_monthly_kpi.sql,ucn_forecast_adjustment_batch,{get_current_date_formatted()},I,{ENV},{audit_bucket_name}'
FM_CF_CLOUD_RUN_URL = os.getenv('fm_export_cfn_url') if os.getenv('fm_export_cfn_url') is not None else 'https://europe-west1-spmena-unecorn-zn-apac-dv.cloudfunctions.net/unecornde-cffmexport-cfn-ew1-{ENV}'

# EMAIL CONFIGURATION
TO_EMAIL = ['prakhar.shanker@loreal.com','shubham2.mishra@loreal.com']
if ENV == 'pd': TO_EMAIL.append('APMENA-GCP-UNECORN-PRODUCT-VN-USER@loreal.com')
SMTP_SERVER = "smtp.sendgrid.net"
SMTP_PORT = 587
SMTP_USERNAME = "apikey"
SMTP_PASSWORD = "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"
EMAIL_FROM_NAME = "Loreal"
FROM_EMAIL_ADDRESS="no-reply@apmena-onedata-np.noreply.loreal.net"









# Triggered by a change in a storage buck
@functions_framework.http
def hello_http(request):
    

    request_json = request.get_json(silent=True)
    request_args = request.args
    print("request_json==>",request_json)
    
    # if request_json and 'name' in request_json:
    #     name = request_json['name']
    # elif request_args and 'name' in request_args:
    #     name = request_args['name']
    # else:
    #     name = 'World'
    # return 'Hello {}!'.format(name)


    data = request_json["data"]
    data['name'] = data['file_name']
    print("REQUEST : ")
    print(PROJECT_ID)
    print(data)
    print(data["bucket"])

    print(data["file_name"])


    return run_with_timeout(1800,data)



def load_excel_to_bigquery(gcs_bucket_name, gcs_file_path, project_id, guid):
    
    # Initialize GCS and BigQuery clients
    storage_client = storage.Client(project=project_id)
    bigquery_client = bigquery.Client(project=project_id)
    file_name = get_file_name(os.path.basename(gcs_file_path))
    bigquery_table_id = bigquery_client.dataset(BQ_DATASET_ID).table(get_filename_ext(file_name))

    # Download the file from GCS
    bucket = storage_client.bucket(gcs_bucket_name)
    blob = bucket.blob(gcs_file_path)

    try:
        file_data = blob.download_as_bytes()
        print(f"{guid} File downloaded successfully. File size: {len(file_data)} bytes")
    except Exception as e:
        print(f"Error downloading the file from GCS: {str(e)}")
        raise

    # Try reading the file based on its extension
    try:
        if gcs_file_path.endswith('.xlsx'):
            print(f" {guid} File is an .xlsx file, using 'openpyxl' engine")
            df = pd.read_excel(io.BytesIO(file_data), engine='openpyxl')
        elif gcs_file_path.endswith('.xls'):
            print(f" {guid} File is an .xls file, using 'xlrd' engine")
            df = pd.read_excel(io.BytesIO(file_data), engine='xlrd')
        elif gcs_file_path.endswith('.csv'):
            print(f" {guid} File is a .csv file, using 'utf-8' encoding")
            df = pd.read_csv(io.BytesIO(file_data), encoding='utf-8')
        else:
            raise ValueError(f" {guid} Unsupported file format: {gcs_file_path}. Please use .xlsx, .xls, or .csv")
        print(f" {guid} File read successfully, shape of DataFrame: {df.shape}")
    
    except Exception as e:
        print(f" {guid}  Failed to read the file from GCS: {str(e)}")
        raise

    # Apply encoding and convert all columns to string
    try:
        df = df.apply(lambda col: col.astype(str).str.encode('utf-8', errors='ignore').str.decode('utf-8'))
        # df['comments_consensus'] = df['comments_consensus'].apply(lambda x: '' if pd.isna(x) else x)
        # df['comments_validated'] = df['comments_validated'].apply(lambda x: '' if pd.isna(x) else x)

        df['comments_consensus'] = df['comments_consensus'].replace(['nan'], '')
        df['comments_validated'] = df['comments_validated'].replace(['nan'], '')
        
    except Exception as e:
        print(f" {guid} Error in handling encoding: {str(e)}")
        raise

    # Create BigQuery schema with all columns as STRING type
    header = df.columns.tolist()
    header = [i.replace("(", "").replace(")", "") for i in header]  # Clean header column names
    bq_schema = [bigquery.SchemaField(column_name, "STRING") for column_name in header]
    print(f" {guid} Schema created: {bq_schema}")

    # Configure BigQuery load job settings with WRITE_TRUNCATE
    job_config = bigquery.LoadJobConfig(
        schema=bq_schema,
        write_disposition=bigquery.WriteDisposition.WRITE_TRUNCATE,  # Truncate the table before loading
        source_format=bigquery.SourceFormat.PARQUET
    )

    # Insert data into BigQuery
    try:
        job = bigquery_client.load_table_from_dataframe(df, bigquery_table_id, job_config=job_config)
        job.result()  # Wait for the job to complete
        print(f" {guid} Data successfully inserted into {bigquery_table_id}, job completed successfully.")
    except Exception as e:
        print(f" {guid} Failed to load data into BigQuery: {str(e)}")
        raise



def call_process_file(data):
    status = process_file({"name": data['name'], 'bucket': data["bucket"]}, None)
    status = 200
    if status == 500:
        return "Forecast Adjustment Function Failed"
        print("Forecast Adjustment Function Failed")
    return "Forecast Adjustmentt Succesfull!"




def run_with_timeout(timeout_seconds, data):
    file_path = data["name"]
    file_name = get_file_name(os.path.basename(file_path))
    guid = get_guid(os.path.basename(file_path))

    try:
        # Use func_timeout to run the function with a timeout
        result = func_timeout.func_timeout(timeout_seconds, call_process_file, args=(data,))
        return result
    except func_timeout.FunctionTimedOut:
        # Handle the timeout scenario
        print(guid," : Timeout occurred")
        release_lock('ADJUSTMENT INIT', 'FAILED', guid)
        print(guid," : LOCK UPDATED")
        push_to_topic(file_name=guid, status="FAILED")
        move_to_archive(data)
        send_email(file_name, 'FAILED')
        print(guid," : PROCESS EXECUTION STOPPED")
        return "Process Failed: Timeout occurred"
    except Exception as e:
        # Handle other exceptions
        release_lock('ADJUSTMENT INIT', 'FAILED', guid)
        print(guid," : LOCK UPDATED")
        push_to_topic(file_name=guid, status="FAILED")
        move_to_archive(data)
        send_email(file_name, 'FAILED')
        print(guid," : PROCESS EXECUTION STOPPED")
        return f"Process Failed: {e}"
def get_filename_ext(param):
    return param.split(".")[0]



def parse_param(param):
    if 'FH' in param:
        query = rollback_query_daily
    elif 'ST' in param or 'MT' in param:
        query = rollback_query_monthly
    else:
        return None  # or any other value indicating no match
    client = bigquery.Client()
    query_job = client.query(query)
    query_job.result()  # Wait for the query to complete
    print("ROLLBACK JOB COMPLETED")


# GET_FILE_NAME and remove the date
def get_file_name(file_name):
    fn = file_name.split("_")
    file_name = "_".join(fn[1:])
    return file_name

def get_guid(file_name):
    fn = file_name.split("_")
    file_name = fn[0]
    return file_name


# Load schema from the schema file
def load_schema():
    schema = schema_dict
    return schema


# Load queries from the queries file
def load_queries():
    return query_dict


# Verify file path
def verify_file_path(file_path):
    return file_path.startswith("VN/CPD")


# Verify file columns
def verify_file_columns(file_path, schema, bucket):
    file_name = get_file_name(os.path.basename(file_path))
    expected_columns = schema[get_filename_ext(file_name)]
    guid = get_guid(os.path.basename(file_path))

    print(guid," : ",get_filename_ext(file_name), file_path)
    storage_client = storage.Client()
    bucket_name = bucket
    bucket = storage_client.get_bucket(bucket)
    blob = bucket.blob(file_path)


    # Assuming CSV format, read the header line
    file_content = blob.download_as_string()
    file_extension = os.path.splitext(file_path)[1].lower()
    # file_content = file_content.encode('latin-1', 'replace')
    if file_extension in ['.csv']:
        # Handle CSV files
        file_content = file_content.decode("utf-8")
        lines = file_content.split("\n")
        header = next(csv.reader([lines[0]]))
        key = 'csv'

    elif file_extension in ['.xlsx', '.xls']:
        # Handle XLSX and XLS files using pandas
        from io import BytesIO
        file_content = BytesIO(file_content)
        df = pd.read_excel(file_content)
        # df = df.iloc[:-2]
        header = df.columns.tolist()
        blob = df
        key = 'xlsx'

    else:
        
        raise ValueError("Unsupported file format")
        return False

    print(guid," : ",expected_columns)
    print(guid," : ",header)

    if header == expected_columns:
        # bq_schema = []
        # header = [i.replace("(", "").replace(")", "") for i in header]
        # for column_name in header:
        #     bq_schema.append(bigquery.SchemaField(column_name, "STRING"))
        load_excel_to_bigquery( bucket_name , file_path,  PROJECT_ID, guid)
        # insert_into_bigquery_temp(blob, file_name, bq_schema, key, guid)
        return True
    else:
        return False



def get_max_batch_id():
    # Construct a BigQuery client object.
    client = bigquery.Client()

    # SQL query to get the maximum batch_id
    query = f"""
    SELECT COALESCE(MAX(batch_id), 0) as batch_id
    FROM `{AUDIT_DATASET}`
    """

    # Make an API request.
    query_job = client.query(query)

    # Get the results.
    results = query_job.result()

    # Extract the batch_id from the results.
    max_batch_id = [row.batch_id for row in results][0]  # Assuming there will be exactly one row returned.

    return max_batch_id




# Insert data into BigQuery temporary table
def insert_into_bigquery_temp(blob, file_name, bq_schema, key, guid):
    client = bigquery.Client()
    table_ref = client.dataset(BQ_DATASET_ID).table(get_filename_ext(file_name))
    print(guid," : ",BQ_DATASET_ID, get_filename_ext(file_name))
    job_config = bigquery.LoadJobConfig()
    job_config.source_format = bigquery.SourceFormat.CSV
    job_config.skip_leading_rows = 1
    # job_config.schema = [ bigquery.SchemaField('Forecast Version', 'STRING', 'NULLABLE', None, (), None),  bigquery.SchemaField('Forecast Week', 'STRING', 'NULLABLE', None, (), None),  bigquery.SchemaField('Country', 'STRING', 'NULLABLE', None, (), None),  bigquery.SchemaField('Platform', 'STRING', 'NULLABLE', None, (), None),  bigquery.SchemaField('Signature', 'STRING', 'NULLABLE', None, (), None),  bigquery.SchemaField('Category', 'STRING', 'NULLABLE', None, (), None),  bigquery.SchemaField('Group', 'STRING', 'NULLABLE', None, (), None),  bigquery.SchemaField('EAN', 'STRING', 'NULLABLE', None, (), None),  bigquery.SchemaField('EAN Description', 'STRING', 'NULLABLE', None, (), None),  bigquery.SchemaField('Hero', 'STRING', 'NULLABLE', None, (), None),  bigquery.SchemaField('Lifecycle', 'STRING', 'NULLABLE', None, (), None),  bigquery.SchemaField('AI Model Forecast', 'STRING', 'NULLABLE', None, (), None),  bigquery.SchemaField('Consensus Forecast', 'STRING', 'NULLABLE', None, (), None),  bigquery.SchemaField('Comments CF', 'STRING', 'NULLABLE', None, (), None),  bigquery.SchemaField('Validated Forecast', 'STRING', 'NULLABLE', None, (), None),  bigquery.SchemaField('Comments VF', 'STRING', 'NULLABLE', None, (), None)]
    job_config.schema = bq_schema
    job_config.write_disposition = bigquery.WriteDisposition.WRITE_TRUNCATE
    try:
        if key == 'csv':
            with blob.open("rb") as source_file:
                job = client.load_table_from_file(
                    source_file, table_ref, job_config=job_config
                )
                job.result()  # Waits for the job to complete

        elif key == 'xlsx':
            blob.replace(r'\u200b', '', regex=True, inplace=True)
            blob.replace(r'\u0110', '', regex=True, inplace=True) 
            csv_buffer = io.StringIO()
            blob.to_csv(csv_buffer, index=False, encoding='UTF-16')
            csv_buffer.seek(0)
            job = client.load_table_from_file(
                csv_buffer, table_ref, job_config=job_config
            )
            job.result()  # Waits for the job to complete
    except Exception as e :
        print(guid,' : ',e)
        raise ValueError('Error Inserting Temperory Table')


# Insert data into BigQuery temporary table
def insert_into_bigquery(file_path, bucket):
    client = bigquery.Client()
    table_ref = client.dataset(BQ_DATASET_ID).table(BQ_TABLE_ID)
    job_config = bigquery.LoadJobConfig()
    job_config.source_format = bigquery.SourceFormat.CSV
    job_config.skip_leading_rows = 1
    job_config.schema = [bigquery.SchemaField('Forecast Version', 'STRING', 'NULLABLE', None, (), None),
                         bigquery.SchemaField('Forecast Week', 'STRING', 'NULLABLE', None, (), None),
                         bigquery.SchemaField('Country', 'STRING', 'NULLABLE', None, (), None),
                         bigquery.SchemaField('Platform', 'STRING', 'NULLABLE', None, (), None),
                         bigquery.SchemaField('Signature', 'STRING', 'NULLABLE', None, (), None),
                         bigquery.SchemaField('Category', 'STRING', 'NULLABLE', None, (), None),
                         bigquery.SchemaField('Group', 'STRING', 'NULLABLE', None, (), None),
                         bigquery.SchemaField('EAN', 'STRING', 'NULLABLE', None, (), None),
                         bigquery.SchemaField('EAN Description', 'STRING', 'NULLABLE', None, (), None),
                         bigquery.SchemaField('Hero', 'STRING', 'NULLABLE', None, (), None),
                         bigquery.SchemaField('Lifecycle', 'STRING', 'NULLABLE', None, (), None),
                         bigquery.SchemaField('AI Model Forecast', 'STRING', 'NULLABLE', None, (), None),
                         bigquery.SchemaField('Consensus Forecast', 'STRING', 'NULLABLE', None, (), None),
                         bigquery.SchemaField('Comments (CF)', 'STRING', 'NULLABLE', None, (), None),
                         bigquery.SchemaField('Validated Forecast', 'STRING', 'NULLABLE', None, (), None),
                         bigquery.SchemaField('Comments (VF)', 'STRING', 'NULLABLE', None, (), None)]

    storage_client = storage.Client()
    bucket = storage_client.get_bucket(bucket)
    blob = bucket.blob(file_path)
    with blob.open("rb") as source_file:
        job = client.load_table_from_file(
            source_file, table_ref, job_config=job_config
        )

    job.result()  # Waits for the job to complete


# Move file to archive bucket
def move_to_archive(file_path):
    storage_client = storage.Client()
    source_bucket_name = file_path['bucket']
    source_blob_name = file_path['name']

    source_bucket = storage_client.get_bucket(source_bucket_name)
    source_blob = source_bucket.blob(source_blob_name)

    destination_bucket = storage_client.bucket(GCS_ARCHIVE_BUCKET_NAME)
    destination_blob = source_bucket.copy_blob(
        source_blob, destination_bucket, source_blob_name
    )

    source_blob.delete()  # Delete file from source bucket after copying


# Run forecast adjustment query
def run_forecast_adjustment(file_name, guid):
    queries = load_queries()
    query = queries[get_filename_ext(file_name)]
    print(guid," : ",f"{file_name} : -> {query}")
    # logging.info(query)
    batch_id = guid
    try:
        if query:
            client = bigquery.Client()
            query_job = client.query(query)
            query_job.result()  # Wait for the query to complete
        print(guid," : ADJUSTMENT JOB COMPLETED")
        status = 'SUCCESS'
    except Exception as e:
        status = 'FAILED'
        raise ValueError("RUN FORECAST FAILED : ", e)
    
    insert_forecast_to_log( get_filename_ext(file_name), LOG_HISTORY_TABLE_NAME, batch_id, file_name, get_filename_ext(file_name).split("_")[-1], status)
    insert_audit_row(batch_id=batch_id, job_id=2, job_name=f'{file_name} forecast adjustment',
                         status=status, file_name=file_name, guid=guid)


# Main function triggered by GCS bucket
def process_file(event, context):
    file_path = event["name"]
    file_name = get_file_name(os.path.basename(file_path))
    guid = get_guid(os.path.basename(file_path))


    acquire_lock(guid, 1, "ADJUSTMENT INIT", "LOCKED", file_name)
    try:
        if not verify_file_path(file_path):
            push_to_topic(file_name=guid,status="FAILED")
            move_to_archive(event)
            send_email(file_name,'FAILED')
            print(guid," : INVALID FILE PATH")


            release_lock('ADJUSTMENT INIT', 'FAILED', guid)
            print(guid," : LOCK UPDATED")

            return 500

        schema = load_schema()
        if not verify_file_columns(file_path, schema, event["bucket"]):
            print(guid," : SCHEMA NOT MATCHED")
            push_to_topic(file_name=guid,status="FAILED")
            move_to_archive(event)
            send_email(file_name,'FAILED')


            release_lock('ADJUSTMENT INIT', 'FAILED', guid)
            print(guid," : LOCK UPDATED")
            raise ValueError("Columns do not match schema")
            return 500

        # insert_into_bigquery(event)


        print(file_name)
        try:
            run_forecast_adjustment(file_name, guid)
 
            delete_forecast_data()
            print(guid," : ",f"LATEST DATA DELETED")

            call_cloud_run_service(file_name,guid)
            print(guid," : REFRESH COMPLETE")

            # parse_param(file_name)
            # print(f"ROLLBACK  COMPLETE")



        except Exception as e:
            print(guid," : ",e)
            release_lock('ADJUSTMENT INIT', 'FAILED', guid)
            print(guid," : LOCK UPDATED")

            push_to_topic(file_name=guid,status="FAILED")
            send_email(file_name,'FAILED')
            
            move_to_archive(event)
            print("FAILURE EMAIL SENT")

            return 500


        # print("DELETE FEATURE TABLE")
        # delete_table(get_filename_ext(file_name))
    except Exception as e:
        print(guid," : ",e)
        release_lock('ADJUSTMENT INIT', 'FAILED', guid)
        print(guid," : LOCK UPDATED")

        push_to_topic(file_name=guid,status="FAILED")
        send_email(file_name,'FAILED')
        
        move_to_archive(event)
        print("FAILURE EMAIL SENT")

        return 500    

    

    release_lock('ADJUSTMENT INIT', 'SUCCESS', guid)
    print(guid," : LOCK UPDATED")
    push_to_topic(file_name=guid,status="SUCCESS")
    send_email(file_name, 'SUCCEEDED')
    print(guid," : SUCCESS EMAIL SENT")
    move_to_archive(event)

    return 200


# def get_identity_token(url):
#     credentials, _ = google.auth.default()
#     auth_request = Request()
#     target_audience = url
#     idt = id_token.fetch_id_token(auth_request, target_audience)
#     return idt


def call_gcloud_url(url,identity_token):
    try:

        # identity_token = "eyJhbGciOiJSUzI1NiIsImtpZCI6ImMzYWJlNDEzYjIyNjhhZTk3NjQ1OGM4MmMxNTE3OTU0N2U5NzUyN2UiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiIzMjU1NTk0MDU1OS5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSIsImF1ZCI6IjMyNTU1OTQwNTU5LmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwic3ViIjoiMTE1MjkwNjU4MTIxNjY3MTAxOTU0IiwiaGQiOiJsb3JlYWwuY29tIiwiZW1haWwiOiJzdGVsdWppbi5uZWR1bmdvdHR1QGxvcmVhbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiYXRfaGFzaCI6ImZZNWFOUUwza1d3UkJOVjcwUFptaEEiLCJpYXQiOjE3MTg2OTAzOTYsImV4cCI6MTcxODY5Mzk5Nn0.gWz0rkMQt15FmojCsWtkWAyXrr5HTCs-OZoJ2O0p9uXNtwmdb0optiYfF9xndryhRgdFtXVG6m3zUVLUFDPI4qPis75GR6cO_l6Rgs8HRwRTWF80a13i03IYQXKrtcCpujsKbHU0iDha4eH7BQPLzEymsXVgY7rpmQ1C-2irGPlGkFdxXRa4ZqetVa-WJ_75uH0R3ri8uVkCCaSFh3HTEhBureR9KUREkWhD0RPRIVf74mql720HzWoTJ3PNxyo2yZqggx-3WOoC73sVbRi1cQdZveNfZPcyEaNbPO_b1eMOw8wSQbkpfTG646yDlnnL7sO4PzxBO5Ko7efCNcEzaQ"
        command = f'curl  --insecure -H "Authorization: Bearer {identity_token}" "{url}"'
        print(url)

        result = subprocess.run(command, shell=True, capture_output=True, text=True)

        # print("Response Output:", result.stdout)
        # if result.stderr :
        # print(result.stderr)
        return {"status_code": result.returncode}

    except Exception as e:
        print("Error Output:", result.stderr)
        print(e)
        return {"status_code": e}



def call_gcloud_cf_url(url,identity_token):
    try:

        # identity_token = "eyJhbGciOiJSUzI1NiIsImtpZCI6ImMzYWJlNDEzYjIyNjhhZTk3NjQ1OGM4MmMxNTE3OTU0N2U5NzUyN2UiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiIzMjU1NTk0MDU1OS5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSIsImF1ZCI6IjMyNTU1OTQwNTU5LmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwic3ViIjoiMTE1MjkwNjU4MTIxNjY3MTAxOTU0IiwiaGQiOiJsb3JlYWwuY29tIiwiZW1haWwiOiJzdGVsdWppbi5uZWR1bmdvdHR1QGxvcmVhbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiYXRfaGFzaCI6ImZZNWFOUUwza1d3UkJOVjcwUFptaEEiLCJpYXQiOjE3MTg2OTAzOTYsImV4cCI6MTcxODY5Mzk5Nn0.gWz0rkMQt15FmojCsWtkWAyXrr5HTCs-OZoJ2O0p9uXNtwmdb0optiYfF9xndryhRgdFtXVG6m3zUVLUFDPI4qPis75GR6cO_l6Rgs8HRwRTWF80a13i03IYQXKrtcCpujsKbHU0iDha4eH7BQPLzEymsXVgY7rpmQ1C-2irGPlGkFdxXRa4ZqetVa-WJ_75uH0R3ri8uVkCCaSFh3HTEhBureR9KUREkWhD0RPRIVf74mql720HzWoTJ3PNxyo2yZqggx-3WOoC73sVbRi1cQdZveNfZPcyEaNbPO_b1eMOw8wSQbkpfTG646yDlnnL7sO4PzxBO5Ko7efCNcEzaQ"
        command = f'curl  -m 310 -X POST {url} -H "Authorization: Bearer {identity_token}" -H "Content-Type: application/json" -d "{"{}"}"'
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        print(url)

        # print("Response Output:", result.stdout)
        # if result.stderr :
        # print(result.stderr)
        return {"status_code": result.returncode}

    except Exception as e:
        print("Error Output:", result.stderr)
        print(e)
        return {"status_code": e}



def call_cloud_run_service(file_name, guid):
    response = []
    audience = gcloud_run_url


    
    identity_token = get_id_token(audience)
    access_token = get_access_token()

    print(guid," : 1")    
    response.append(call_gcloud_url(CLOUD_RUN_URL, identity_token))
    
    with concurrent.futures.ThreadPoolExecutor() as executor:
       futures = [
           executor.submit(call_gcloud_url, CLOUD_RUN_BOM_D_URL, identity_token),
           executor.submit(call_gcloud_url, CLOUD_RUN_BOM_M_URL, identity_token),
        #    removing the below table, as it is converted into a view
        #    executor.submit(call_gcloud_url, CLOUD_RUN_KPI_URL, identity_token)
       ]
       for i, future in enumerate(concurrent.futures.as_completed(futures), start=2):
           print(guid," : ",i)
           response.append(future.result())
    print(guid," : ",4)
    response.append(call_gcloud_url(CLOUD_RUN_BOM_FH_M_URL, identity_token))
    print(guid," : ","RESPONSE COMPLETE")
    try:
        for i in response:
            print(guid," : ",i["status_code"])
            if i["status_code"] == 500:
                insert_audit_row(batch_id=guid, job_id=3, job_name='Full Refresh', status='FAILED',
                                 file_name=file_name, guid=guid)
                return f'Error: 500', 500
        print(guid," : ","END CLOUD RUN LOOP")
        call_gcloud_cf_url(FM_CF_CLOUD_RUN_URL, get_id_token(FM_CF_CLOUD_RUN_URL))
        print(guid," : ","FM PUSHED")
        insert_audit_row(batch_id=guid, job_id=3, job_name='Full Refresh', status='SUCCESS',
                         file_name=file_name, guid=guid)
                         



        return response, 200
    except Exception as e:
        print("CLOUD STATUS FAILED", e)
        return response, 500


def acquire_lock(batch_id, job_id, job_name, status, file_name):
    client = bigquery.Client()
    table_id = AUDIT_DATASET  # Replace with your table ID
    print(batch_id," : LOCK ACQUIRE INITIATED")
    while True:
        query = f"""
            SELECT * FROM `{table_id}` WHERE status = 'LOCKED' AND TIMESTAMP_DIFF(current_timestamp(), jon_run_ts, MINUTE) < 30
        """
        query_job = client.query(query)
        results = list(query_job.result())

        if len(results) > 0:
            print(batch_id," : WAITING to acquire LOCK")
            time.sleep(60)
            print(batch_id," : RETRYING")
            continue

        # Acquire lock
        # rows_to_insert = [
        #     {"lock_id": uuid.uuid4().hex, "job_name": job_name, "status": "processing", "locked_at": datetime.datetime.utcnow()}
        # ]
        rows_to_insert = [
                {
                    "batch_id": batch_id,
                    "job_id": job_id,
                    "file_name": file_name,
                    "job_name": "ADJUSTMENT INIT",
                    "job_type": file_name.split("_")[-2],
                    "term": file_name.split("_")[-3],
                    "frequency": file_name.split("_")[-1],
                    "status": "LOCKED",
                    "jon_run_ts": datetime.utcnow().isoformat()
                }
            ]

        # errors = client.insert_rows_json(table_id, rows_to_insert)
        insert_values = ", ".join([f"('{row['batch_id']}', {row['job_id']}, '{row['file_name']}', '{row['job_name']}', '{row['job_type']}', '{row['term']}', '{row['frequency']}', '{row['status']}', '{row['jon_run_ts']}')" for row in rows_to_insert])

        # Construct the SQL query to insert data
        query = f"""
            INSERT INTO `{table_id}` (batch_id, job_id, file_name, job_name, job_type, term, frequency, status, jon_run_ts)
            VALUES {insert_values}
        """

        # Run the query

        query_job = client.query(query)

        # Wait for the query to complete
        query_job.result()



        # if errors:
        #     raise Exception(f"Error inserting lock: {errors}")
        return True


def insert_audit_row(batch_id, job_id, job_name, status, file_name, guid):
    client = bigquery.Client()

    table_id = AUDIT_DATASET  # Replace with your table ID
    file_name = file_name.split(".")[0]
    # Prepare the row to insert
    rows_to_insert = [
        {
            "batch_id": guid,
            "job_id": job_id,
            "file_name": file_name,
            "job_name": job_name,
            "job_type": file_name.split("_")[-2],
            "term": file_name.split("_")[-3],
            "frequency": file_name.split("_")[-1],
            "status": status,
            "jon_run_ts": datetime.utcnow().isoformat()
        }
    ]
    try:

        # errors = client.insert_rows_json(table_id, rows_to_insert)
        insert_values = ", ".join([f"('{row['batch_id']}', {row['job_id']}, '{row['file_name']}', '{row['job_name']}', '{row['job_type']}', '{row['term']}', '{row['frequency']}', '{row['status']}', '{row['jon_run_ts']}')" for row in rows_to_insert])

        # Construct the SQL query to insert data
        query = f"""
            INSERT INTO `{table_id}` (batch_id, job_id, file_name, job_name, job_type, term, frequency, status, jon_run_ts)
            VALUES {insert_values}
        """

        # Run the query
        query_job = client.query(query)

        # Wait for the query to complete
        query_job.result()

    except Exception as e:
        print("Encountered errors while inserting rows: {}".e)
    

def release_lock(job_name, status,guid):
    client = bigquery.Client()
    table_id = AUDIT_DATASET  # Replace with your table ID

    query = f"""
        UPDATE `{table_id}` SET status = '{status}'  WHERE batch_id='{guid}' and  job_name = 'ADJUSTMENT INIT' AND status = 'LOCKED'
    """
    query_job = client.query(query)
    result_val = query_job.result()

def delete_table( table_id):
    client = bigquery.Client(project=PROJECT_ID)

    # Construct a full table ID
    table_full_id = f"{PROJECT_ID}.{BQ_DATASET_ID}.{table_id}"

    try:
        client.delete_table(table_full_id)
        print(f"Deleted table '{table_full_id}'.")
    except Exception as e:
        print(f"Failed to delete table '{table_full_id}': {e}")


def delete_forecast_data():
    client = bigquery.Client()

    queries = [
        f"""
        DELETE FROM `{project_id}.cds_unecorn_process_zn.fact_monthly_fh_forecast`
        WHERE forecast_gen_date = (SELECT MAX(forecast_gen_date) FROM `{project_id}.cds_unecorn_process_zn.fact_monthly_fh_forecast`)
        and active_month_flag = 1
        and active_version_flag = 1
        """,
        f"""
        DELETE FROM `{project_id}.cds_unecorn_process_zn.fact_daily_forecast_explosion`
        WHERE forecast_gen_date = (SELECT MAX(forecast_gen_date) FROM `{project_id}.cds_unecorn_process_zn.fact_daily_forecast_explosion`)
        and active_month_flag = 1
        and active_version_flag = 1
        """,
        f"""
        DELETE FROM `{project_id}.cds_unecorn_process_zn.fact_monthly_forecast_explosion`
        WHERE forecast_gen_date = (SELECT MAX(forecast_gen_date) FROM `{project_id}.cds_unecorn_process_zn.fact_monthly_forecast_explosion`)
        and active_month_flag = 1
        and active_version_flag = 1
        """,
        f"""
        DELETE FROM `{project_id}.cds_unecorn_process_zn.fact_monthly_fh_forecast_explosion`
        WHERE forecast_gen_date = (SELECT MAX(forecast_gen_date) FROM `{project_id}.cds_unecorn_process_zn.fact_monthly_fh_forecast_explosion`)
        and active_month_flag = 1
        and active_version_flag = 1
        """
    ]

    for query in queries:
        query_job = client.query(query)  # Make an API request.
        query_job.result()  # Wait for the job to complete.

    print("BOM Deletion queries executed successfully.")




def send_ping_to_topic( topic_id, message):
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(PROJECT_ID, topic_id)

    try:
        # Data must be a bytestring
        data = message.encode("utf-8")
        future = publisher.publish(topic_path, data)
        print(f"Published message ID: {future.result()}")
    except Exception as e:
        print(f"Failed to publish message to topic '{topic_id}': {e}")


def generate_html_content(file_name, file_location, current_time, status, status_msg, email_from_name):
    color = "#4CAF50" if status == "Success" else "#E91E63"  # Green for success, red for failure

    html_content = f"""
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Forecast Adjustment {status}</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                color: #333;
                margin: 0;
                padding: 0;
                background-color: #f4f4f4;
            }}
            .container {{
                width: 80%;
                max-width: 600px;
                margin: 0 auto;
                background-color: #fff;
                padding: 20px;
                border-radius: 10px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }}
            .header {{
                background-color: {color};
                color: #fff;
                padding: 10px;
                text-align: center;
                border-radius: 10px 10px 0 0;
            }}
            .content {{
                padding: 20px;
            }}
            .content p {{
                line-height: 1.6;
            }}
            .file-details {{
                margin-top: 20px;
            }}
            .file-details table {{
                width: 100%;
                border-collapse: collapse;
            }}
            .file-details th, .file-details td {{
                text-align: left;
                padding: 8px;
                border-bottom: 1px solid #ddd;
            }}
            .footer {{
                margin-top: 20px;
                text-align: center;
                font-size: 0.9em;
                color: #777;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Forecast Adjustment {status}</h1>
            </div>
            <div class="content">
                <p>Dear User,</p>
                <p>We {status_msg} to inform you that forecast adjustment for '<strong>{file_name}</strong>' submitted on <strong>{current_time}</strong> has {status}.</p>
                <div class="file-details">
                    <h3>File Details:</h3>
                    <table>
                        <tr>
                            <th>File Name:</th>
                            <td>{file_name}</td>
                        </tr>
                        <tr>
                            <th>File Location:</th>
                            <td>{file_location}</td>
                        </tr>
                    </table>
                </div>
                <p>We kindly request you to review the file if needed.</p>
                <p>Thank you for your attention to this matter.</p>
                <p>Best regards,</p>
                <p><strong>{email_from_name}</strong></p>
            </div>
            <div class="footer">
                &copy; 2024 L'Oréal. All rights reserved.
            </div>
        </div>
    </body>
    </html>"""
    return html_content



# def send_email_btdp:
#     file_name = str(file_name.split('/')[-1].split('.')[0] + '.csv')
#     invalid_table_csv = export_table_to_csv()

#     current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
#     file_location = file_name
#     # Define the scope required for the OAuth token
#     scope = ["https://www.googleapis.com/auth/cloud-platform"]


#     # Encode the HTML content to base64
#     encoded_html_content = base64.b64encode(html_content.encode('utf-8')).decode('utf-8')

#     try:
#         # Obtain default credentials and refresh the token
#         # creds, _ = default()
#         # creds.refresh(Request())
#         # access_token = creds.token
#         creds, project = google.auth.default()
#         auth_req = google.auth.transport.requests.Request()
#         creds.refresh(auth_req)
#         access_token = creds.token
#     except (DefaultCredentialsError, RefreshError) as e:
#         logging.warning(f"Failed to retrieve or refresh credentials: {e}")
#         return "Authentication error", 500

#     api_url = "https://api.loreal.net/global/it4it/btdp-notification/v1/notifications/email"

#     if not access_token:
#         raise Exception("Access token not provided")

#     # Define headers and payload
#     headers = {
#         "Authorization": f"Bearer {access_token}",
#         "Content-Type": "application/json",
#     }

#     # recipients = ["prakhar.shanker@nagarro.com","prakhar.shanker@loreal.com"]
#     recipients = ["stelujin.nedungottu@loreal.com"]
#     subject = f"Data Validation Failure: Manual File '{file_name}'"
#     body = f"Dear User,\n\nWe regret to inform you that the manual file '{file_name}' submitted for validation on {current_time} has failed the data validation process.\n\nFile Details:\n\nFile Name: {file_name}\nFile Location: {file_location}\n\nWe kindly request you to review the file and make necessary corrections in the next 48 hours before resubmitting it for validation.\n\nThank you for your attention to this matter.\n\nBest regards,\n{EMAIL_FROM_NAME}"
#     attachments = [
#         {
#             "file_name": "example.html",
#             "file_type": "text/html",
#             "file_content": encoded_html_content
#         },
#         {

#             "file_name": "invalid_table.csv",
#             "file_type": "text/csv",
#             "file_content": invalid_table_csv

#         }
#     ]

#     payload = [{
#         "to": recipients,
#         "subject": subject,
#         "content": html_content
#     }]

#     print(payload)
#     print(access_token)
#     response = requests.post(api_url, headers=headers, json=payload)
#     # Log the response content and status code
#     print(f"API response: {response.content.decode('utf-8')}")
#     print(f"API response status code: {response.status_code}")
#     print(response.content, response.status_code)
#     return response.content, response.status_code


def send_email(file_name, status):
    to_emails = TO_EMAIL


    current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    file_location = file_name
    if status == 'SUCCEEDED':
        status_msg = 'are happy'
    else :
        status_msg = 'regret'
    subject = f"Forecast Adjustment {status} For File '{file_name}'"
    message = f"Dear User,\n\nWe {status_msg} to inform you that forecast adjustment for  '{file_name}'  submitted on {current_time} has {status}.\n\nFile Details:\n\nFile Name: {file_name}\nFile Location: {file_location}\n\nWe kindly request you to review the file if needed.\n\nThank you for your attention to this matter.\n\nBest regards,\n{EMAIL_FROM_NAME}"

    html_content = generate_html_content(file_name, file_location, current_time, status, status_msg, 'UNECORN FORECAST ADJUSTMENT MODULE ')
    scope = ["https://www.googleapis.com/auth/cloud-platform"]

    # for to_email in to_emails:
    #     # Create the email message
    #     msg = MIMEMultipart()
    #     msg['From'] = f"{EMAIL_FROM_NAME} <{FROM_EMAIL_ADDRESS}>"
    #     msg['To'] = to_email
    #     msg['Subject'] = subject
    #     msg.attach(MIMEText(message, 'plain'))

    #     # Attach the invalid table CSV file


    #     try:
    #         # Send the email
    #         server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
    #         server.starttls()
    #         server.login(SMTP_USERNAME, SMTP_PASSWORD)
    #         text = msg.as_string()
    #         server.sendmail(FROM_EMAIL_ADDRESS, to_email, text)
    #         server.quit()
    #         print(f"Email sent successfully to {to_email}!")
    #     except Exception as e:
    #         print("Error sending email to", to_email, ":", str(e))
    encoded_html_content = base64.b64encode(html_content.encode('utf-8')).decode('utf-8')

    try:
        # Obtain default credentials and refresh the token
        # creds, _ = default()
        # creds.refresh(Request())
        # access_token = creds.token
        creds, project = google.auth.default()
        auth_req = google.auth.transport.requests.Request()
        creds.refresh(auth_req)
        access_token = creds.token
    except (DefaultCredentialsError, RefreshError) as e:
        logging.warning(f"Failed to retrieve or refresh credentials: {e}")
        return "Authentication error", 500

    api_url = "https://api.loreal.net/global/it4it/btdp-notification/v1/notifications/email"

    if not access_token:
        raise Exception("Access token not provided")

    # Define headers and payload
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }

    # recipients = ["prakhar.shanker@nagarro.com","prakhar.shanker@loreal.com"]
    recipients = to_emails
    body = message
    attachments = [
        {
            "file_name": "example.html",
            "file_type": "text/html",
            "file_content": encoded_html_content
        }
    ]

    payload = [{
        "to": recipients,
        "sender": "unecorn-noreply@data-platform.beauty.tech",
        "subject": subject,
        "content": html_content
    }]

    response = requests.post(api_url, headers=headers, json=payload)
    # Log the response content and status code
    print(response.content, response.status_code)
    return response.content, response.status_code


# CHECK PUBLISHER

# Publisher function
def publish_to_topic(project_id, topic_id, message):
    """Publishes a message to a Pub/Sub topic."""
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(project_id, topic_id)
    data = json.dumps(message).encode("utf-8")
    future = publisher.publish(topic_path, data)
    return future.result()

# Subscriber function
def push_to_topic(file_name,status):
    try:

        # Log the received message
        print(f"PUSH INITIATED : {status}")

        # Process the received message
        new_message = {
            "guid": file_name.split("_")[0],
            "status": "ADJUSTMENT_SUCCESS" if status=='SUCCESS'  else "ADJUSTMENT_FAILED",
            "created_at": datetime.utcnow().isoformat() + "Z"
        }

        # Publish the new message to the same topic

        message_id = publish_to_topic(PROJECT_ID, TOPIC_ID, new_message)

        # Log the published message
        print(f"Published message with ID: {message_id}")



    except Exception as e:
        print(f"An error occurred: {e}")

def create_table_if_not_exists(client, table_id):
    # Define table schema for the log_forecast_adjustment_history table
    schema = [
        bigquery.SchemaField("forecast_version", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("forecast_DWM", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("country_code", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("platform_code", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("signature_code", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("category", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("group", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("ean_code", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("ean_description", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("hero_type", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("lifecycle", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("ai_model_forecast", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("consensus_forecast", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("comments_consensus", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("validated_forecast", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("comments_validated", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("batch_id", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("status", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("run_timestamp", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("file_type", "STRING", mode="NULLABLE"),
    ]

    # Check if the table already exists
    try:
        client.get_table(table_id)  # API request
        print(f"Table {table_id} already exists.")
    except Exception:
        # If table does not exist, create it
        table = bigquery.Table(table_id, schema=schema)
        table = client.create_table(table)  # API request
        print(f"Created table {table_id}.")


def get_forecast_type_and_column(table_name):
    # Determine the frequency type and corresponding column based on table name suffix
    if table_name.endswith('_D'):
        return 'daily', 'forecast_date'
    elif table_name.endswith('_W'):
        return 'weekly', 'forecast_week'
    elif table_name.endswith('_M'):
        return 'monthly', 'forecast_month'
    else:
        raise ValueError(f"Invalid table name format: {table_name}")

def insert_forecast_to_log( source_table_name, log_table_name, batch_id, file_name, file_type, status):
    # Ensure the log table exists
    client = bigquery.Client()
    create_table_if_not_exists(client, log_table_name)
    
    # Get the current timestamp
    run_timestamp = datetime.utcnow()

    # Determine forecast type and corresponding column based on table name
    forecast_type, forecast_column = get_forecast_type_and_column(source_table_name)

    # Construct the SQL query to select from the source and insert into the log table
    query = f"""
    INSERT INTO `{log_table_name}`
    (
        forecast_version,
        forecast_DWM,
        country_code,
        platform_code,
        signature_code,
        category,
        `group`,
        ean_code,
        ean_description,
        hero_type,
        lifecycle,
        ai_model_forecast,
        consensus_forecast,
        comments_consensus,
        validated_forecast,
        comments_validated,
        batch_id,
        status,
        run_timestamp,
        file_type
    )
    SELECT
        forecast_version,
        CAST({forecast_column} AS STRING) AS forecast_DWM,
        country_code,
        platform_code,
        signature_code,
        category,
        `group`,
        ean_code,
        ean_description,
        hero_type,
        lifecycle,
        ai_model_forecast,
        consensus_forecast,
        comments_consensus,
        validated_forecast,
        comments_validated,
        '{batch_id}' AS batch_id,
        '{status}' AS status,
        '{run_timestamp}' AS run_timestamp,
        '{file_type}' AS file_type
    FROM `{PROJECT_ID}.{BQ_DATASET_ID}.{source_table_name}`
    """

    # Run the query in batches (BigQuery does this natively)
    query_job = client.query(query)

    # Wait for the job to complete
    query_job.result()

    print(f"Data from {source_table_name} successfully inserted into {log_table_name}.")

# Example usage:



