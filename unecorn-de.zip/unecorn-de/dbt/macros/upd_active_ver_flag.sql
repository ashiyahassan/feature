{% macro upd_active_ver_flag(dataset_name, table_name) %}
{% set project_id = target.project %}


{% if execute and is_incremental() %}
  
    {{ print("Running active_version_macro: "~ dataset_name ~", "~ table_name~","~project_id) }}
    EXECUTE IMMEDIATE ''' UPDATE `{{ project_id }}.{{ dataset_name }}.{{ table_name }}` AS t
        SET active_version_flag = CASE
            WHEN EXISTS (
                
                SELECT 1
                FROM (
                    SELECT forecast_gen_date, MAX(load_ts) AS latest_load_ts
                    FROM `{{ project_id }}.{{ dataset_name }}.{{ table_name }}`
                    GROUP BY forecast_gen_date
                ) AS sub
                WHERE t.forecast_gen_date = sub.forecast_gen_date AND t.load_ts = sub.latest_load_ts
            ) THEN 1
            ELSE 0
            END
                  WHERE t.forecast_gen_date IN (
            SELECT forecast_gen_date
            FROM (
                SELECT forecast_gen_date, MAX(load_ts) AS latest_load_ts
                FROM `{{ project_id }}.{{ dataset_name }}.{{ table_name }}`
                GROUP BY forecast_gen_date
            ) AS sub
        )
    '''
   
{% endif %}
{{ print("completed active_version_macro: ") }}
{% endmacro %}