{{ config(materialized='table') }}

WITH source_data AS (
    SELECT * FROM {{ref('pnl_actual_2024')}}
    UNION ALL
    SELECT * FROM {{ref('pnl_pre_budget_2025')}}
    UNION ALL
    SELECT * FROM {{ref('pnl_actual_2026')}}
)

SELECT *, CURRENT_TIMESTAMP() AS load_ts FROM source_data