{{ config(materialized='view') }}

WITH file_version_data AS (      
      SELECT 
        file_version,
        version_month,
        client 
      FROM 
      (
        SELECT 
          *, 
          ROW_NUMBER() OVER(PARTITION BY version_month, client ORDER BY file_version DESC) AS row_num
        FROM
        (
          SELECT DISTINCT
            file_version,
            version_month,
            client
          FROM {{db_source('src_campaign','vw_non_optimus_promo_planning_online_v2')}} AS voucher
          WHERE voucher.country IN {{variable_macro('country_var')}}
          AND voucher.online_offline = {{variable_macro('online_var')}}
          AND voucher.division IN {{variable_macro('division_var')}}
          AND voucher.client IN {{variable_macro('platform_var')}}
        )
      )
      WHERE row_num = 1
),
source_data AS (
    SELECT 
      CAST(voucher.version_month AS INT64) AS version_month,
      voucher.file_version,
      CAST(NULL AS STRING) AS attributes,
      year,
      month,
      promo_duration,
      CAST(start_date AS DATE) AS start_date,
      CAST(end_date AS DATE) AS end_date,
      voucher.client,
      country,
      online_offline,
      channel,
      signature,
      brand,
      franchise_sub_brand,
      category,
      sub_category,
      forecasting_line,
      product_name,
      ean_code,
      retailer_product_id AS product_id,
      sap_sku_code AS sap_material_code,
      retailer_product_model_id AS seller_code,
      product_type,
      single_bundle,
      division AS budget_owner,
      promo_name,
      campaign_type1,
      campaign_type2,
      promo_tactic AS promo_mechanics,
      CAST(NULL AS STRING) AS promo_mechanics_detail1,
      CAST(NULL AS STRING) AS promo_mechanics_detail2,
      promo_event AS promo_type,
      CAST(NULL AS STRING) AS consumer_group,
      rsp,
      promo_price,
      promo_discount_percentage,
      scheme_discount_percentage,
      CAST(NULL AS FLOAT64) AS promo_discount_value,
      minimum_spend_value,
      type_of_voucher,
      CAST(scheme_redemption_period_start_date AS DATE) AS redemption_period_start_date,
      CAST(scheme_redemption_period_end_date AS DATE) AS redemption_period_end_date,
      CAST(cap_order AS STRING) AS cap_order,
      type_of_allowance,
      CAST(NULL AS STRING) AS promo_basis,
      CAST(NULL AS STRING) AS unit_cost_of_promo,
      CAST(NULL AS STRING) AS compensation_condition,
      CAST(NULL AS STRING) AS display_type,
      CAST(NULL AS FLOAT64) AS sellout_baseline_unit_forecast,
      CAST(NULL AS FLOAT64) AS sellout_baseline_value_forecast,
      CAST(NULL AS FLOAT64) AS sellout_promo_units_actual,
      CAST(NULL AS FLOAT64) AS sellout_promo_value_actual,
      CAST(scheme_issued_quantity AS STRING) AS issued_quantity,
      '0' AS redemption_quantity_percentage,
      CAST(NULL AS STRING) AS real_usage_quota,
      file_name,
      insert_timestamp,
      update_timestamp
    FROM {{db_source('src_campaign','vw_non_optimus_promo_planning_online_v2')}} AS voucher
    INNER JOIN file_version_data AS f_version
    ON voucher.file_version = f_version.file_version
    AND voucher.version_month = f_version.version_month
    AND voucher.client = f_version.client
    WHERE voucher.country IN {{variable_macro('country_var')}}
    AND voucher.online_offline = {{variable_macro('online_var')}}
    AND voucher.division IN {{variable_macro('division_var')}}
    AND voucher.client IN {{variable_macro('platform_var')}}
    AND voucher.year IS NOT NULL
    AND voucher.month IS NOT NULL
)

SELECT * FROM source_data