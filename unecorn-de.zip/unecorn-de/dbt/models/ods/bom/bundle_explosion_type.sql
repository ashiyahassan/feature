{{ config(materialized='table') }}

WITH source_data AS (
    SELECT 1 AS bundle_sk, 'Single' AS bundle_type, 'PB+Single' AS bundle_explosion
    UNION ALL
    SELECT 2 AS bundle_sk, 'Single' AS bundle_type, 'Single' AS bundle_explosion
    UNION ALL
    SELECT 3 AS bundle_sk, 'PB' AS bundle_type, 'PB+Single' AS bundle_explosion
    UNION ALL
    SELECT 4 AS bundle_sk, 'Single' AS bundle_type, 'Single+PB+VB' AS bundle_explosion
    UNION ALL
    SELECT 5 AS bundle_sk, 'Single' AS bundle_type, 'VB+Single' AS bundle_explosion
    UNION ALL
    SELECT 6 AS bundle_sk, 'PB' AS bundle_type, 'Single+PB+VB' AS bundle_explosion
    UNION ALL
    SELECT 7 AS bundle_sk, 'VB' AS bundle_type, 'VB+Single' AS bundle_explosion
    UNION ALL
    SELECT 8 AS bundle_sk, 'VB' AS bundle_type, 'Single+PB+VB' AS bundle_explosion
)

SELECT * FROM source_data