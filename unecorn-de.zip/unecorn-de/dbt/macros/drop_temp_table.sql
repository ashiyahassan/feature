{% macro drop_temp_table(dataset_name, table_name) %}

{% set project_id = target.project %}
-- {% set dataset_id = dataset_name %}
{{ print("Running some_macro: "~ dataset_name ~", "~ table_name) }}
{% if execute %}

  EXECUTE IMMEDIATE 'DROP TABLE IF EXISTS `{{ project_id }}.{{ dataset_name }}.{{ table_name }}`'

{% endif %}

{% endmacro %}
