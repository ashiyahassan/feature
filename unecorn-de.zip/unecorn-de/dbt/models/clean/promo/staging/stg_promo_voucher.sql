WITH stg_valid_promo_voucher AS (
    SELECT promo.version_month,
    promo.year,
    promo.month,
    promo.promo_duration,
    (CASE WHEN promo.client IN {{variable_macro('shopee_var')}} THEN {{variable_macro('shopee_vn_var')}}
    WHEN promo.client In {{variable_macro('lazada_var')}} THEN {{variable_macro('lazada_vn_var')}}
    WHEN promo.client IN {{variable_macro('tiktok_var')}} THEN {{variable_macro('tiktok_vn_var')}}
    ELSE promo.client END) AS marketplace_code,
    promo.country,
    (CASE WHEN promo.signature IN {{variable_macro('mbl_brand_var')}} THEN {{variable_macro('mbl_var')}}
    WHEN promo.signature IN {{variable_macro('oap_brand_var')}} THEN {{variable_macro('oap_var')}}
    WHEN promo.signature IN {{variable_macro('grn_brand_var')}} THEN {{variable_macro('grn_var')}}
    WHEN promo.signature IN {{variable_macro('3ce_brand_var')}} THEN {{variable_macro('3ce_var')}}
    ELSE promo.signature END) AS signature_code,
    (CASE WHEN promo.brand IN {{variable_macro('mbl_brand_var')}} THEN {{variable_macro('mbl_var')}}
    WHEN promo.brand IN {{variable_macro('oap_brand_var')}} THEN {{variable_macro('oap_var')}}
    WHEN promo.brand IN {{variable_macro('grn_brand_var')}} THEN {{variable_macro('grn_var')}}
    WHEN promo.brand IN {{variable_macro('3ce_brand_var')}} THEN {{variable_macro('3ce_var')}}
    ELSE promo.brand END) AS brand_name,
    promo.product_name,
    promo.ean_code,
    promo.sap_material_code AS sku_code,
    promo.promo_name,    
    promo.campaign_type1,
    promo.campaign_type2,
    promo.budget_owner AS division,
    promo.online_offline,
    promo.promo_mechanics,
    promo.promo_mechanics_detail1,
    promo.promo_type,
    promo.rsp,
    promo.scheme_discount_percentage AS promo_discount_percentage,
    promo.minimum_spend_value,
    promo.type_of_voucher,
    promo.issued_quantity,
    promo.redemption_quantity_percentage,
    promo.compensation_condition,
    promo.display_type,
    promo.sellout_baseline_unit_forecast,
    promo.sellout_baseline_value_forecast,
    promo.real_usage_quota,
    promo.promo_discount_value,
    promo.start_date,
    promo.end_date,
    promo.file_name,
    promo.insert_timestamp AS created_date,
    promo.update_timestamp AS updated_date,
    CURRENT_TIMESTAMP() AS load_ts
    FROM {{ ref('int_promo_plan') }} AS promo
    WHERE promo.promo_mechanics = {{variable_macro('promo_voucher_var')}}
    -- AND promo.brand IS NOT NULL
    -- AND promo.ean_code IS NOT NULL )
)

SELECT * FROM stg_valid_promo_voucher