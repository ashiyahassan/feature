{{ config(materialized='table') }}

WITH source_data AS (
    SELECT *
    FROM {{ ref('stg_promo_voucher') }} 
)

SELECT * FROM source_data