{{ config(materialized='table') }}

WITH source_data AS (
    SELECT ean_code,
        brand_name AS brand_name,
        sub_brand_name AS sub_brand_name,
        category AS category_name,
        sub_category AS sub_category_name,
        `group` AS group_name,
        sub_group AS sub_group_name,
        axe_name AS axe_name,
        hero_type AS hero_lsp_non_hero,
        platform_code,
        platform_name,
        signature_code,
        signature_name,
        country_code,
        division_code AS division    
    FROM 
    {{ref('dim_product')}}
),
campaign_data AS (
    SELECT date_sk,
        campaign_type,
        campaign_sk,
        country_code,
        signature_code,
        platform_code,
        `year`,	
        `month`,
        `day`
    FROM
    {{ref('dim_campaign')}}
)

SELECT sd.* ,
    cd.campaign_sk,
    cd.campaign_type,
    cd.date_sk,
    cd.year,
    cd.month,
    CURRENT_TIMESTAMP() AS load_ts
FROM source_data AS sd 
LEFT JOIN campaign_data cd
ON  sd.platform_code = cd.platform_code 
    AND sd.signature_code = cd.signature_code 
    AND sd.country_code = cd.country_code 

