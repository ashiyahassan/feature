import os

location =  os.getenv('location') if os.getenv('location') is not None else "europe-west1"
try:
    project_id = os.getenv('project_id') if os.getenv('project_id') is not None else 'spmena-unecorn-zn-apac-dv' 
    
except:
    project_id = 'spmena-unecorn-zn-apac-dv'

ENV = project_id.split('-')[-1]
dataset_id = 'cds_unecorn_raw_zn'
invalid_table_id = 'dq_invalid_master_data_forecast_file_data'

TO_EMAIL = ['prakhar.shanker@loreal.com']
if ENV == 'pd': TO_EMAIL.append('APMENA-GCP-UNECORN-PRODUCT-VN-USER@loreal.com')
GCS_ARCHIVE_BUCKET_NAME = f"unecornde-audit-ew1-{ENV}"

EMAIL_FROM_NAME = "Loreal"
FROM_EMAIL_ADDRESS="no-reply@apmena-onedata-np.noreply.loreal.net"
api_url = "https://api.loreal.net/global/it4it/btdp-notification/v1/notifications/email"
