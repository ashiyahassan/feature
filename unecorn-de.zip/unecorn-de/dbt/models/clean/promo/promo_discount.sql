{{ config(materialized='table',
log_path='/logs/clean/promo/promos_discount/{{ model.name }}'
 )}}

WITH source_data AS (
    SELECT *
    FROM {{ ref('stg_promo_discount') }} 
)

SELECT * FROM source_data
