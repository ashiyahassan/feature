{%- macro variable_macro(variable) -%}

{#- filters variables -#}
{%- if variable =='country_var' -%} ('VN')
{%-elif variable =='division_var'-%} ('CPD')
{%-elif variable =='platform_var'-%} ('SHOPEE', 'LAZADA', 'SHOPEE_VN', 'LAZADA_VN','TIKTOK','TIKTOK_VN')
{%-elif variable =='platform_short_var'-%} ('SHP', 'LZD','TIKTOK')
{%-elif variable =='platform_country_var'-%} ('SHOPEE_VN', 'LAZADA_VN','TIKTOK_VN')
{%-elif variable =='bd_var'-%} 'BD'
{%-elif variable =='sbd_var'-%} 'SBD'
{%-elif variable =='bl_var'-%} 'BL'
{%-elif variable =='mg_var'-%} 'MG'
{%-elif variable =='smg_var'-%} 'SMG'
{%-elif variable =='cp_var'-%} 'CP'
{%-elif variable =='non_bl_var'-%} ('SMG','MG','CP')
{%-elif variable =='online_var'-%} 'ONLINE'
{%-elif variable =='virtual_bundle_var'-%} 'VIRTUAL BUNDLE'
{%-elif variable =='virtual_bundle_lower_var'-%} 'Virtual Bundle'
{%-elif variable =='bundle_var'-%} 'BUNDLE'
{%-elif variable =='bundle_lower_var'-%} 'Bundle'
{%-elif variable =='bau_var'-%} 'BAU'
{%-elif variable =='fs_var'-%} 'Fs'
{%-elif variable =='fs_s_var'-%} 's'
{%-elif variable =='fs_upper_var'-%} 'FS'
{%-elif variable =='non_fs_var'-%} 'Non FS'
{%-elif variable =='promo_scheme_var'-%} 'MultiBuy'
{%-elif variable =='promo_voucher_var'-%} 'Shopper Discount'
{%-elif variable =='promo_discount_var'-%} 'Promo Pricing'
{%-elif variable =='p54_var'-%} 'P54'
{%-elif variable =='elixpedia_var'-%} 'Elixpedia'
{%-elif variable =='apac_var'-%} '%_APAC'
{%-elif variable =='neo_var'-%} 'Neo'
{%-elif variable =='vie_var'-%} 'VIE'
{%-elif variable =='country_like_var'-%} '%VN%'
{%-elif variable =='country_var2'-%} ('VNM')
{%-elif variable =='location_var'-%} ('V001')
{%-elif variable =='sales_organization_var'-%} ('V200')
{%-elif variable =='shopee_var'-%} ('SHOPEE','SHP')
{%-elif variable =='shopee_vn_var'-%} 'SHOPEE_VN'
{%-elif variable =='lazada_var'-%} ('LAZADA','LZD')
{%-elif variable =='lazada_vn_var'-%} 'LAZADA_VN'
{%-elif variable =='tiktok_var'-%} ('TIKTOK','TIKTOK')
{%-elif variable =='tiktok_vn_var'-%} 'TIKTOK_VN'
{%-elif variable =='shp_var'-%} 'SHP'
{%-elif variable =='lzd_var'-%} 'LZD'
{%-elif variable =='tiktok_var'-%} 'TIKTOK'
{%-elif variable =='shp_like_var'-%} '%SHOPEE%'
{%-elif variable =='lzd_like_var'-%} '%LAZADA%'
{%-elif variable =='tiktok_like_var'-%} '%TIKTOK%'
{%-elif variable =='unit_list_price_var'-%} 'Unit list price'
{%-elif variable =='vietnam_var'-%} ('Vietnam')
{%-elif variable =='distribution_channel_var'-%} ('Y8')
{%-elif variable =='mbl_brand_var'-%} ('P5','MBL','Maybelline','MAYBELLINE')
{%-elif variable =='mbl_var'-%} ('MAYBELLINE')
{%-elif variable =='oap_brand_var'-%} ('P2','OAP','OAP2','L\'OREAL PARIS','L\'Oreal Paris','LOREAL PARIS','Loreal Paris')
{%-elif variable =='oap_var'-%} ('LOREAL PARIS')
{%-elif variable =='grn_brand_var'-%} ('P4','GRN','Garnier','GARNIER')
{%-elif variable =='grn_var'-%} ('GARNIER')
{%-elif variable =='p2_var'-%} 'P2'
{%-elif variable =='p4_var'-%} 'P4'
{%-elif variable =='p5_var'-%} 'P5'
{%-elif variable =='dist_channel_var'-%} ('D2C')
{%-elif variable =='operational_division_var'-%} ('1')
{%-elif variable =='operational_division_20_var'-%} ('20')
{%-elif variable =='location_gln_var'-%} ('Affiliate Vietnam')
{%-elif variable =='ecc_var'-%} 'ECC'
{%-elif variable =='hero_var'-%} 'HERO'
{%-elif variable =='super_hero_var'-%} 'SUPER-HERO'
{%-elif variable =='operational_division_20_var'-%} ('20')
{%-elif variable =='cpd_apac_var'-%} 'CPD_APAC'
{%-elif variable =='daily_var'-%} 'DAILY'
{%-elif variable =='monthly_var'-%} 'MONTHLY'
{%-elif variable =='vn_countryname_var' -%} ('Vietnam')
{%-elif variable =='shp_lower_var' -%} 'Shopee'
{%-elif variable =='lzd_lower_var' -%} 'Lazada'
{%-elif variable =='tiktok_lower_var' -%} 'Tiktok'
{%-elif variable =='lsp_var' -%} 'LSP'
{%-elif variable =='shp_upper_var' -%} 'SHOPEE'
{%-elif variable =='lzd_upper_var' -%} 'LAZADA'
{%-elif variable =='tiktok_upper_var' -%} 'TIKTOK'
{%-elif variable =='shp_vn_like_var'-%} '%SHOPEE_VN%'
{%-elif variable =='lzd_vn_like_var'-%} '%LAZADA_VN%'
{%-elif variable =='tiktok_vn_like_var'-%} '%TIKTOK_VN%'
{%-elif variable =='non_hero_var' -%} 'NON HERO'
{%-elif variable =='dummy_code_signature_var' -%} ('P2','P4','P5')
{%-elif variable =='sellout_source_var' -%} 'OMS_SFCC'
{%-elif variable =='3ce_brand_var'-%} ('PH','3CE','3ce','Stylenanda','stylenanda','STYLENANDA')
{%-elif variable =='3ce_var'-%} ('3CE')
{%-elif variable =='ph_var'-%} 'PH'
{%-elif variable =='oap_title_var'-%} 'L\'Oreal Paris'
{%-elif variable =='grn_title_var'-%} 'Garnier'
{%-elif variable =='mbl_title_var'-%} 'Maybelline'
{%- endif -%}
{%- endmacro -%}
