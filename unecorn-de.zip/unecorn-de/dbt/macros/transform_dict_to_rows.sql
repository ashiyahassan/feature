{% macro transform_dict_to_rows(column_dict) %}
    {% if not column_dict %}
        {{ return([]) }}
    {% endif %}

    {# Get all column names and the length of any column (they should all be the same length) #}
    {% set columns = column_dict.keys() %}
    {% set num_rows = column_dict[columns | list | first] | length %}
    
    {# Initialize result list #}
    {% set result = [] %}
    
    {# Create a row-wise dictionary for each index #}
    {% for i in range(num_rows) %}
        {% set row_dict = {} %}
        {% for column in columns %}
            {% do row_dict.update({column: column_dict[column][i]}) %}
        {% endfor %}
        {% do result.append(row_dict) %}
    {% endfor %}
    
    {{ return(result) }}
{% endmacro %}