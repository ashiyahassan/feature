{{ config(materialized='table') }}

WITH oms_product_platform AS (
    SELECT * FROM 
    (
        SELECT DISTINCT 
            country AS market_code, 
            marketplace_code, 
            ean_code, 
            sku_code AS sap_product_code, 
            product_status AS oms_platform_product_status, 
            source_load_ts AS load_ts, 
            ROW_NUMBER() OVER (
                PARTITION BY ean_code, 
                marketplace_code,
                country
                ORDER BY 
                source_load_ts DESC
            ) AS latest_record 
        FROM 
          {{ref('platform_product')}}
    )
    WHERE latest_record=1        
)


SELECT DISTINCT 
    OMS.ean_code, 
    OMS.marketplace_code, 
    OMS.oms_platform_product_status, 
    OMS.status_from_masterdata, 
    OMS.launch_date, 
    OMS.discontinuation_date, 
    MM_ST.mm_status, 
    SD_ST.sd_status,
    MM_ST.material_type,
    MM_ST.material_group, 
    --CASE WHEN sellout.ean_code IS NULL THEN 'NO' ELSE 'YES' END AS Sellout_status, 
    historical_flag.histroical_sales_flag ,
    CASE 
        WHEN sellout.ean_code IS NULL THEN 'out of scope' 
        WHEN sellout.ean_code IS NOT NULL THEN 'in scope' 
        ELSE 'ND' 
    END AS l_3_flag, 
    unecorn_status,
    CURRENT_TIMESTAMP() AS load_ts
---------------------------Latest record from OMS assortment(platform product) and join with masterdata forecast---------- 
FROM 
(
    SELECT DISTINCT  
        OMS_ASS.marketplace_code, 
        OMS_ASS.ean_code,
        oms_platform_product_status, 
        MS_Data.status AS status_from_masterdata, 
        launch_date, 
        discontinuation_date,
        unecorn_status,
    FROM 
    (
        SELECT * FROM oms_product_platform
    ) AS OMS_ASS 
    LEFT JOIN 
    (
        SELECT * 
        FROM {{ref('master_data_forecast_file_data')}} 
        WHERE active_status='Y'
    ) AS MS_Data 
    ON OMS_ASS.ean_code = MS_Data.ean_code 
    AND OMS_ASS.marketplace_code = MS_Data.marketplace_code 
     
    UNION ALL
    SELECT DISTINCT 
        MS_Data.marketplace_code, 
        MS_Data.ean_code, 
        'null' AS oms_platform_product_status, 
        MS_Data.status AS status_from_masterdata, 
        MS_Data.launch_date, 
        MS_Data.discontinuation_date,
        unecorn_status   
        FROM
        (
            SELECT * FROM oms_product_platform
        ) AS OMS_ASS 
        RIGHT JOIN 
        (
            SELECT * 
            FROM {{ref('master_data_forecast_file_data')}}  
            WHERE active_status='Y'
        ) AS MS_Data 
        ON OMS_ASS.ean_code = MS_Data.ean_code 
        AND OMS_ASS.marketplace_code = MS_Data.marketplace_code 
        WHERE OMS_ASS.ean_code IS NULL 
) AS OMS
----------------------------------------SD status ------------------------ 
LEFT JOIN 
(
    SELECT DISTINCT
        ean_code, 
        sap_sd_product_status AS sd_status, 
    FROM 
    (
        SELECT  
            ean_code, 
            sap_sd_product_status, 
            sku_code, 
            meta_validity_from, 
            meta_validity_to, 
            priority, 
            ROW_NUMBER() OVER (
              PARTITION BY ean_code 
              ORDER BY 
                priority ASC NULLS LAST, 
                meta_validity_from DESC NULLS LAST, 
                sku_code ASC NULLS LAST
            ) AS rank_sd_status 
        FROM 
        (
            SELECT 
                ean_code, 
                sd_status AS sap_sd_product_status, 
                sku_code, 
                meta_validity_from, 
                meta_validity_to, 
                priority 
            FROM 
            (
                SELECT DISTINCT
                    a.sku_code, 
                    a.ean_code, 
                    b.sd_status, 
                    b.meta_validity_from, 
                    b.meta_validity_to 
                FROM 
                  {{ref('sku_v1')}} AS a 
                INNER JOIN 
                (
                    SELECT 
                        sku_code, 
                        sd_status, 
                        sales_organization, 
                        distribution_channel, 
                        meta_validity_from, 
                        meta_validity_to 
                    FROM 
                      {{ref('sku_sales_area_v1')}}
                ) AS b 
                ON a.sku_code = b.sku_code 
                WHERE 
                    a.source_system = {{variable_macro('ecc_var')}}
                    AND a.a0939_operational_division IN {{variable_macro('operational_division_20_var')}} 
                    -- and b.sales_organization = 'V200' 
                    -- AND b.distribution_channel = 'Y8'
            ) AS t_sd_status 
            INNER JOIN {{ref('dim_lifecycle_status')}} ON sd_status = status_value 
            WHERE 
                status_type = 'SD'
        ) AS SD
    )        
    WHERE rank_sd_status = 1   
) AS SD_ST
ON OMS.ean_code = SD_ST.ean_code
-------------------------------------MM Status-------------------
LEFT JOIN 
(
    SELECT  DISTINCT
        ean_code, 
        --   sap_product_code,
        mm_status,
        material_type,
        material_group
    FROM 
    (
        SELECT 
            ean_code, 
            mm_status, 
            sku_code,
            material_type,
            material_group, 
            meta_validity_from, 
            meta_validity_to, 
            ROW_NUMBER() OVER (
              PARTITION BY ean_code 
              ORDER BY 
                priority ASC NULLS LAST, 
                meta_validity_from DESC NULLS LAST, 
                sku_code DESC NULLS LAST
            ) AS rank_mm_status 
        FROM 
        (
            SELECT 
                sku_code, 
                ean_code, 
                mm_status,
                material_type,
                material_group, 
                priority,
                meta_validity_from, 
                meta_validity_to 
            FROM 
            (
                SELECT DISTINCT
                    a.sku_code, 
                    a.ean_code, 
                    b.mm_status,
                    a.material_type,
                    a.material_group, 
                    b.meta_validity_from, 
                    b.meta_validity_to 
                FROM 
                    {{ref('sku_v1')}} AS a 
                INNER JOIN 
                (
                    SELECT 
                        sku_code, 
                        a1257_supply_entity, 
                        location_gln_description, 
                        mm_status, 
                        meta_validity_from, 
                        meta_validity_to 
                    FROM {{ref('sku_location_v2')}}
                ) AS b 
                ON a.sku_code = b.sku_code 
                WHERE 
                    a.source_system = {{variable_macro('ecc_var')}}
                    AND a.a0939_operational_division IN {{variable_macro('operational_division_20_var')}} 
                    -- AND b.a1257_supply_entity = 'V001' 
                    -- OR (
                    --   b.location_gln_description IN ('Affiliate Vietnam') 
                    --   OR b.location_gln_description LIKE ('%VN%')
                    --)
            ) AS t_mm_status 
            INNER JOIN {{ref('dim_lifecycle_status')}} ON mm_status = status_value 
            WHERE 
                status_type = 'MM'
        ) 
    ) 
    WHERE 
        rank_mm_status = 1
) AS MM_ST
ON OMS.ean_code = MM_ST.ean_code
        
-------------------------------------------last 3 year -----------------------------------------
LEFT JOIN 
(
    SELECT DISTINCT
        ean_code,
        marketplace_code    
    FROM 
        {{ref('sellout_d2c_v3')}}
    WHERE 
        sellout_year > 2020 
) AS Sellout 
ON OMS.ean_code = Sellout.ean_code AND  OMS.marketplace_code = Sellout.marketplace_code
----------------------Historical flag-----------------------------
LEFT JOIN 
(
    SELECT 
        ean_code,
        marketplace_code, 
        CASE 
            WHEN days_from_first_sell >= 90 THEN 'Y' 
            ELSE 'N' 
        END AS histroical_sales_flag
    FROM 
    (
        SELECT DISTINCT
            ean_code,
            marketplace_code,
            DATE_DIFF(DATE_TRUNC(CURRENT_DATE(),MONTH), MIN(sellout_date), DAY) AS days_from_first_sell   
        FROM 
            {{ref('sellout_d2c_v3')}}    
        GROUP BY
            ean_code, marketplace_code
    )
    GROUP BY ean_code,marketplace_code, days_from_first_sell
) AS historical_flag
ON OMS.ean_code = historical_flag.ean_code AND OMS.marketplace_code = historical_flag.marketplace_code
WHERE OMS.ean_code NOT IN (
    'GRP-6902395853930',
    'GRP-6902395854005',
    'GRP-8935274632683',
    'GRP-8935274634700',
    'GRP-8994993015160',
    'GRP-8994993016532',
    'GRP-6902395858539',
    'GRP-6902395498926',
    'GRP-6902395853275',
    'P21022AB',
    'P214302B',
    'P214302T',
    'P214521V',
    'P230281',
    '8935274612074',
    '8935274612128',
    '8935274606592'
)
ORDER BY 
    OMS.ean_code
