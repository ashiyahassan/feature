{{ config(materialized='table') }}

WITH source_data AS (
    SELECT
        bom_header_ean_code,
        bom_header_code,
        component_ean_code,
        component_code,
        m_factor,
        component_quantity,
        local_bom_type_description

    FROM {{ref('bom_explosion_factor')}}
)



SELECT *,        
CURRENT_TIMESTAMP() AS load_ts
FROM
source_data
