{{ config(materialized='view') }}

SELECT 
    a.*,
    b.mm_status 
FROM {{ref('bom_component_location')}} AS a
INNER JOIN
(
    SELECT DISTINCT 
        sku_code,
        mm_status 
    FROM
    (
        SELECT DISTINCT  
            a.sku_code,
            b.mm_status ,
            ROW_NUMBER() OVER (PARTITION BY a.ean_code ORDER BY a.meta_validity_from DESC  NULLS LAST, b.meta_validity_from DESC  NULLS LAST) AS rank1
        FROM {{ref('sku_v1')}} AS a
        LEFT JOIN {{ref('sku_location_v2')}} AS b
        ON a.sku_code = b.sku_code
        WHERE a.source_system = {{ variable_macro('ecc_var') }}
        -- AND b.source_system = 'ECC'
    )
    WHERE rank1 = 1
) AS b
ON a.a0001_bom_header_code = b.sku_code
WHERE a0001_bom_header_code NOT IN
(
    SELECT DISTINCT a0001_bom_header_code 
    FROM {{ref('bom_component_location')}}
    WHERE a1345_local_bom_type = 'B'
)