-- WITH adjust_column AS (
--     SELECT  
--     disc.rsp AS promo_discount_percentage,
--     CAST(disc.promo_type AS FLOAT64) AS rsp,
--     CAST(disc.consumer_group AS INT64) AS promo_price,
--     CAST(NULL AS STRING) AS consumer_group,
--     CAST(NULL AS STRING) AS promo_type,
--     disc.version_month,
--     disc.year,
--     disc.month,
--     disc.start_date,
--     disc.end_date,
--     disc.client,
--     disc.country,
--     disc.signature,
--     disc.brand,
--     disc.franchise_sub_brand,
--     disc.category,
--     disc.sub_category,
--     disc.product_name,
--     disc.ean_code,
--     disc.sap_material_code,
--     disc.product_type,
--     --disc.promo_type,
--     disc.single_bundle,
--     disc.campaign_type1,
--     disc.campaign_type2,
--     disc.budget_owner,
--     disc.online_offline,   
--     disc.file_name,
--     disc.insert_timestamp,
--     disc.update_timestamp
--     FROM {{ ref('int_promo_plan') }} AS disc
--     WHERE disc.promo_mechanics = {{variable_macro('promo_discount_var')}}
--     -- WHERE disc.promo_mechanics_detail1 IS NULL
--     AND disc.promo_type IS NOT NULL AND disc.promo_type <> 's'
-- ),
-- remaining_data AS (
--     SELECT  
--     disc_2.promo_discount_percentage,
--     disc_2.rsp,
--     disc_2.promo_price,
--     disc_2.consumer_group,
--     disc_2.promo_type,
--     disc_2.version_month,
--     disc_2.year,
--     disc_2.month,
--     disc_2.start_date,
--     disc_2.end_date,
--     disc_2.client,
--     disc_2.country,
--     disc_2.signature,
--     disc_2.brand,
--     disc_2.franchise_sub_brand,
--     disc_2.category,
--     disc_2.sub_category,
--     disc_2.product_name,
--     disc_2.ean_code,
--     disc_2.sap_material_code,
--     disc_2.product_type,
--     --disc_2.promo_type,
--     disc_2.single_bundle,
--     disc_2.campaign_type1,
--     disc_2.campaign_type2,
--     disc_2.budget_owner,
--     disc_2.online_offline,   
--     disc_2.file_name,
--     disc_2.insert_timestamp,
--     disc_2.update_timestamp
--     FROM {{ ref('int_promo_plan') }} AS disc_2
--     WHERE disc_2.promo_mechanics = {{variable_macro('promo_discount_var')}}
--     -- WHERE disc_2.promo_mechanics_detail1 IS NULL
--     AND (disc_2.promo_type IS NULL OR disc_2.promo_type = 's')
-- ),
-- promo_discount_data AS (
--     SELECT * FROM adjust_column
--     UNION ALL
--     SELECT * FROM remaining_data
-- ),
WITH stg_valid_promo_discount AS (
    SELECT promo.version_month AS year_month,
    promo.year,
    promo.month,
    promo.start_date,
    promo.end_date,
    (CASE WHEN promo.client IN {{variable_macro('shopee_var')}} THEN {{variable_macro('shopee_vn_var')}}
    WHEN promo.client IN {{variable_macro('lazada_var')}} THEN {{variable_macro('lazada_vn_var')}}
    WHEN promo.client IN {{variable_macro('tiktok_var')}} THEN {{variable_macro('tiktok_vn_var')}}
    ELSE promo.client END) AS marketplace_code,
    promo.country,
    (CASE WHEN promo.signature IN {{variable_macro('mbl_brand_var')}} THEN {{variable_macro('mbl_var')}}
    WHEN promo.signature IN {{variable_macro('oap_brand_var')}} THEN {{variable_macro('oap_var')}}
    WHEN promo.signature IN {{variable_macro('grn_brand_var')}} THEN {{variable_macro('grn_var')}}
    WHEN promo.signature IN {{variable_macro('3ce_brand_var')}} THEN {{variable_macro('3ce_var')}}
    ELSE promo.signature END) AS signature_code,
    (CASE WHEN promo.brand IN {{variable_macro('mbl_brand_var')}} THEN {{variable_macro('mbl_var')}}
    WHEN promo.brand IN {{variable_macro('oap_brand_var')}} THEN {{variable_macro('oap_var')}}
    WHEN promo.brand IN {{variable_macro('grn_brand_var')}} THEN {{variable_macro('grn_var')}}
    WHEN promo.brand IN {{variable_macro('3ce_brand_var')}} THEN {{variable_macro('3ce_var')}}
    ELSE promo.brand END) AS brand_name,
    promo.franchise_sub_brand,
    promo.category,
    promo.sub_category,
    promo.product_name,
    promo.ean_code,
    promo.sap_material_code AS sku_code,
    promo.product_type,
    (CASE WHEN promo.single_bundle = {{variable_macro('virtual_bundle_var')}}
    THEN {{variable_macro('virtual_bundle_lower_var')}} 
    WHEN promo.single_bundle = {{variable_macro('bundle_var')}}
    THEN {{variable_macro('bundle_lower_var')}} 
    ELSE promo.single_bundle END) AS single_bundle,
    (CASE WHEN promo.campaign_type1 = {{variable_macro('bau_var')}}
    THEN {{variable_macro('bl_var')}} ELSE promo.campaign_type1 END) AS campaign_type1,
    (CASE WHEN promo.campaign_type2 = {{variable_macro('fs_var')}} OR promo.campaign_type2 = {{variable_macro('fs_s_var')}}
    THEN {{variable_macro('fs_upper_var')}} ELSE promo.campaign_type2 END) AS campaign_type2,
    promo.budget_owner AS division,
    promo.online_offline,
    promo.rsp,
    promo.promo_price,
    promo.promo_discount_percentage,
    --promo.consumer_group,
    promo.promo_type,
    promo.file_name,
    promo.insert_timestamp AS created_date,
    promo.update_timestamp AS updated_date,
    CURRENT_TIMESTAMP() AS load_ts
    FROM {{ ref('int_promo_plan') }} AS promo
    WHERE promo.promo_mechanics = {{variable_macro('promo_discount_var')}}
),
negative_discount_data AS (
  SELECT 
    year_month,
    year,
    month,
    start_date,
    end_date,
    marketplace_code,
    country,
    signature_code,
    brand_name,
    franchise_sub_brand,
    category,
    sub_category,
    product_name,
    ean_code,
    sku_code,
    product_type,
    single_bundle,
    campaign_type1,
    campaign_type2,
    division,
    online_offline,
    --consumer_group,
    promo_type,
    CASE WHEN promo_discount_percentage < 0 THEN promo_price ELSE rsp END AS rsp,
    CASE WHEN promo_discount_percentage < 0 THEN rsp ELSE promo_price END AS promo_price,
    CASE WHEN promo_discount_percentage < 0 THEN promo_discount_percentage * (-1) ELSE promo_discount_percentage END AS promo_discount_percentage,
    file_name,
    created_date,
    updated_date,
    load_ts
  FROM stg_valid_promo_discount
)

SELECT * FROM negative_discount_data

