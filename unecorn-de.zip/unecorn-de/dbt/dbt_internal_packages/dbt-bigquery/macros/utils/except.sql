{% macro bigquery__except() %}

    except distinct

{% endmacro %}
