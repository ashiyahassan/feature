{{ config(materialized='table') }}

WITH
    RECURSIVE BOM AS (
      SELECT
        NT.a0001_bom_header_code,
        a1349_local_bom_child_code_initial AS component_code,
        CAST(NULL AS STRING) AS parent_code,
        a1352_local_bom_child_quantity,
        1 AS level,
        local_bom_type_description,
        location_gln_description,
        source_catalog_name,
        source_system,
        a1257_location_gln,
        running_date
      FROM
        {{ref('vw_active_bom_component_location')}} AS NT
      INNER JOIN 
      (
        SELECT DISTINCT 
          a.a0001_bom_header_code
        FROM
          {{ref('vw_active_bom_component_location')}} AS a
      ) AS BH
      ON
        NT.a0001_bom_header_code=BH.a0001_bom_header_code
    
    UNION ALL
    SELECT
      b.a0001_bom_header_code,
      a.a1349_local_bom_child_code_initial,
      a.a0001_bom_header_code,
      a.a1352_local_bom_child_quantity,
      level+1 AS level,
      a.local_bom_type_description,
      a.location_gln_description,
      a.source_catalog_name,
      a.source_system,
      a.a1257_location_gln,
      a.running_date
    FROM
      {{ref('vw_active_bom_component_location')}} AS a
    INNER JOIN
      BOM b
    ON
      b.component_code = a.a0001_bom_header_code
    WHERE
      level < 4 
)
  
SELECT
  *,
  CURRENT_TIMESTAMP() AS load_ts
FROM
  BOM
WHERE
  component_code IS NOT NULL
UNION ALL
SELECT
  DISTINCT a.a0001_bom_header_code,
  a.a0001_bom_header_code AS component_code,
  CAST(NULL AS STRING) AS parent_code,
  CAST(NULL AS STRING) AS a1352_local_bom_child_quantity,
  0 AS level,
  local_bom_type_description,
  location_gln_description,
  source_catalog_name,
  source_system,
  a1257_location_gln,
  running_date,
  CURRENT_TIMESTAMP() AS load_ts
FROM
  {{ref('vw_active_bom_component_location')}} AS a


-- SELECT * FROM source_data
