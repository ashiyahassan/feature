{% macro update_active_flag(dataset_name, table_name) %}
 
{% set project_id = target.project %}
 
{% if execute and is_incremental() %}

    {{ print("Running active_month_macro: "~ dataset_name ~", "~ table_name~","~project_id) }}
    EXECUTE IMMEDIATE '''UPDATE `{{ project_id }}.{{ dataset_name }}.{{ table_name }}`
                    SET active_month_flag = 0
            WHERE active_month_flag = 1
                '''
 
 
{% endif %}
{{ print("completed active_month_macro: ") }} 
{% endmacro %}
 