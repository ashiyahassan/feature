	{% macro dq_rule_completeness() %}
		-- Query the BigQuery table to fetch data quality rules
		{% set dq_rules_query %}
			SELECT 
				dq_rule_sk, 
				dq_rule, 
				dq_rule_description, 
				dq_type, 
				pre_post_processing, 
				source_type, 
				source_name, 
				table_name, 
				column_name, 
				domain, 
				platform_code, 
				signature_code, 
				expected_value, 
				filters,
				result_query
			FROM {{ db_source('src_dq_rule', 'dim_dq_rule') }}
			WHERE dq_type = 'Completeness' 
			ORDER BY dq_rule_sk
		{% endset %}
		
		-- Fetch the data and transform it into row-based records
		{% set dq_rules_raw = dbt_utils.get_query_results_as_dict(dq_rules_query) %}
		{% set dq_rules = transform_dict_to_rows(dq_rules_raw) %}

		-- Initialize a variable to store the results
		{% set results = [] %}

		-- Current date for the refresh column - only fetch once
		{% set current_date = dbt_utils.get_query_results_as_dict("SELECT cast(DATETIME(CURRENT_TIMESTAMP(), 'Asia/Kolkata') as string) AS today")['today'] %}

		-- Process each rule
		{% for rule in dq_rules %}
			{% do log("Processing dq_rule_sk: " ~ rule['dq_rule_sk'], info=true) %}
			
			-- Parse expected values once to avoid repeated parsing
			{% set expected_values = fromjson(rule['expected_value']) %}
			{% set expected_threshold = expected_values[0] | int %}
			{% set expected_row_count = expected_values[1] | int %}
			
			-- Prepare common table reference for reuse
			{% set table_ref %}
				{% if rule['source_type'] == 'CDS' %}
					{{ ref(rule['table_name'])}}
				{% else %}
					{{ db_source(rule['source_name'], rule['table_name']) }} 
				{% endif %}
			{% endset %}
			
			-- Prepare filters with environment replacement
			{% set filter_clause = '' %}
			{% if rule['filters'] %}
				{% set filter_clause = 'WHERE ' ~ rule['filters'] | replace('{env}', target.name) %}
			{% endif %}
			
			-- Consolidated query to get all metrics in one go (threshold check, row count, min value)
			{% set combined_query %}
			BEGIN
				WITH base_data AS (
					SELECT {{ rule['column_name'] }}
					FROM {{ table_ref }}
					{{ filter_clause }}
					GROUP BY ALL
				)
				SELECT 
					CASE WHEN NOT EXISTS (
						SELECT 1 FROM base_data
						WHERE threshold_value >= {{ expected_threshold }}
					) THEN 0 ELSE 1 END AS threshold_result,
					COUNT(*) AS row_count,
					MIN(threshold_value) AS min_threshold_value
				FROM base_data;
			EXCEPTION WHEN ERROR THEN
				SELECT -1 AS threshold_result, -1 AS row_count, -1 AS min_threshold_value;
			END;
			{% endset %}

			-- Execute the consolidated query and get results
			{% do log("Executing combined query: " ~ combined_query, info=true) %}
			{% set query_result = dbt_utils.get_query_results_as_dict(combined_query) %}
			
			{% set threshold_result = query_result['threshold_result'][0] %}
			{% set row_count = query_result['row_count'][0] %}
			{% set min_threshold_value = query_result['min_threshold_value'][0] %}
			
			{% do log("threshold_result: " ~ threshold_result ~ ", row_count: " ~ row_count ~ ", min_threshold_value: " ~ min_threshold_value, info=true) %}

			-- Execute result query if provided
			{% set output_query_result = '' %}
			{% if rule['result_query'] %}
				{% set result_query = rule['result_query'] | replace('{env}', target.name) %}
				{% do log("Executing result query: " ~ result_query, info=true) %}
				{% set result_query_output = dbt_utils.get_query_results_as_dict(result_query) %}
				{% set output_query_result = transform_dict_to_rows(result_query_output) %}
			{% endif %}
			
			-- Evaluate the rule validity
			{% set valid_check = 1 if row_count == expected_row_count and threshold_result == 1 else 0 %}
			{% set valid_check = 0 if rule['result_query'] and tojson(output_query_result) == '[]' else valid_check %}
			
			-- Prepare other parameters
			{% set other_value = expected_threshold if threshold_result | int >= 1 else min_threshold_value | int %}
			{% set other = [expected_threshold, other_value] %}
			
			-- Sanitize output_query_result for proper JSON formatting
			{% set sanitized_output = tojson(output_query_result) | replace("'", '"') | replace('"Oreal', "\\'Oreal") %}
			
			-- Prepare the result row
			{% set result_row = [
				rule['dq_rule_sk'],
				'',
				valid_check,
				"'" ~ tojson(other) ~ "'",
				current_date[0],
				"'" ~ sanitized_output ~ "'"
			] %}
			
			-- Append the result_row into the results list
			{% do results.append(result_row) %}
			{% do log("Added result for rule " ~ rule['dq_rule_sk'] ~ ": " ~ result_row, info=true) %}
		{% endfor %}

		{% do log("Final Results count: " ~ results | length, info=true) %}
		{# do log("Final Results: " ~ results, info=true) #}
		
		-- Generate and return the final query
		{{ dq_rule_query_generator(results) }}

	{% endmacro %}