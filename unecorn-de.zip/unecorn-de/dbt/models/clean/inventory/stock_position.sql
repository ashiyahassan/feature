{{ config(materialized='table') }}

WITH source_data AS (
    SELECT '0000506423' AS stock_position, 'LAZADA_VN' AS marketplace_code
    UNION ALL
    SELECT '0000506231' AS stock_position, 'LAZADA_VN' AS marketplace_code
    UNION ALL
    SELECT '0000506423' AS stock_position, 'TIKTOK_VN' AS marketplace_code
    UNION ALL
    SELECT '0000506231' AS stock_position, 'TIKTOK_VN' AS marketplace_code
    UNION ALL
    SELECT '0000506249' AS stock_position, 'SHOPEE_VN' AS marketplace_code
    UNION ALL
    SELECT '0000506670' AS stock_position, 'SHOPEE_VN' AS marketplace_code
    UNION ALL
    SELECT '0000507112' AS stock_position, 'SHOPEE_VN' AS marketplace_code
    UNION ALL
    SELECT '0000507032' AS stock_position, 'SHOPEE_VN' AS marketplace_code
)

SELECT * FROM source_data