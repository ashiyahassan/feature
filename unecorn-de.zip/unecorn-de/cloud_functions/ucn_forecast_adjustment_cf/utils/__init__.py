import logging
import os

import yaml
from google.cloud import bigquery
from google.cloud.exceptions import Conflict, NotFound

config_file_name = "lld_config.yaml" #os.environ['CONFIG_FILE']

class ConfigParser:

    def __init__(self):
        pwd = os.getcwd()
        if __name__ == '__main__':
            stream = open("../"+ config_file_name, 'r')
        else:
            stream = open(F"{pwd}/"+ config_file_name, 'r')
        self.dictionary = yaml.load(stream, Loader=yaml.FullLoader)

    @staticmethod
    def get_project_id():
        project_id = os.environ['GCP_PROJECT_ID']
        return project_id

    def get_feed_list(self):
        feed_list = []
        for feed in self.dictionary['feeds']:
            feed_list.append(feed['feed_id'])
        return feed_list

    def get_feed(self, feed_id):
        return next((file_feed for file_feed in self.dictionary['feeds']
                     if str(file_feed['feed_id']) == str(feed_id)), None)

    def get_config_value(self, feed_id, keyname):
        res = self.get_feed(feed_id)
        if res:
            return res[keyname]
        else:
            return None


class BQUtils:

    def __init__(self):
        self.configParser = ConfigParser()
        self.bqClient = bigquery.Client(self.configParser.get_project_id())

    def get_bigquery_client(self):
        return self.bqClient

    def get_table_schema(self, project_id, dataset_id, table_name):
        client = self.get_bigquery_client()
        table_id = f"{project_id}.{dataset_id}.{table_name}"
        table = client.get_table(table_id)
        print("Table {} already exists.".format(table_id))

        # logging.info(table.schema)
        schema = []

        for x in table.schema:
            logging.info(x.field_type)
            column_attribute = {
                'name': x.name,
                'type': x.field_type,
                'mode': x.mode,
            }
            schema.append(column_attribute)
        return schema


if __name__ == '__main__':
    cp = ConfigParser()
    print(os.getcwd())
    bq = BQUtils()