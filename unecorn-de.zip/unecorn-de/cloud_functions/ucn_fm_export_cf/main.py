import functions_framework
from google.cloud import bigquery
from google.cloud import storage
import csv
import tempfile
import os
import logging
import pandas

# Initialize clients
bq_client = bigquery.Client()
storage_client = storage.Client()

project_id = os.getenv('project_id') if os.getenv('project_id') is not None else 'spmena-unecorn-zn-apac-dv'
dataset_id = os.getenv('dataset_id') if os.getenv('dataset_id') is not None else 'cds_unecorn_process_zn'
table_id = os.getenv('table_id') if os.getenv('table_id') is not None else 'vw_export_to_fm'
bucket_name = os.getenv('bucket_name') if os.getenv('bucket_name') is not None else 'unecornde-export-fm-ew1-dv'
folder_path = os.getenv('folder_path') if os.getenv('folder_path') is not None else 'VNCPD'
filename = os.getenv('filename') if os.getenv('filename') is not None else 'wholesaler.csv'

@functions_framework.http
def hello_http(request):
    """HTTP Cloud Function.
    Args:
        request (flask.Request): The request object.
        <https://flask.palletsprojects.com/en/1.1.x/api/#incoming-request-data>
    Returns:
        The response text, or any set of values that can be turned into a
        Response object using `make_response`
        <https://flask.palletsprojects.com/en/1.1.x/api/#flask.make_response>.
    """
    request_json = request.get_json(silent=True)
    request_args = request.args

    print("INITIATED ----------")
    export_to_gcs(request)
    
    return 'File Exported !'




def export_to_gcs(request):
    try:
        # Set your BigQuery query
        query = f"""
        SELECT *
        FROM `{project_id}.{dataset_id}.{table_id}`
        """

        # Execute the query and fetch results as DataFrame
        df = bq_client.query(query).to_dataframe()

        # Check if DataFrame has rows
        if df.empty:
            logging.warning('Query returned zero rows.')
            print('Query returned zero rows.')
            return 'Query returned zero rows.'
            
        col = ["Qty M", "Qty M+1", "Qty M+2", "Qty M+3", "Qty M+4", "Qty M+5", "Qty M+6", "Qty M+7", "Qty M+8", "Qty M+9", "Qty M+10", "Qty M+11", "Qty M+12", "Qty M+13", "Qty M+14", "Qty M+15", "Qty M+16", "Qty M+17", "Qty M+18", "Qty M+19"]
        # Prepare a temporary file to store CSV
        with tempfile.NamedTemporaryFile(delete=False) as temp_file:
            temp_file_path = temp_file.name
            for i in col:
                df[i] = df[i].fillna(0).astype(int)
            # Write DataFrame to CSV file with ';' delimiter
            df.to_csv(temp_file_path, index=False, sep=';')

        # Define GCS bucket and file path


        destination_blob_name = f'{folder_path}/{filename}'

        # Upload file to GCS
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(destination_blob_name)
        blob.upload_from_filename(temp_file_path)

        # Clean up: delete temporary file
        os.remove(temp_file_path)

        # Log and return
        logging.info(f'File uploaded to GCS bucket: gs://{bucket_name}/{destination_blob_name}')
        print(f'File uploaded to GCS bucket: gs://{bucket_name}/{destination_blob_name}')
        return f'File uploaded to GCS bucket: gs://{bucket_name}/{destination_blob_name}'

    except Exception as e:
        logging.error(f'An error occurred: {str(e)}')
        print(f'An error occurred: {str(e)}')
        return f'An error occurred: {str(e)}'
