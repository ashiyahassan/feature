{{ config(materialized='table') }}

WITH BOM_Main AS (
    SELECT DISTINCT
      a.a0001_bom_header_code AS bom_header_code,
      a.component_code,
      a.parent_code,
      b.parent_code AS parent_code_of_node,
      b.component_code AS component_code_of_node,
      CAST (a.a1352_local_bom_child_quantity AS INT) AS component_quantity,
      b.level AS bom_level_of_node,
      a.local_bom_type_description,
      a.level AS bom_level
    FROM
    {{ref('bom_level_explosion')}} AS a
    LEFT JOIN
    {{ref('bom_level_explosion')}} AS b
    ON
    a.a0001_bom_header_code = b.a0001_bom_header_code
    AND a.component_code =b.parent_code
)
   
SELECT DISTINCT
  b.ean_code AS bom_header_ean_code,
  a.bom_header_code,
  c.ean_code AS component_ean_code,
  component_code,
  m_factor,
  component_quantity,
  d.local_bom_type_description AS local_bom_type_description
FROM (
  SELECT DISTINCT 
    leaf_node.bom_header_code,
    leaf_node.component_code,
    COALESCE(factor,1) AS m_factor,
    component_quantity,
    local_bom_type_description,
    bom_level
  FROM (
    SELECT
      bom_header_code,
      parent_code,
      component_code,
      component_quantity,
      bom_level,
      local_bom_type_description
    FROM
      BOM_Main
    WHERE
      parent_code_of_node IS NULL
      AND bom_level!=0
  ) AS leaf_node
  LEFT JOIN (
  SELECT
    a.bom_header_code,
    a.parent_code_of_node,
    a.component_code_of_node,
    (a.component_quantity*COALESCE(b.component_quantity,1)) AS factor,
    COALESCE(b.component_quantity,1)
  FROM
    BOM_Main AS a
  LEFT JOIN
    BOM_Main AS b
  ON
    a.bom_header_code=b.bom_header_code
    AND a.parent_code_of_node =b.component_code_of_node
  WHERE
    a.component_code_of_node IS NOT NULL
  ) AS MF
  ON
  leaf_node.bom_header_code=MF.bom_header_code
  AND leaf_node.component_code=MF.component_code_of_node
  WHERE
  component_code IS NOT NULL
) AS a
LEFT JOIN
(
  SELECT DISTINCT sku_code,ean_code,material_type 
  FROM
  (
    SELECT DISTINCT sku_code,ean_code,material_type,meta_validity_from,
      ROW_NUMBER() OVER (PARTITION BY sku_code ORDER BY source_system, meta_validity_from DESC) AS row_num
    FROM {{ref('sku_v1')}} 
    -- WHERE source_system={{variable_macro('ecc_var')}}
  )
  WHERE row_num = 1
) AS b
ON bom_header_code=b.sku_code
LEFT JOIN
(
  SELECT DISTINCT sku_code,ean_code,material_type 
  FROM
  (
    SELECT DISTINCT sku_code,ean_code,material_type,meta_validity_from,
      ROW_NUMBER() OVER (PARTITION BY sku_code ORDER BY source_system, meta_validity_from DESC) AS row_num
    FROM {{ref('sku_v1')}} 
    -- WHERE source_system={{variable_macro('ecc_var')}}
  )
  WHERE row_num = 1
) AS c
ON component_code=c.sku_code
LEFT JOIN
(
  SELECT DISTINCT
    a0001_bom_header_code AS bom_header_code,
    CASE
        WHEN local_bom_type_description = 'Virtual BOM' THEN 'VB'
        ELSE 'PB'
    END AS local_bom_type_description
  FROM {{ref('bom_level_explosion')}}
  WHERE level = 0
) AS d
ON   a.bom_header_code= d.bom_header_code
WHERE (d.local_bom_type_description = 'PB' AND b.material_type='YVIB') = false