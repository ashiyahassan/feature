WITH campaign_hours AS (
    SELECT 
        camp.file_version,
        camp.year,
        camp.month,
        camp.day,
        camp.date,
        camp.start_date,
        camp.end_date,
        ROUND(DATETIME_DIFF(TIMESTAMP(camp.end_date), TIMESTAMP(camp.start_date), MILLISECOND) / (3600 * 1000)) AS total_hours,
        (CASE WHEN camp.marketplace_code IN {{variable_macro('shopee_var')}} THEN {{variable_macro('shopee_vn_var')}}
        WHEN camp.marketplace_code IN {{variable_macro('lazada_var')}} THEN {{variable_macro('lazada_vn_var')}}
        WHEN camp.marketplace_code IN {{variable_macro('tiktok_var')}} THEN {{variable_macro('tiktok_vn_var')}}
        ELSE camp.marketplace_code END) AS marketplace_code,
        camp.country,
        CASE
            WHEN signature_code IN {{variable_macro('mbl_brand_var')}} THEN {{variable_macro('mbl_var')}}
            WHEN signature_code IN {{variable_macro('oap_brand_var')}} THEN {{variable_macro('oap_var')}}
            WHEN signature_code IN {{variable_macro('grn_brand_var')}} THEN {{variable_macro('grn_var')}}
            WHEN signature_code IN {{variable_macro('3ce_brand_var')}} THEN {{variable_macro('3ce_var')}}
            ELSE signature_code
        END AS signature_name,
        CASE
            WHEN signature_code IN {{variable_macro('mbl_brand_var')}} THEN {{variable_macro('p5_var')}}
            WHEN signature_code IN {{variable_macro('oap_brand_var')}} THEN {{variable_macro('p2_var')}}
            WHEN signature_code IN {{variable_macro('grn_brand_var')}} THEN {{variable_macro('p4_var')}}
            WHEN signature_code IN {{variable_macro('3ce_brand_var')}} THEN {{variable_macro('ph_var')}}
            ELSE signature_code
        END AS signature_code,
        camp.store_or_franchise,
        camp.campaign_title,
        (CASE WHEN camp.campaign_type = {{variable_macro('bd_var')}} THEN {{variable_macro('mg_var')}}
        WHEN camp.campaign_type = {{variable_macro('sbd_var')}} THEN {{variable_macro('smg_var')}}
        ELSE camp.campaign_type END) as  campaign_type,
        camp.campaign_name,    
        camp.division,
        camp.file_name,
        camp.insert_timestamp AS created_date,
        camp.update_timestamp AS updated_date,
        -- CURRENT_TIMESTAMP() AS load_ts
    FROM {{ ref('int_campaign_calendar') }} AS camp
    WHERE camp.date IS NOT NULL AND camp.signature_code IS NOT NULL
    AND camp.campaign_type IS NOT NULL
),
-- Flag days that have non-BL campaigns
non_bl_days AS (
    SELECT DISTINCT marketplace_code, signature_code, date
    FROM campaign_hours
    WHERE campaign_type IN {{variable_macro('non_bl_var')}} 
),
-- Filter out BL only when non-BL campaigns exist
filtered_campaigns AS (
    SELECT ch.*
    FROM campaign_hours ch
    LEFT JOIN non_bl_days nb
    ON ch.marketplace_code = nb.marketplace_code 
    AND ch.signature_code = nb.signature_code 
    AND ch.date = nb.date
    WHERE NOT (ch.campaign_type = {{variable_macro('bl_var')}} 
    AND nb.marketplace_code IS NOT NULL AND nb.signature_code IS NOT NULL)
),
-- Add SMG ≥ 6h check
priority_flagged AS (
    SELECT *,
        CASE 
            WHEN campaign_type = {{variable_macro('smg_var')}} AND total_hours >= 6 THEN 1 ELSE 0
        END AS s_satisfies_rule
    FROM filtered_campaigns
),
-- Tag row number based on priority logic
ranked_campaigns AS (
    SELECT
        *,
        ROW_NUMBER() OVER (
            PARTITION BY marketplace_code, signature_code, date 
            ORDER BY  
                s_satisfies_rule DESC,         -- Rule 1: SMG ≥ 6h
                total_hours DESC,              -- Rule 2 & 3: longest duration
                CASE                           -- Rule 4: priority
                    WHEN campaign_type = {{variable_macro('smg_var')}} THEN 1
                    WHEN campaign_type = {{variable_macro('mg_var')}} THEN 2
                    WHEN campaign_type = {{variable_macro('cp_var')}} THEN 3
                    WHEN campaign_type = {{variable_macro('bl_var')}} THEN 4
                    ELSE 5
                END
        ) AS rank_priority
    FROM priority_flagged
)
SELECT
    file_version,
    year,
    month,
    day,
    date,
    start_date,
    end_date,
    marketplace_code,
    country,
    signature_name,
    signature_code,
    store_or_franchise,
    campaign_title,
    campaign_type,
    campaign_name,    
    division,
    file_name,
    created_date,
    updated_date,
    CURRENT_TIMESTAMP() AS load_ts
FROM ranked_campaigns 
WHERE rank_priority = 1