{{ 
  config(
    materialized='incremental',
    unique_key=['sku_code','meta_validity_from']
  ) 
}}


WITH source_data AS (
    SELECT a0001_internal_product_code AS sku_code, 
    a0528_product_lifecycle_status_code AS mm_status, 
    product_lifecycle_status_description AS mm_status_description,
    local_pillar,
    -- CAST(CASE WHEN local_pillar = '1' THEN 'true' ELSE 'false' END AS BOOL) AS local_pillar,
    meta_validity_from, 
    meta_validity_to,
    a0529_product_lifecycle_status_application_date AS application_date,
    a0527_producer_application_start_date AS start_date,
    a1257_supply_entity,
    location_gln_description,
    source_system,
    last_running_date,
    CURRENT_TIMESTAMP() AS load_ts  
    FROM {{db_source('src_product_v3','sku_location_v4')}}  
    WHERE a1257_supply_entity IN {{variable_macro('location_var')}}
    OR (location_gln_description IN {{variable_macro('location_gln_var')}} OR 
    location_gln_description LIKE {{variable_macro('country_like_var')}} )
    {% if is_incremental() %}

      -- this filter will only be applied on an incremental run
      -- (uses > to include records whose timestamp occurred since the last run of this model)
      AND last_running_date > (SELECT MAX(last_running_date) FROM {{ this }})

    {% endif %}
)

SELECT * FROM source_data
