import functions_framework
import os
import time
from datetime import datetime
from jinja2 import Environment, FileSystemLoader
import requests
import base64
import google.auth
import google.auth.transport.requests

project_id = os.environ['GCP_PROJECT_ID']
ENV = os.environ['GCP_ENV']

@functions_framework.http
def http_hello(request):
    request_json = request.get_json(silent=True)
    request_args = request.args
    print(request_json)
    status = request_json["status"]
    return send_email(status, request_json)


def define_content(request_json):
    content = {}
    table_details = []
    content["workflow_name"] = request_json["workflow_name"]
    content["status"] = request_json["status"].lower()
    content["workflow_execution_id"] = request_json["workflow_excution_id"]
    content["date"] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print(request_json["email_dicts"])
    
    for table_name,status in request_json["email_dicts"].items():
        table_details.append({"table_name":table_name,"status":status})
    content["table_details"] = table_details
    
    return content


def get_html(status,content):
    html_content = None
    try:
        env = Environment(loader=FileSystemLoader("./html"))
        print(env.list_templates())
        if status=="success":
            template = env.get_template("success_template.html")
            html_content = template.render(content)
        else:
            template = env.get_template("failed_template.html")
            html_content = template.render(content)
        
    except Exception as e:
        print("Exception at get_html: ",e)

    if not html_content:
        raise Exception("The HTML file is empty.")
    
    return html_content

def send_email(status, request_json):
    email_details = {
        "pd": {
            "to":['APMENA-GCP-UNECORN-PRODUCT-VN-USER@loreal.com','nikhil.jain@loreal.com','sowjanya.janarthanan@loreal.com'],
            "success": "Successful Execution of Workflow Pipeline",
            "failed": "Workflow Pipeline is failed"
        },
        "np": {
            "to":['prakhar.shanker@loreal.com','pratham.dubey@loreal.com', 'shubham2.mishra@loreal.com'],
            "success": "Successful Execution of Workflow Pipeline",
            "failed": "Workflow Pipeline is failed"
        },
        "qa": {
            "to":['prakhar.shanker@loreal.com', 'shubham2.mishra@loreal.com'],
            "success": "Successful Execution of Workflow Pipeline",
            "failed": "Workflow Pipeline is failed"
        },
        "dv": {
            "to":['prakhar.shanker@loreal.com'],
            "success": "Successful Execution of Workflow Pipeline",
            "failed": "Workflow Pipeline is failed"
        },
    }
    try:
        creds, project = google.auth.default()
        auth_req = google.auth.transport.requests.Request()
        creds.refresh(auth_req)
        access_token = creds.token
    except (DefaultCredentialsError, RefreshError) as e:
        logging.warning(f"Failed to retrieve or refresh credentials: {e}")
        return "Authentication error", 500
    
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }
    context = define_content(request_json)
    payload = [{
        "to": email_details[ENV]["to"],
        "sender": "unecorn-noreply@data-platform.beauty.tech",
        "subject": email_details[ENV][status.lower()],
        "content": get_html(status.lower(),context)
    }]

    try:
        print(payload)
        # print(access_token)
        response = requests.post("https://api.loreal.net/global/it4it/btdp-notification/v1/notifications/email", headers=headers, json=payload)
        # Log the response content and status code
        print(f"API response: {response.content.decode('utf-8')}")
        print(f"API response status code: {response.status_code}")
        # print(response.content, response.status_code)
        # return response.content, response.status_code
        print("email send successfully to ...".upper(),email_details[ENV]["to"])
        
    except Exception as e:
        print("exception at sending email using btdp api, error: ",e)
        return "Failed!! to send email " + str(e)
    return "Success"