{{ config(materialized='table') }}

WITH source_data AS (
    SELECT  
        country,
        division,
        marketplace_code,
        signature_code,
        ean_code,
        AVG(cancelled_rate) AS cancelled_rate_check ,
        CASE
            WHEN AVG(cancelled_rate) >.30  THEN .30
            ELSE AVG(cancelled_rate)
        END AS cancelled_rate
    FROM
    (
        SELECT 
            country,
            division,
            sd.ean_code,
            sd.marketplace_code,
            sd.signature_code,
            DATE_TRUNC(sd.sellout_date, MONTH) AS sellout_date,
            SUM(sd.daily_cancelled_units) AS total_cancelled_units,
            SUM(sd.daily_gmv_units) AS total_gmv_units,
            SUM(sd.daily_cancelled_units) / NULLIF(SUM(sd.daily_gmv_units), 0) AS cancelled_rate
            --(daily_cancelled_units)/NULLIF(daily_gmv_units,0) AS cancelled_rate
        FROM {{ref('daily_sellout_d2c_v3')}} AS sd
        INNER JOIN {{ref('unecorn_ean_details')}} AS ud
        ON sd.ean_code = ud.ean_code
        AND sd.marketplace_code = ud.marketplace_code
        WHERE sd.sellout_date >= DATE_TRUNC(DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 4 MONTH), MONTH)
        AND sd.sellout_date < DATE_TRUNC(DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 1 MONTH), MONTH)
        AND ud.unecorn_lifecycle IN ('To be Discont. (modelled)','Ongoing (modelled)')
        GROUP BY DATE_TRUNC(sd.sellout_date, MONTH),country,division,ean_code,marketplace_code,signature_code
    )
    GROUP BY 1,2,3,4,5
)

SELECT *, CURRENT_TIMESTAMP() AS load_ts FROM source_data
UNION ALL
SELECT 
    country, 
    division, 
    {{variable_macro('tiktok_vn_var')}} AS marketplace_code, 
    signature_code, 
    ean_code, 
    cancelled_rate_check, 
    cancelled_rate, 
    CURRENT_TIMESTAMP() AS load_ts
FROM (
    SELECT * FROM source_data
    WHERE marketplace_code = {{variable_macro('lazada_vn_var')}} AND country = {{variable_macro('country_var')}}
)
WHERE NOT EXISTS (
    SELECT 1 FROM source_data
    WHERE marketplace_code = {{variable_macro('tiktok_vn_var')}} AND country = {{variable_macro('country_var')}}
)