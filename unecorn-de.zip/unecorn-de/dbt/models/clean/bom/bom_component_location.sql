{{ config(materialized='incremental') }}

WITH source_data AS (
    SELECT a0001_bom_header_code,
    a1257_location_gln,
    a1345_local_bom_type,
    a1349_local_bom_child_code_initial,
    a1350_local_bom_child_code_operational,
    a1351_local_bom_child_description,
    a1391_local_bom_child_function,
    a1352_local_bom_child_quantity,
    a1353_local_bom_child_quantity_uom,
    location_gln_description,
    local_bom_type_description,
    local_bom_child_function_description,
    local_bom_child_quantity_uom_description,
    alternative_bom,
    item_position,
    local_bom_child_item_category,
    bom_id,
    valid_from,
    valid_to,
    running_date,
    last_running_date,
    source_catalog_name,
    source_catalog_gln,
    meta_file_name,
    meta_file_export_type,
    meta_file_version,
    meta_validity_from,
    meta_validity_to,
    meta_loading_date,
    source_system,
    CURRENT_TIMESTAMP() AS load_ts
    FROM {{db_source('src_product','sku_bom_components_location_v1')}}   
    WHERE a1257_location_gln IN {{variable_macro('location_var')}}
    AND source_system = {{variable_macro('ecc_var')}}
    {% if is_incremental() %}

      -- this filter will only be applied on an incremental run
      -- (uses > to include records whose timestamp occurred since the last run of this model)
      AND running_date > (SELECT MAX(running_date) FROM {{ this }})

    {% endif %}
)

SELECT * FROM source_data
