{% macro ensure_load_ts(dataset_name, table_name, col_name) %}

{% set project_id = target.project %}
-- {% set dataset_id = dataset_name %}
{{ print("Running some_macro: "~ dataset_name ~", "~ table_name ~","~ col_name) }}
{% if execute %}

  IF (
    SELECT COUNT(*)
    FROM `{{ project_id }}.{{ dataset_name }}.INFORMATION_SCHEMA.COLUMNS`
    WHERE
      TABLE_NAME = '{{ table_name }}'
      AND COLUMN_NAME = '{{ col_name }}'
  ) = 0 THEN
    -- If the column doesn't exist, add the 'load_ts' column
    EXECUTE IMMEDIATE 'ALTER TABLE {{ project_id }}.{{ dataset_name }}.{{ table_name }} ADD COLUMN {{ col_name }} TIMESTAMP';
    EXECUTE IMMEDIATE 'UPDATE {{ project_id }}.{{ dataset_name }}.{{ table_name }} SET {{ col_name }} = CURRENT_TIMESTAMP() WHERE 1=1';
  ELSE
    EXECUTE IMMEDIATE 'UPDATE {{ project_id }}.{{ dataset_name }}.{{ table_name }} SET {{ col_name }} = CURRENT_TIMESTAMP() WHERE 1=1';
  END IF;

{% endif %}

{% endmacro %}
