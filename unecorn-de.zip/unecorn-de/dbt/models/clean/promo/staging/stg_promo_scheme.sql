WITH stg_valid_promo_scheme AS (
    SELECT promo.version_month AS year_month,
    promo.year,
    promo.month,
    promo.promo_duration,
    promo.start_date,
    promo.end_date,
    (CASE WHEN promo.client IN {{variable_macro('shopee_var')}} THEN {{variable_macro('shopee_vn_var')}}
    WHEN promo.client IN {{variable_macro('lazada_var')}} THEN {{variable_macro('lazada_vn_var')}}
    WHEN promo.client IN {{variable_macro('tiktok_var')}} THEN {{variable_macro('tiktok_vn_var')}}
    ELSE promo.client END) AS marketplace_code,
    promo.country,
    (CASE WHEN promo.signature IN {{variable_macro('mbl_brand_var')}} THEN {{variable_macro('p5_var')}}
    WHEN promo.signature IN {{variable_macro('oap_brand_var')}} THEN {{variable_macro('p2_var')}}
    WHEN promo.signature IN {{variable_macro('grn_brand_var')}} THEN {{variable_macro('p4_var')}}
    WHEN promo.signature IN {{variable_macro('3ce_brand_var')}} THEN {{variable_macro('ph_var')}}
    ELSE promo.signature END) AS signature_code,
    (CASE WHEN promo.brand IN {{variable_macro('mbl_brand_var')}} THEN {{variable_macro('mbl_var')}}
    WHEN promo.brand IN {{variable_macro('oap_brand_var')}} THEN {{variable_macro('oap_var')}}
    WHEN promo.brand IN {{variable_macro('grn_brand_var')}} THEN {{variable_macro('grn_var')}}
    WHEN promo.brand IN {{variable_macro('3ce_brand_var')}} THEN {{variable_macro('3ce_var')}}
    ELSE promo.brand END) AS brand_name,
    promo.product_name,
    promo.ean_code,
    promo.sap_material_code AS sku_code,
    promo.promo_name,    
    promo.campaign_type1,
    promo.campaign_type2,
    promo.budget_owner AS division,
    promo.online_offline,
    promo.promo_mechanics,
    promo.promo_mechanics_detail1,
    promo.promo_mechanics_detail2,
    LOWER(promo.promo_type) AS promo_type,
    promo.rsp,
    promo.promo_discount_value,
    promo.issued_quantity,
    promo.file_name,
    promo.insert_timestamp AS created_date,
    promo.update_timestamp AS updated_date,
    CURRENT_TIMESTAMP() AS load_ts
    FROM {{ ref('int_promo_plan') }} AS promo
    WHERE promo.promo_mechanics = {{variable_macro('promo_scheme_var')}}
    --AND promo.ean_code IS NOT NULL
)

SELECT * FROM stg_valid_promo_scheme