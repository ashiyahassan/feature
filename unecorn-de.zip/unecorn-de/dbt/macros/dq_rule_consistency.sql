{% macro dq_rule_consistency() %}
    -- Query the BigQuery table to fetch data quality rules
    {% set dq_rules_query %}
        SELECT 
            dq_rule_sk,
            dq_type, 
            pre_post_processing, 
            source_type, 
            source_name, 
            table_name, 
            column_name, 
            domain, 
            platform_code, 
            signature_code, 
            expected_value, 
            filters,
            result_query
        FROM {{ db_source('src_dq_rule', 'dim_dq_rule') }}
        WHERE dq_type = 'Consistency'
        ORDER BY dq_rule_sk
    {% endset %}
    
    -- Fetch the data and transform it into row-based records
    {% set dq_rules = transform_dict_to_rows(dbt_utils.get_query_results_as_dict(dq_rules_query)) %}

    -- Initialize a variable to store the results
    {% set results = [] %}

    -- Current date for the refresh column - fetch once
    {% set current_date = dbt_utils.get_query_results_as_dict("SELECT cast(DATETIME(CURRENT_TIMESTAMP(), 'Asia/Kolkata') as string) AS today")['today'] %}

    -- Process each rule
    {% for rule in dq_rules %}
        {% do log("Processing dq_rule_sk: " ~ rule['dq_rule_sk'], info=true) %}
        
        -- Create table reference only once
        {% set table_ref %}
            {% if rule['source_type'] == 'CDS' %}
                {{ ref(rule['table_name'])}}
            {% else %}
                {{ db_source(rule['source_name'], rule['table_name']) }} 
            {% endif %}
        {% endset %}
        
        -- Prepare filter clause with environment replacement
        {% set filter_clause = rule['filters'] | replace('{env}', target.name) %}
        
        -- Build main query
        {% set query %}
        BEGIN
            SELECT COUNT(*) AS row_count
            FROM {{ table_ref }}
            WHERE {{ filter_clause }};
        EXCEPTION WHEN ERROR THEN
            SELECT -1 AS row_count;
        END;         
        {% endset %}

        -- Execute the main query and log the result
        {% set query_result = dbt_utils.get_query_results_as_dict(query) %}
        {% set row_count = query_result['row_count'][0] %}
        {% do log("Row count for rule " ~ rule['dq_rule_sk'] ~ ": " ~ row_count, info=true) %}
        {% do log("Main query: " ~ query, info=true) %}

        -- Execute result query if provided
        {% set output_query_result = '' %}
        {% if rule['result_query'] %}
            {% set result_query = rule['result_query'] | replace('{env}', target.name) %}
            {% do log("Executing result query for rule " ~ rule['dq_rule_sk'], info=true) %}
            {% set result_query_output = dbt_utils.get_query_results_as_dict(result_query) %}
            {% set output_query_result = transform_dict_to_rows(result_query_output) %}
        {% endif %}
        
        -- Evaluate the rule validity
        {% set valid_check = 1 if row_count > 0 else 0 %}
        {% set valid_check = 0 if rule['result_query'] and tojson(output_query_result) == '[]' else valid_check %}
        
        -- Sanitize output for proper JSON formatting
        {% set sanitized_output = tojson(output_query_result) | replace("'", '"') | replace('"Oreal', "\\'Oreal") %}
        
        -- Prepare the result row
        {% set result_row = [
            rule['dq_rule_sk'],
            '',
            valid_check,
            '',
            current_date[0],
            "'" ~ sanitized_output ~ "'"
        ] %}
        
        -- Append the result row to results list
        {% do results.append(result_row) %}    
        {% do log("Added result for rule " ~ rule['dq_rule_sk'], info=true) %}
    {% endfor %}

    {% do log("Completed processing " ~ results | length ~ " consistency rules", info=true) %}
    {% do log("Completed processing: " ~ results , info=true) %}

    -- Generate and return the final query
    {{ dq_rule_query_generator(results) }}
{% endmacro %}