{% macro inc_ts(ts_column, node) -%}

SELECT entry_timestamp FROM spmena-unecorn-zn-apac-dv.audit_zn.audit_details 
    WHERE entity='{{ts_column}}' AND `status`=success Order by batch_id desc limit 1


{%- endmacro %}