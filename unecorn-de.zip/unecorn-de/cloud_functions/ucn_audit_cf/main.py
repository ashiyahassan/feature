import datetime
import functions_framework
from google.cloud import bigquery
from google.cloud.bigquery import LoadJobConfig, SourceFormat
import json
import pandas as pd

client = bigquery.Client()


@functions_framework.http
def http_hello(request):
    """HTTP Cloud Function.
    Args:
        request (flask.Request): The request object.
        <https://flask.palletsprojects.com/en/1.1.x/api/#incoming-request-data>
    Returns:
        The response text, or any set of values that can be turned into a
        Response object using `make_response`
        <https://flask.palletsprojects.com/en/1.1.x/api/#flask.make_response>.
    """
    request_json = request.get_json(silent=True)

    print(request_json)
    message = main_callback(request_json)
    return 'CF DE AUDIT {}! '.format(message)


def main_callback(request_json):
    print('Initializing Audit Function')
    try:
        if request_json is not None:
            data = request_json['data']
            project_id = request_json['project_id']
            dataset_id = request_json['dataset_id']
            table_id = request_json['table_id']
            try :
                gcs_folder = request_json['gcs_folder']
            except :
                gcs_folder = None

            print(data)
            print(project_id)
            print(dataset_id)
            print(table_id)
            print(gcs_folder)
            
            if table_id == 'log_batch_details' and data['batch_stage'] == 'end':
                print('UPDATE BATCH-------------------------------------------------------',data['batch_stage'] )
                return update_status(data, project_id, dataset_id, table_id)      
            return insert_into_bigquery(data, project_id, dataset_id, table_id, gcs_folder)
             
        else:
            return 'Missing parameters: data, project_id, dataset_id, table_id'
    except Exception as e:
        print("EXCEPTION :", e)
        return e


def update_status(data, project_id, dataset_id, table_id):
    # Initialize BigQuery client

    client = bigquery.Client(project=project_id)
    batch_id = get_max_batch_id(project_id, dataset_id)
    print('UPDATE BTACH ID ', batch_id)
    # Define the query to update status
    query = f"""
        UPDATE `{project_id}.{dataset_id}.{table_id}`
        SET state = '{data['state']}', end_time = current_timestamp

        WHERE batch_id = {batch_id}
    """
    print('UPDATE QUERY ADDED')

    # Run the query
    query_job = client.query(query)

    # Wait for the query to finish
    query_job.result()
    print('UPDATE QUERY COMPLETE')
    print(f"Status updated successfully for id {data['id']}")


def serialize_datetime(obj):
    """Serialize datetime object to string."""
    if isinstance(obj, datetime.datetime):
        return obj.isoformat()
    raise TypeError("Type not serializable")




# def insert_into_bigquery(data, project_id, dataset_id, table_id, gcs_folder):
#   """
#   Inserts data from a JSON object into BigQuery using a Pandas DataFrame and to_gbq.

#   Args:
#       data: The JSON data to be inserted.
#       project_id: Your Google Cloud project ID.
#       dataset_id: The ID of the BigQuery dataset.
#       table_id: The ID of the BigQuery table.
#       gcs_folder: (Optional) Path to a Google Cloud Storage folder related to the data (unused in this implementation).

#   Returns:
#       A string indicating success or failure with any errors encountered.
#   """

#   try:
#     # Convert JSON data to Pandas DataFrame
#     df = pd.DataFrame( [get_audit_data(data, table_id, project_id, dataset_id, gcs_folder)])
#     # Establish BigQuery client
#     pclient = bigquery.Client(project=project_id)
#     table_ref = f"{dataset_id}.{table_id}"
#     print(df)
#     print(table_ref)
#     print(df.dtypes)
#     # Insert data into BigQuery using to_gbq
#     disposition = "append"  # Append to existing table (adjust if needed)
#     df.to_gbq(table_ref, if_exists=disposition)

#     print("INSERT BQ INITIALIZED")
#     print("INSERT COMPLETE")
#     return f"Records inserted successfully into {project_id}.{dataset_id}.{table_id}"

#   except Exception as e:
#     print("EXCEPTION : INSERT into BQ :", e)
#     return e


def insert_into_bigquery(data, project_id, dataset_id, table_id, gcs_folder):
    try:
        pclient = bigquery.Client(project=project_id)
        table_ref = pclient.dataset(dataset_id).table(table_id)
        print(project_id, dataset_id, table_id)
        print(table_ref)
        table = pclient.get_table(table_ref)
        print(table)
        row = get_audit_data(data, table_id, project_id, dataset_id, gcs_folder)
        rows_to_insert = [row]
        print("INSERT BQ INITIALIZED")
        # errors = pclient.insert_rows(table, rows_to_insert)
        job = pclient.load_table_from_json(
            rows_to_insert, table, location="EU"  # You can specify location here
        )
        print("CONFIG SET")
        errors = job.result()
        print("INSERT COMPLETE")
        return f"Records inserted successfully into {project_id}.{dataset_id}.{table_id}"
        # print("INSERT COMPLETE")
        # if not errors:
        #     print("INSERT COMPLETE")
        #     return f"Records inserted successfully into {project_id}.{dataset_id}.{table_id}"
        # else:
        #     print("ERROR ",errors)
        #     return f"Errors occurred: {errors}"
    except Exception as e:
        print("EXCEPTION : INSERT into BQ :",e)
        return e

def get_max_batch_id(project_id, audit_dataset):
    try:
        batch_id_query = client.query(
            f"SELECT coalesce(max(batch_id),0) as batchid FROM `{project_id}.{audit_dataset}.log_batch_details`")
        batch_id = "1"
        for row in batch_id_query.result():
            if row.batchid is not None:
                batch_id = row.batchid
        return batch_id
    except Exception as e:
        print("EXEPTION GET MAX BATCH ",e)
        return  e

def get_max_job_id(project_id, audit_dataset, batch_id):
    try:
        job_id_query = client.query(
            f"SELECT coalesce(max(job_id),0) as jobid FROM `{project_id}.{audit_dataset}.log_job_details` WHERE batch_id = {batch_id}")
        job_id = "1"
        for row in job_id_query.result():
            if row.jobid is not None:
                job_id = row.jobid
        return job_id
    except Exception as e:
        print("EXEPTION GET MAX JOB ",e)
        return  e

# spmena-unecorn-zn-apac-dv.audit_zn.log_incremental_position_details
def get_last_date(key, inc_date,  table,project_id, audit_dataset, batch_id):
    try:
        if key != 'Historical':
            inc_end_date_query = client.query(
                f"SELECT inc_end_date as inc_end_date FROM `{project_id}.{audit_dataset}.log_incremental_position_details` WHERE table_name='{table}' and status='Success' order by inc_end_date desc limit 1")
            inc_end_date = inc_date
            for row in inc_end_date_query.result():
                if row.inc_end_date is not None:
                    inc_end_date = row.inc_end_date
            return inc_end_date
        else : return inc_date
    except Exception as e:
        print("EXEPTION GET MAX JOB ",e)
        return  e


def parse_datetime(input_string):
    try:
        datetime_object = datetime.datetime.strptime(input_string, "%Y-%m-%dT%H:%M:%S.%fZ")
        return datetime_object.strftime("%Y-%m-%d %H:%M:%S")
    except ValueError:
        print("Invalid input string format. Please use the format YYYY-MM-DDTHH:MM:SS.ffffffZ")
        return None

def get_audit_data(data, table_id, project_id, audit_dataset, gcs_folder):
    try:
        key = table_id
        print(key)
        batch_id = get_max_batch_id(project_id, audit_dataset)

        if key == "log_batch_details":
            data = {
                "batch_id": batch_id + 1,
                "batch_name": data['name'],
                "batch_type": data['type'],
                "state": data['state'],
                "start_time": parse_datetime(data['start_date']),
                "end_time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "frequency": data['frequency'],
                "phase": data['phase'],
            }

        elif key == "log_job_details":
            data = {
                "batch_id": batch_id,
                "job_id": get_max_job_id(project_id, audit_dataset, batch_id ) + 1,
                # "dag_id": data['dag_id'],
                "job_name": data['task_id'],
                "table_name": data['table_name'],
                "start_date": parse_datetime(data['start_date']),
                "end_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "status": data['state'],
                "error_description": gcs_folder if gcs_folder is not None else " - "
            }

        elif key == "log_incremental_position_details":

            end_date = get_last_date(data['load_type'], data['inc_start_time'], data['entity_name'], project_id, audit_dataset, batch_id)
            
            if data['load_type'] == 'Historical':
                end_date = data['start_date']
            data = {
                "batch_id": batch_id,
                "table_name": data['entity_name'],
                # "column":data['column'],
                # "entry_timestamp": get_entry_timestamp(),
                "inc_start_date": end_date.strftime("%Y-%m-%d %H:%M:%S"),
                # "inc_end_date": data['end_name'],
                "inc_end_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "status": data['status'],
                "load_type": data['load_type']
            }
        print(data)
        return data

    except Exception as e:
        print("EXCEPTION GET_Data: ", e)
        return e

    # {
    #   "name": "unecorn_project",
    #   "data":{
    #       "project_id":"spmena-unecorn-zn-apac-dv",
    #       "dataset_id":"audit_zn",
    #       "table_id":"log_batch_details",
    #       "parse_objects":{
    #             "batch_name":"unecorn_batch",
    #             "state":"success",
    #             "start_date":"2024-01-02 18:28:40.685798",
    #             "end_date":"2024-01-02 18:28:40.685798"
    #       }
    #   }
    # }

