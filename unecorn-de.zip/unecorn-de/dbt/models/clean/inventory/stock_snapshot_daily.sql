{{ config(materialized='incremental') }}

{% call set_sql_header(config) %}
DECLARE ref_date DATE;
SET ref_date= (SELECT MAX(snapshot_reference_date) AS ref_date FROM {{ this }});
{%- endcall %}

WITH source_data AS (
    SELECT 
        a.snapshot_type, 
        a.snapshot_timestamp, 
        a.snapshot_reference_date, 
        a.snapshot_day, 
        a.snapshot_week, 
        a.snapshot_month, 
        a.snapshot_year, 
        a.source_system,
        a.system_id,
        a.plant, 
        a.material,
        b.marketplace_code, 
        a.stock_position, 
        a.stock_type, 
        a.unrestricted, 
        a.stock_in_transfer, 
        a.in_quality_inspection, 
        a.restricted_use, 
        a.blocked, 
        `returns`,
        a.plant_country_code,
        a.division,
        CURRENT_TIMESTAMP() AS load_ts
    FROM {{db_source('src_inventory','stock_snapshots_v2')}} AS a
    INNER JOIN {{ref('stock_position')}} AS b
        ON a.stock_position=b.stock_position
    WHERE 
        snapshot_reference_date > ref_date AND
        plant_country_code IN {{variable_macro('country_var2')}} AND
        division IN {{variable_macro('division_var')}} AND
        snapshot_type={{variable_macro('daily_var')}}
)

SELECT * FROM source_data