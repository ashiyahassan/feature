{{ 
  config(
    materialized='incremental',
    unique_key='sku_code'
  ) 
}}

WITH source_data AS (
    SELECT sales_status AS sd_status, 
    sales_status_description AS sd_status_description, 
    internal_product_code AS sku_code,
    sales_organization,
    distribution_channel,
    meta_validity_from, 
    meta_validity_to, 
    meta_loading_date,
    running_date,
    CURRENT_TIMESTAMP() AS load_ts
    FROM {{db_source('src_product_v3','sku_sales_area_v3')}}   
    WHERE sales_organization IN {{variable_macro('sales_organization_var')}}
    AND distribution_channel IN {{variable_macro('distribution_channel_var')}}
    {% if is_incremental() %}

    -- this filter will only be applied on an incremental run
    -- (uses > to include records whose timestamp occurred since the last run of this model)
    AND running_date > (SELECT MAX(running_date) FROM {{ this }})

    {% endif %}
)

SELECT * FROM source_data
