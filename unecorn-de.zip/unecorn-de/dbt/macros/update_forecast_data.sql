{% macro update_forecast_data(dataset_name, table_name, clone_table_name) %}
 
{% set project_id = target.project %}
 
{% if execute %}

    {{ print("Running update_forecast_data: "~ dataset_name ~", "~ table_name~","~project_id) }}
    EXECUTE IMMEDIATE '''
        UPDATE `{{ project_id }}.{{ dataset_name }}.{{ table_name }}` AS target_table
        SET consensus_forecast = main.consensus_forecast,
            validated_forecast = main.validated_forecast,
            comments_consensus = main.comments_consensus,
            comments_validated = main.comments_validated 
        FROM 
        (
            SELECT 
                forecast_gen_date, 
                ean_code, 
                platform_code, 
                country_code, 
                division_code,
                campaign_type, 
                forecast_date, 
                consensus_forecast,
                validated_forecast,
                comments_consensus,
                comments_validated, 
                load_ts
            FROM `{{ project_id }}.{{ dataset_name }}.{{ clone_table_name }}`
            WHERE active_version_flag = 1
            AND ((comments_consensus IS NOT NULL AND comments_consensus <> '') 
            OR (comments_validated IS NOT NULL AND comments_validated <> ''))
        ) AS main
        WHERE 
            target_table.ean_code = main.ean_code
            AND target_table.forecast_date = main.forecast_date
            AND target_table.forecast_gen_date = main.forecast_gen_date
            AND target_table.platform_code = main.platform_code
            AND target_table.country_code = main.country_code
            AND target_table.division_code = main.division_code
            AND target_table.campaign_type = main.campaign_type            
            AND active_version_flag = 1;
    ''' 
{% endif %}
{{ print("completed update_forecast_data: ") }} 
{% endmacro %}
 