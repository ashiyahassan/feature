{{ config(materialized='table') }}

SELECT 
    destination_system,
    hub_plant,
    sales_org,
    sku_code,
    ean_code,
    plant_country_code,
    plant_country_code_desc,
    division_amaas,
    CURRENT_TIMESTAMP() AS load_ts
FROM
(
    SELECT 
        destination_system,
        hub_plant,
        sales_org,
        sku_code,
        ean_code,
        plant_country_code,
        plant_country_code_desc,
        division_amaas,
        --row_number() over (partition by ean_code order by  desc) row_number latest_sku_code
        ROW_NUMBER() OVER (PARTITION BY ean_code ORDER BY SUBSTR(sku_code,-2) DESC) latest_sku_code
    FROM 
    (
        SELECT DISTINCT
            a.destination_system,
            a.hub_plant,
            a.sales_org,
            b.sku_code,
            b.ean_code,
            a.plant_country_code,
            a.plant_country_code_desc,
            a.division_amaas
        FROM {{ref('sales_forecast_daily_v1')}} AS a
        RIGHT JOIN
        (
            SELECT * FROM
            (
                SELECT DISTINCT 
                    sku_code,
                    ean_code,
                    ROW_NUMBER() OVER (PARTITION BY ean_code, sku_code ORDER BY meta_validity_from DESC) latest_row
                FROM {{ref('sku_v1')}}
                WHERE source_system = {{variable_macro('ecc_var')}}
                    AND ean_code IS NOT NULL
                    AND ean_code<>''
            )
            WHERE latest_row = 1
        ) AS b
        ON a.sku_code=b.sku_code
    )
)
WHERE latest_sku_code = 1