{{ config(materialized='view') }}

WITH file_version_data AS (      
    SELECT 
        file_version,
        version_month,
        marketplace_code, 
        signature_code 
    FROM 
    (
        SELECT 
        *, 
        ROW_NUMBER() OVER(PARTITION BY version_month, marketplace_code, signature_code ORDER BY file_version DESC) AS row_num
        FROM
        (
            SELECT DISTINCT
                camp.file_version,
                DATE_TRUNC(camp.date, MONTH) AS version_month,
                camp.platform AS marketplace_code, 
                camp.signature AS signature_code
            FROM {{db_source('src_campaign','vw_non_optimus_calendar_v2')}} AS camp
            WHERE camp.country IN {{variable_macro('country_var')}}
            AND camp.division IN {{variable_macro('division_var')}}
            AND camp.platform IN {{variable_macro('platform_var')}}   
            AND camp.signature <> 'OAP'   
        )
    )
    WHERE row_num = 1
),
source_data AS (
    SELECT 
        camp.file_version,
        camp.year,
        camp.month,
        camp.day,
        camp.date,
        camp.start_date,
        camp.end_date,
        camp.platform AS marketplace_code,
        camp.country,
        camp.signature AS signature_code,
        camp.store_or_franchise,
        camp.phasing AS campaign_title,
        camp.campaign_type,
        camp.campaign_name,    
        camp.division,
        camp.file_name,
        camp.insert_timestamp,
        camp.update_timestamp,
        -- ROW_NUMBER() OVER(PARTITION BY year, month, day, platform,country,signature,division ORDER BY file_version DESC) AS row_num
    FROM {{db_source('src_campaign','vw_non_optimus_calendar_v2')}} AS camp
    INNER JOIN file_version_data AS f_version
    ON camp.file_version = f_version.file_version
    AND DATE_TRUNC(camp.date, MONTH) = f_version.version_month
    AND camp.platform = f_version.marketplace_code
    AND camp.signature = f_version.signature_code
    WHERE camp.country IN {{variable_macro('country_var')}}
    AND camp.division IN {{variable_macro('division_var')}}
    AND camp.platform IN {{variable_macro('platform_var')}}   
    AND camp.signature <> 'OAP'   
)

SELECT
    file_version,
    year,
    month,
    day,
    CAST(`date` AS DATE) AS `date`,
    start_date,
    end_date,
    marketplace_code,
    country,
    signature_code,
    store_or_franchise,
    campaign_title,
    campaign_type,
    campaign_name,    
    division,
    file_name,
    insert_timestamp,
    update_timestamp,
FROM source_data