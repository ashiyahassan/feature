{{ 
  config(
    materialized='incremental',
    unique_key=['ean_code', 'sku_code', 'a1252_modification_date', 'source_system']
  ) 
}}

WITH source_data AS (
  SELECT
    a.a0001_internal_product_code AS sku_code,
    -- a.a0003_cu_gtin_code AS ean_code,
    CAST(REGEXP_REPLACE(a.a0003_cu_gtin_code, r'^0+', '') AS STRING) AS ean_code,
    a.a1128_compass_code AS compass_code,
    a.a0218_codifier_product_logistic_description AS global_description,
    a.hero_sku_flag AS hero_flag,
    -- CAST(CASE WHEN a.hero_sku_flag IS NULL THEN 'false' ELSE a.hero_sku_flag END AS BOOL) AS hero_flag,
    a.source_system,
    a.a0939_operational_division,
    a.source_catalog_name,
    a.meta_validity_from,
    a.meta_validity_to,
    a.meta_loading_date,
    a.a1252_modification_date,
    a.material_type, 
    a.material_group, 
    a.material_group_description, 
    a.material_type_description,
    CURRENT_TIMESTAMP() AS load_ts
    FROM
      {{db_source('src_product_v3','sku_v3')}} AS a    
    WHERE
      a.source_system = {{variable_macro('elixpedia_var')}}
      AND a.a0939_operational_division IN {{variable_macro('operational_division_var')}}
      AND a.a0003_cu_gtin_code IS NOT NULL
      {% if is_incremental() %}

        -- this filter will only be applied on an incremental run
        -- (uses > to include records whose timestamp occurred since the last run of this model)
        AND a1252_modification_date > (SELECT MAX(a1252_modification_date) FROM {{ this }} WHERE source_system = {{variable_macro('elixpedia_var')}})

      {% endif %}

  UNION ALL

  SELECT
    a.a0001_internal_product_code AS sku_code,
    -- a.a0003_cu_gtin_code AS ean_code,
    CAST(REGEXP_REPLACE(a.a0003_cu_gtin_code, r'^0+', '') AS STRING) AS ean_code,
    a.a1128_compass_code AS compass_code,
    a.a0218_codifier_product_logistic_description AS global_description,
    a.hero_sku_flag AS hero_flag,
    -- CAST(CASE WHEN a.hero_sku_flag IS NULL THEN 'false' ELSE a.hero_sku_flag END AS BOOL) AS hero_flag,
    a.source_system,
    a.a0939_operational_division,
    a.source_catalog_name,
    a.meta_validity_from,
    a.meta_validity_to,
    a.meta_loading_date,
    a.a1252_modification_date,
    a.material_type, 
    a.material_group, 
    a.material_group_description, 
    a.material_type_description,
    CURRENT_TIMESTAMP() AS load_ts
    FROM
      {{db_source('src_product_v3','sku_v3')}} AS a    
    WHERE
      a.source_system = {{variable_macro('ecc_var')}}
      AND a.a0939_operational_division IN {{variable_macro('operational_division_20_var')}}
      AND a.a0003_cu_gtin_code IS NOT NULL
      {% if is_incremental() %}

        -- this filter will only be applied on an incremental run
        -- (uses > to include records whose timestamp occurred since the last run of this model)
        AND a1252_modification_date > (SELECT MAX(a1252_modification_date) FROM {{ this }} WHERE source_system = {{variable_macro('ecc_var')}})

      {% endif %}
)

SELECT * FROM source_data
