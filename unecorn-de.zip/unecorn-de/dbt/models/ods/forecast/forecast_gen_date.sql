{{ config(materialized='table') }}

WITH source_data AS (
    SELECT DISTINCT
        forecast_gen_date AS gen_date,
        FORMAT_DATE('%Y%m',forecast_gen_date) AS year_month_code       
    FROM {{ref('fact_daily_forecast_explosion')}}
)

SELECT *, CURRENT_TIMESTAMP() AS load_ts
FROM source_data