-- depends_on: {{ ref('unecorn_ean_details') }}

{{ 
    config(
        materialized='incremental',
         pre_hook =[
            "{{ delete_m0_old_version_data('cds_unecorn_process_zn', 'fact_monthly_kpi', 'fact_daily_forecast') }}"
        ]
    ) 
}}

WITH valid__kpi_date AS (
    SELECT 
        forecast_gen_date,
        FORMAT_DATE('%Y-%m', forecast_gen_date) AS forecast_month, 
        load_ts AS max_load_ts
    FROM 
    (
        SELECT forecast_gen_date, load_ts,
        ROW_NUMBER() OVER (PARTITION BY forecast_gen_date ORDER BY load_ts DESC) AS row_num
        FROM 
        (
            SELECT DISTINCT forecast_gen_date, load_ts
            FROM {{ref('fact_daily_forecast')}} 
            -- WHERE forecast_gen_date <=  DATE_TRUNC(CURRENT_DATE(), MONTH) 
            {% if is_incremental() %}
            WHERE forecast_gen_date = (SELECT MAX(forecast_gen_date) FROM {{ref('fact_daily_forecast')}} 
            WHERE active_version_flag = 1 AND active_month_flag = 1)
            {% endif %}                      
        )
    )
    WHERE row_num = 1
),
monthly_forecast AS (
    SELECT  
        forecast_sk, 
        a.ean_code, 
        a.forecast_gen_date,
        a.platform_code,a.platform_name,
        a.country_code,
        a.division_code,
        a.campaign_type, 
        ai_model_forecast,  
        consensus_forecast, 
        validated_forecast, 
        m_1_ai_fc, 
        m_1_validated_fc,  
        m_1_consensus_fc,
        m_3_ai_fc, 
        m_3_validated_fc, 
        m_3_consensus_fc,
        -- COALESCE(actual_units,0) AS actual_units
        actual_units
    FROM
    (
        (
            SELECT  
                forecast_sk, 
                ean_code, 
                a.forecast_gen_date,
                platform_code,
                platform_name, 
                country_code,
                division_code,
                campaign_type, 
                SUM(ai_model_forecast) AS ai_model_forecast,
                SUM(consensus_forecast) AS consensus_forecast, 
                SUM(validated_forecast) AS validated_forecast,
                SUM(m_1_ai_fc) AS m_1_ai_fc,
                SUM(m_1_validated_fc) AS m_1_validated_fc,
                SUM(m_1_consensus_fc) AS m_1_consensus_fc,
                SUM(m_3_ai_fc) AS m_3_ai_fc,
                SUM(m_3_validated_fc) AS m_3_validated_fc, 
                SUM(m_3_consensus_fc) AS m_3_consensus_fc  
            FROM {{ref('fact_daily_forecast')}} AS a
            INNER JOIN valid__kpi_date AS b
            ON a.forecast_gen_date=b.forecast_gen_date
            AND FORMAT_DATE('%Y-%m', forecast_date)=forecast_month
            AND a.active_version_flag = 1
            --where a.forecast_gen_date='2023-11-01' 
            --and ean_code='8935274666459'
            WHERE a.forecast_date <= (SELECT MAX(sellout_date) FROM {{ref('fact_sellout_daily')}})
            GROUP BY forecast_sk, ean_code, forecast_gen_date,platform_code,platform_name, country_code,division_code,campaign_type
        ) AS a
        LEFT JOIN 
        (
            SELECT 
                product_sk, 
                country_code, 
                division_name, 
                platform_code, 
                platform_name,
                campaign_type,  
                month_date,
                ean_code,  
                actual_units 
            FROM
            (
                SELECT 
                    product_sk, 
                    a.country_code, 
                    division_name, 
                    a.platform_code, 
                    a.platform_name,
                    campaign_type, 
                    DATE_TRUNC(sellout_date, MONTH) AS month_date,
                    ean_code, 
                    SUM(delivered_units) AS actual_units  
                FROM {{ref('fact_sellout_daily')}} AS a
                WHERE sellout_date >'2022-12-31'
                --and ean_code='8935274666459'
                GROUP BY  product_sk, a.country_code, division_name, a.platform_code, a.platform_name,campaign_type ,DATE_TRUNC(sellout_date, MONTH) , ean_code
            )
        ) AS b
        ON a.ean_code=b.ean_code
        AND a.platform_code=b.platform_code
        AND a.country_code=b.country_code
        AND a.campaign_type=b.campaign_type
        AND forecast_gen_date=month_date
    )
),
bom_type AS (
    SELECT DISTINCT
        bom_header_ean_code,
        local_bom_type_description
    FROM {{ref('dim_bom_explosion_factor')}}
),
bom_explosion AS (
    SELECT DISTINCT 
        bom_header_ean_code,
        component_ean_code,
        m_factor*component_quantity AS mf,
        local_bom_type_description 
    FROM {{ref('dim_bom_explosion_factor')}} 
    WHERE component_ean_code NOT IN (' ','')
),
unecorn_details AS (
    SELECT 
        unecorn_lifecycle,
        ean_code,
        marketplace_code,   
        CASE
            WHEN marketplace_code = {{variable_macro('shopee_vn_var')}} THEN {{variable_macro('shp_lower_var')}}
            WHEN marketplace_code = {{variable_macro('lazada_vn_var')}} THEN {{variable_macro('lzd_lower_var')}}
            WHEN marketplace_code = {{variable_macro('tiktok_vn_var')}} THEN {{variable_macro('tiktok_lower_var')}}
        ELSE
            marketplace_code
        END AS marketplace_name,
        {% if is_incremental() == false %}
        forecast_gen_date
        {% endif %}
    FROM
        {% if is_incremental() %}
        {{ref('unecorn_ean_details')}}
        {% else %}
        {{ref('unecorn_ean_details_history')}}
        {% endif %}
),
all_forecasts AS (
-- ----------------------------Single+PB+VB ---------------------------

SELECT 
    ean_code, 
    a.forecast_gen_date,
    platform_name, 
    country_code,
    division_code,
    campaign_type,
    COALESCE(b.local_bom_type_description,'Single') AS local_bom_type_description,
    'Single+PB+VB' AS bundle_explosion, 
    ai_model_forecast, 
    consensus_forecast,  
    validated_forecast, 
    m_1_ai_fc,
    m_1_validated_fc, 
    m_1_consensus_fc,
    m_3_ai_fc, 
    m_3_validated_fc,  
    m_3_consensus_fc,
    actual_units 
FROM monthly_forecast AS a
LEFT JOIN bom_type AS b
ON ean_code=bom_header_ean_code

UNION ALL 
----------------------------VB+Single---------------------------
SELECT  
    ean_code, 
    forecast_gen_date,
    platform_name, 
    country_code,
    division_code,
    campaign_type,
    local_bom_type_description,
    bundle_explosion, 
    SUM(ai_model_forecast),
    SUM(consensus_forecast),  
    SUM(validated_forecast), 
    SUM(m_1_ai_fc),
    SUM(m_1_validated_fc), 
    SUM(m_1_consensus_fc),
    SUM(m_3_ai_fc), 
    SUM(m_3_validated_fc),  
    SUM(m_3_consensus_fc),
    SUM(actual_units)
FROM 
(
    SELECT  
        ean_code, 
        a.forecast_gen_date,
        platform_name, 
        country_code,
        division_code,
        campaign_type, 
        ai_model_forecast, 
        consensus_forecast,  
        validated_forecast, 
        m_1_ai_fc,
        m_1_validated_fc, 
        m_1_consensus_fc,
        m_3_ai_fc, 
        m_3_validated_fc,  
        m_3_consensus_fc,
        actual_units,
        COALESCE(b.local_bom_type_description,'Single') AS local_bom_type_description,
        'VB+Single' AS bundle_explosion  
    FROM monthly_forecast AS a
    LEFT JOIN bom_type AS b
    ON ean_code=bom_header_ean_code
    WHERE b.local_bom_type_description <>'PB' OR b.local_bom_type_description IS NULL

    UNION ALL

    SELECT 
        component_ean_code, 
        a.forecast_gen_date,
        platform_name, 
        country_code,
        division_code,
        campaign_type, 
        mf*ai_model_forecast AS ai_model_forecast, 
        mf*consensus_forecast AS consensus_forecast,  
        mf*validated_forecast AS validated_forecast, 
        mf*m_1_ai_fc AS m_1_ai_fc,
        mf*m_1_validated_fc AS m_1_validated_fc, 
        mf*m_1_consensus_fc AS m_1_consensus_fc,
        mf*m_3_ai_fc AS m_3_ai_fc, 
        mf*m_3_validated_fc AS m_3_validated_fc,
        mf*m_3_consensus_fc AS m_3_consensus_fc,
        mf*actual_units AS actual_units,
        'Single' AS local_bom_type_description,
        'VB+Single' AS bundle_explosion  
    FROM monthly_forecast AS a
    LEFT JOIN bom_explosion AS b
    ON ean_code=bom_header_ean_code
    WHERE b.local_bom_type_description = 'PB'
)
GROUP BY  ean_code, forecast_gen_date,platform_name, country_code,division_code,campaign_type,local_bom_type_description , bundle_explosion

----------------------------PB+Single---------------------------

UNION ALL 

SELECT  
    ean_code, 
    forecast_gen_date,
    platform_name, 
    country_code,
    division_code,
    campaign_type,
    local_bom_type_description, 
    bundle_explosion, 
    SUM(ai_model_forecast),
    SUM(consensus_forecast),  
    SUM(validated_forecast), 
    SUM(m_1_ai_fc),
    SUM(m_1_validated_fc), 
    SUM(m_1_consensus_fc),
    SUM(m_3_ai_fc), 
    SUM(m_3_validated_fc),  
    SUM(m_3_consensus_fc),
    SUM(actual_units)
FROM 
(
    SELECT  
        ean_code, 
        a.forecast_gen_date,
        platform_name, 
        country_code,
        division_code,
        campaign_type, 
        ai_model_forecast, 
        consensus_forecast,  
        validated_forecast, 
        m_1_ai_fc,
        m_1_validated_fc, 
        m_1_consensus_fc,
        m_3_ai_fc, 
        m_3_validated_fc,  
        m_3_consensus_fc,actual_units,
        COALESCE(b.local_bom_type_description,'Single') AS local_bom_type_description,
        'PB+Single' AS bundle_explosion  
    FROM monthly_forecast AS a
    LEFT JOIN bom_type AS b
    ON ean_code=bom_header_ean_code
    WHERE b.local_bom_type_description <>'VB' OR b.local_bom_type_description IS NULL

    UNION ALL

    SELECT 
        component_ean_code, 
        a.forecast_gen_date,
        platform_name, 
        country_code,
        division_code,
        campaign_type, 
        mf*ai_model_forecast AS ai_model_forecast, 
        mf*consensus_forecast AS consensus_forecast,  
        mf*validated_forecast AS validated_forecast, 
        mf*m_1_ai_fc AS m_1_ai_fc,
        mf*m_1_validated_fc AS m_1_validated_fc, 
        mf*m_1_consensus_fc AS m_1_consensus_fc,
        mf*m_3_ai_fc As m_3_ai_fc, 
        mf*m_3_validated_fc AS m_3_validated_fc,
        mf*m_3_consensus_fc AS m_3_consensus_fc,
        mf*actual_units AS actual_units,
        'Single' AS local_bom_type_description,
        'PB+Single' AS bundle_explosion  
    FROM monthly_forecast AS a
    LEFT JOIN bom_explosion AS b
    ON ean_code=bom_header_ean_code
    WHERE b.local_bom_type_description = 'VB'
)
GROUP BY  ean_code, forecast_gen_date,platform_name, country_code,division_code,campaign_type,local_bom_type_description , bundle_explosion


----------------------------Single---------------------------

UNION ALL

SELECT  
    ean_code, 
    forecast_gen_date,
    platform_name, 
    country_code,
    division_code,
    campaign_type,
    local_bom_type_description, 
    bundle_explosion, 
    SUM(ai_model_forecast),
    SUM(consensus_forecast),  
    SUM(validated_forecast), 
    SUM(m_1_ai_fc),
    SUM(m_1_validated_fc), 
    SUM(m_1_consensus_fc),
    SUM(m_3_ai_fc), 
    SUM(m_3_validated_fc),  
    SUM(m_3_consensus_fc),
    SUM(actual_units)
FROM 
(
    SELECT  
        ean_code, 
        a.forecast_gen_date,
        platform_name, 
        country_code,
        division_code,
        campaign_type, 
        ai_model_forecast, 
        consensus_forecast,  
        validated_forecast, 
        m_1_ai_fc,
        m_1_validated_fc, 
        m_1_consensus_fc,
        m_3_ai_fc, 
        m_3_validated_fc,  
        m_3_consensus_fc,
        actual_units,
        COALESCE(b.local_bom_type_description,'Single') AS local_bom_type_description,
        'Single' AS bundle_explosion  
    FROM monthly_forecast AS a
    LEFT JOIN bom_type AS b
    ON ean_code=bom_header_ean_code
    WHERE b.local_bom_type_description NOT IN ('VB','PB') OR b.local_bom_type_description IS NULL

    UNION ALL

    SELECT 
        component_ean_code, 
        a.forecast_gen_date,
        platform_name, 
        country_code,
        division_code,
        campaign_type, 
        mf*ai_model_forecast AS ai_model_forecast, 
        mf*consensus_forecast AS consensus_forecast,  
        mf*validated_forecast As validated_forecast, 
        mf*m_1_ai_fc AS m_1_ai_fc,
        mf*m_1_validated_fc AS m_1_validated_fc, 
        mf*m_1_consensus_fc AS m_1_consensus_fc,
        mf*m_3_ai_fc AS m_3_ai_fc, 
        mf*m_3_validated_fc AS m_3_validated_fc,
        mf*m_3_consensus_fc AS m_3_consensus_fc,
        mf*actual_units AS actual_units,
        'Single' AS local_bom_type_description,
        'Single' AS bundle_explosion  
    FROM monthly_forecast AS a
    LEFT JOIN bom_explosion AS b
    ON ean_code=bom_header_ean_code
    WHERE b.local_bom_type_description IN ('VB','PB')
)
GROUP BY  ean_code, forecast_gen_date,platform_name, country_code,division_code,campaign_type,local_bom_type_description , bundle_explosion

)

SELECT
    dp.forecast_sk,
    -- FORMAT_DATE('%Y%m%d',CAST(sd.forecast_gen_date AS date)) AS date_sk,
    dim_date.date_key AS date_sk,
    bet.bundle_sk,
    sd.ean_code, 
    EXTRACT(YEAR FROM sd.forecast_gen_date) AS forecast_year,
    sd.forecast_gen_date AS forecast_date,
   -- sd.forecast_gen_date,
    sd.actual_units AS actuals,   
    sd.platform_name, 
    sd.country_code,
    sd.division_code,
    sd.campaign_type,
    sd.local_bom_type_description AS bundle_type,
    -- '' AS bundle_type,
    sd.bundle_explosion, 
    sd.ai_model_forecast, 
    sd.consensus_forecast,  
    sd.validated_forecast, 
    sd.m_1_ai_fc,
    sd.m_1_validated_fc, 
    sd.m_1_consensus_fc,
    sd.m_3_ai_fc, 
    sd.m_3_validated_fc,  
    sd.m_3_consensus_fc,
    ud.unecorn_lifecycle AS lifecycle,
    CURRENT_TIMESTAMP() AS load_ts
FROM all_forecasts AS sd 
JOIN 
(
    SELECT 
        product_sk AS forecast_sk,
        ean_code,
        platform_name,
        country_code,
        division_code
    FROM {{ref('dim_product')}}
) AS dp
ON sd.ean_code=dp.ean_code
AND UPPER(sd.platform_name) = UPPER(dp.platform_name)
AND sd.country_code = dp.country_code
AND sd.division_code = dp.division_code
LEFT JOIN unecorn_details AS ud 
ON sd.ean_code = ud.ean_code 
AND sd.platform_name = ud.marketplace_name
{% if is_incremental() == false %}
AND sd.forecast_gen_date = ud.forecast_gen_date
{% endif %}
LEFT JOIN {{ref('dim_date')}} AS dim_date 
ON sd.forecast_gen_date = dim_date.date
LEFT JOIN
(
    SELECT 
        bundle_sk,
        bundle_type,
        bundle_explosion
    FROM {{ref('bundle_explosion_type')}}
) AS bet
ON sd.local_bom_type_description = bet.bundle_type
AND sd.bundle_explosion = bet.bundle_explosion
-- WHERE ud.unecorn_lifecycle IN ('Discont.','dummy_code','Future Launch','Ongoing (modelled)','New Launch (<3M sales)','To be Discont. (modelled)')