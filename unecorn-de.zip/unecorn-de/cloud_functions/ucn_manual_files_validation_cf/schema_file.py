schema_dict = {
 
    "vn_cpd_master_data_forecast": ["ean", "signature", "brand", "sub_brand", "category", "sub_category", "group",
                                    "sub_group", "hero",
                                    "bundle", "material_type", "material_des", "old_ean",
                                    "lzd_status", "lzd_launch_month", "lzd_dc_month",
                                    "shp_status", "shp_launch_month", "shp_dc_month", 
                                    "tiktok_status", "tiktok_launch_month", "tiktok_dc_month",
                                    "unecorn_lzd_status", "unecorn_shp_status", "unecorn_tiktok_status"],
 
    "vn_cpd_dummy_code": ["record_type", "compass_product_code", "product_label", "fm_level_2", "dummy_1", "dummy_2", "dummy_3", "dummy_4", "dummy_5", "dummy_6", "dummy_7", "dummy_8", "dummy_9", "dummy_10", "dummy_11", "signature", "signature_description", "brand", "brand_description", "sub_brand", "sub_brand_description", "reference_code", "reference_code_description", "attribute_n_5", "axe_code", "axe_code_description", "subaxe_code", "subaxe_code_description", "class_code", "class_code_description", "function_code", "function_code_description", "fm_material_type", "fm_material_group", "fm_sales_status", "attribute_n_13", "material", "attribute_n_15", "attribute_n_16", "compass_product_code", "attribute_n_18", "business_units", "compass_channel_code"]
 
}
sheet_dict = {
    "vn_cpd_master_data_forecast": "masterdata"
}
 
run_validation_dict = {
    "vn_cpd_master_data_forecast": True,
    "vn_cpd_dummy_code": False
}
 
merge_dict = {
    "vn_cpd_master_data_forecast": True,
    "vn_cpd_dummy_code": True
}
 

 
def merge_query_dict_function(master_table, stage_table, file_key, schematext):
    query_dict = {
        "vn_cpd_master_data_forecast":  f"""
        MERGE INTO `{master_table}` AS target
    USING (
       SELECT
           `{stage_table}`.ean AS join_key,
           `{stage_table}`.*
       FROM `{stage_table}`
       UNION ALL
       SELECT
           NULL AS join_key,
           `{stage_table}`.*
       FROM `{stage_table}`
       JOIN (SELECT * FROM `{master_table}` WHERE active_status = 'Y') AS `{master_table}`
           ON `{stage_table}`.ean = `{master_table}`.ean
       WHERE `{stage_table}`.hash_map <> `{master_table}`.hash_map
    ) AS source
    ON source.join_key = target.ean
 
    WHEN MATCHED AND
       source.hash_map <> target.hash_map AND target.active_status = 'Y'
    THEN
       UPDATE SET
           active_status = 'N',
           modified_date = CAST(CURRENT_TIMESTAMP() AS STRING)
 
    WHEN NOT MATCHED THEN
       INSERT ({schematext},hash_map)
       VALUES (
            source.ean, source.signature, source.brand, source.`sub_brand`, source.category, source.`sub_category`, source.`group`, source.`sub_group`, source.hero, source.bundle, source.material_type, source.material_des, source.`old_ean`, source.lzd_status, source.lzd_launch_month, source.lzd_dc_month, source.shp_status, source.shp_launch_month, source.shp_dc_month, source.tiktok_status, source.tiktok_launch_month, source.tiktok_dc_month, source.unecorn_lzd_status, source.unecorn_shp_status, source.unecorn_tiktok_status, '1', source.country_code, CAST(CURRENT_TIMESTAMP() AS STRING), CAST(CURRENT_TIMESTAMP() AS STRING), 'Y', source.hash_map)
 
    WHEN NOT MATCHED BY SOURCE THEN
       UPDATE SET
           active_status = 'N',
           modified_date = CAST(CURRENT_TIMESTAMP() AS STRING)
        """,
        "vn_cpd_dummy_code":f"""MERGE INTO `{master_table}` AS target
    USING (
       SELECT
           `{stage_table}`.compass_product_code AS join_key,
           `{stage_table}`.*
       FROM `{stage_table}`
       UNION ALL
       SELECT
           NULL AS join_key,
           `{stage_table}`.*
       FROM `{stage_table}`
       JOIN `{master_table}`
           ON `{stage_table}`.compass_product_code = `{master_table}`.compass_product_code
       WHERE `{stage_table}`.hash_map <> `{master_table}`.hash_map
    ) AS source
    ON source.join_key = target.compass_product_code
 
    WHEN MATCHED AND
       source.hash_map <> target.hash_map AND target.active_status = 'Y'
    THEN
       UPDATE SET
           active_status = 'N',
           modified_date = CAST(CURRENT_TIMESTAMP() AS STRING)
 
    WHEN NOT MATCHED THEN
       INSERT ({schematext},hash_map)
       VALUES (
       source.record_type, source.compass_product_code, source.product_label, source.fm_level_2, source.dummy_1, source.dummy_2, source.dummy_3, source.dummy_4, source.dummy_5, source.dummy_6, source.dummy_7, source.dummy_8, source.dummy_9, source.dummy_10, source.dummy_11, source.signature, source.signature_description, source.brand, source.brand_description, source.sub_brand, source.sub_brand_description, source.reference_code, source.reference_code_description, source.attribute_n_5, source.axe_code, source.axe_code_description, source.subaxe_code, source.subaxe_code_description, source.class_code, source.class_code_description, source.function_code, source.function_code_description, source.fm_material_type, source.fm_material_group, source.fm_sales_status, source.attribute_n_13, source.material, source.attribute_n_15, source.attribute_n_16, source.compass_product_code, source.attribute_n_18, source.material, source.business_units, source.compass_channel_code, CAST(CURRENT_TIMESTAMP() AS STRING),'Y',source.hash_map)
 
    WHEN NOT MATCHED BY SOURCE THEN
       UPDATE SET
           active_status = 'N',
           modified_date = CAST(CURRENT_TIMESTAMP() AS STRING) """
 
    }
 
    return query_dict[file_key]