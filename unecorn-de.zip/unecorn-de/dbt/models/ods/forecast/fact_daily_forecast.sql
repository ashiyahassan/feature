-- depends_on: {{ ref('unecorn_ean_details') }}
-- depends_on: {{ ref('fact_monthly_forecast') }}

{{ 
    config(
        materialized='incremental',
        pre_hook = [
            "{{ update_active_flag('cds_unecorn_process_zn','fact_daily_forecast') }}"
        ], 
        post_hook =[
             "{{ upd_active_ver_flag('cds_unecorn_process_zn','fact_daily_forecast') }}"
        ],
        partition_by = {
            "field": "forecast_gen_date",
            "data_type": "date",
            "granularity": "day"
        }
    ) 
}}

WITH model_run_date AS ( 
    SELECT * FROM (
    SELECT 
        CAST(model_run_date AS DATE) AS model_run_date,
        CAST(LAG(model_run_date) OVER(ORDER BY model_run_date) AS DATE) AS m1_date,
        CAST(LAG(model_run_date,3) OVER(ORDER BY model_run_date) AS DATE) AS m3_date  
    FROM 
    (SELECT DISTINCT model_run_date 
    FROM {{db_source('src_ml_output_zone','model_daily_forecast')}}
    ORDER BY model_run_date )  ORDER BY model_run_date ) 
    {% if is_incremental() %}
    WHERE  model_run_date >= (SELECT CAST(MAX(model_run_date) AS DATE) FROM {{db_source('src_ml_output_zone','model_daily_forecast')}})
    {% endif %}
),
dim_date AS (
    SELECT 
        d.date,
        d.month,
        m.model_run_date,
        'M' || CAST((EXTRACT(YEAR FROM d.date) - EXTRACT(YEAR FROM m.model_run_date)) * 12 
           + (EXTRACT(MONTH FROM d.date) - EXTRACT(MONTH FROM m.model_run_date)) AS STRING) AS fca_month
    FROM {{ref('dim_date')}} AS d
    JOIN 
    (
        SELECT 
            CAST(model_run_date.model_run_date AS DATE) AS model_run_date 
        FROM model_run_date
        WHERE model_run_date.model_run_date > '2023-12-31'
    ) AS m
    ON
    d.start_of_month >= m.model_run_date AND d.start_of_month <= date_add( m.model_run_date , interval 3 MONTH)
),
dim_product_data AS (
    SELECT * 
    FROM 
    (
        SELECT 
            u.forecast_gen_date, 
            u.ean_code, 
            p.platform_code,
            p.signature_name,
            p.signature_code
        FROM {{ref('unecorn_ean_details_history')}} AS u
        JOIN 
        (
            SELECT 
            CAST(model_run_date.model_run_date AS DATE) AS model_run_date 
            FROM model_run_date
            WHERE model_run_date.model_run_date > '2023-12-31'
        ) AS m
        ON u.forecast_gen_date = m.model_run_date
        INNER JOIN {{ref('dim_product')}}  AS p
        ON u.ean_code = p.ean_code AND u.marketplace_code = p.platform_code
        WHERE u.unecorn_lifecycle IN('Discont.','New Launch (<3M sales)','Future Launch','Active & Not Modelled')
    ) AS sd
    JOIN dim_date AS d  ON sd.forecast_gen_date = d.model_run_date
),
raw_data_model AS (
    SELECT
        CAST(rd.ean_code AS STRING) AS ean_code,
        CAST(rd.model_run_date AS DATE) AS forecast_gen_date,
        CAST(rd.target_week AS DATE) AS forecast_date,
        rd.fca_month,
        rd.forecast_sales,
        rd.actual_sales,
        rd.marketplace_code,
        product.signature_name,
        product.signature_code,
        rd.load_timestamp AS load_ts
    FROM {{db_source('src_ml_output_zone','model_daily_forecast')}} AS rd
    INNER JOIN (
        SELECT model_run_date, load_timestamp
        FROM (
                SELECT model_run_date, load_timestamp,
                ROW_NUMBER() OVER (PARTITION BY model_run_date ORDER BY load_timestamp DESC) AS row_num
                FROM (
                        SELECT DISTINCT model_run_date, load_timestamp
                        FROM {{db_source('src_ml_output_zone','model_daily_forecast')}}
                )
        )
        WHERE row_num = 1
    ) AS sd
    ON rd.model_run_date = sd.model_run_date AND rd.load_timestamp = sd.load_timestamp
    LEFT JOIN {{ref('dim_product')}} AS product
    ON CAST(rd.ean_code AS STRING) = product.ean_code AND rd.marketplace_code = product.platform_code
),
raw_data AS (
SELECT * FROM  raw_data_model
    UNION ALL (
        SELECT ean_code,
        model_run_date AS forecast_gen_date,
        `date` AS forecast_date,
        fca_month,
        0 AS forecast_sales,
        0 AS actual_sales,
        platform_code,
        signature_name,
        signature_code,
        CURRENT_TIMESTAMP()  AS load_ts
        FROM dim_product_data
    )
),

{% if is_incremental() %}
expanded_forecast_m1 AS (
  SELECT 
    DATE_TRUNC(CURRENT_DATE(), MONTH) AS forecast_gen_date,
    ean_code, 
    platform_code, 
    SUM(ai_model_forecast) AS ai_model_forecast,
    SUM(consensus_forecast) AS consensus_forecast,
    SUM(validated_forecast) AS validated_forecast,
    GENERATE_DATE_ARRAY(
      DATE_TRUNC(forecast_date, MONTH),
      LAST_DAY(forecast_date, MONTH)
    ) AS daily_dates
  FROM {{ref('fact_monthly_forecast')}}
  WHERE forecast_gen_date = DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 1 MONTH)
  AND forecast_date = DATE_ADD(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 3 MONTH)
  AND active_version_flag = 1
  GROUP BY ALL
),

-- Step 2: Flatten the array to one row per day
daily_forecast_m1 AS (
  SELECT 
    forecast_gen_date,
    ean_code,
    platform_code,
    ai_model_forecast,
    consensus_forecast,
    validated_forecast,
    day AS forecast_date,
    EXTRACT(DAY FROM day) AS date_index
  FROM expanded_forecast_m1,
  UNNEST(daily_dates) AS day
),

-- Step 3: Calculate number of days in the month and divide forecast
final_daily_split_m1 AS (
  SELECT
    forecast_gen_date,
    forecast_date,
    ean_code,
    platform_code,    
    CASE
      WHEN date_index > MOD(ai_model_forecast, EXTRACT(DAY FROM LAST_DAY(forecast_date)))
        THEN CAST(((ai_model_forecast - MOD(ai_model_forecast, EXTRACT(DAY FROM LAST_DAY(forecast_date)))) / EXTRACT(DAY FROM LAST_DAY(forecast_date))) AS INT64)
      ELSE CAST(((ai_model_forecast - MOD(ai_model_forecast, EXTRACT(DAY FROM LAST_DAY(forecast_date)))) / EXTRACT(DAY FROM LAST_DAY(forecast_date))) AS INT64) + 1
    END AS ai_model_forecast,
    CASE
      WHEN date_index > MOD(consensus_forecast, EXTRACT(DAY FROM LAST_DAY(forecast_date)))
        THEN CAST(((consensus_forecast - MOD(consensus_forecast, EXTRACT(DAY FROM LAST_DAY(forecast_date)))) / EXTRACT(DAY FROM LAST_DAY(forecast_date))) AS INT64)
      ELSE CAST(((consensus_forecast - MOD(consensus_forecast, EXTRACT(DAY FROM LAST_DAY(forecast_date)))) / EXTRACT(DAY FROM LAST_DAY(forecast_date))) AS INT64) + 1
    END AS consensus_forecast,
    CASE
      WHEN date_index > MOD(validated_forecast, EXTRACT(DAY FROM LAST_DAY(forecast_date)))
        THEN CAST(((validated_forecast - MOD(validated_forecast, EXTRACT(DAY FROM LAST_DAY(forecast_date)))) / EXTRACT(DAY FROM LAST_DAY(forecast_date))) AS INT64)
      ELSE CAST(((validated_forecast - MOD(validated_forecast, EXTRACT(DAY FROM LAST_DAY(forecast_date)))) / EXTRACT(DAY FROM LAST_DAY(forecast_date))) AS INT64) + 1
    END AS validated_forecast
  FROM daily_forecast_m1
),
m_1_data AS (
SELECT DISTINCT
        DATE_TRUNC(CURRENT_DATE(), MONTH) AS forecast_gen_date, 
        forecast_date, 
        ean_code, 
        platform_code, 
        ai_model_forecast,
        consensus_forecast,
        validated_forecast
    FROM {{ this }}
    WHERE forecast_gen_date = DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 1 MONTH)
    AND active_version_flag = 1

    UNION ALL

    SELECT *
    FROM final_daily_split_m1
),
expanded_forecast_m3 AS (
  SELECT 
    DATE_TRUNC(CURRENT_DATE(), MONTH) AS forecast_gen_date,
    ean_code, 
    platform_code, 
    SUM(ai_model_forecast) AS ai_model_forecast,
    SUM(consensus_forecast) AS consensus_forecast,
    SUM(validated_forecast) AS validated_forecast,
    GENERATE_DATE_ARRAY(
      DATE_TRUNC(forecast_date, MONTH),
      LAST_DAY(forecast_date, MONTH)
    ) AS daily_dates
  FROM {{ref('fact_monthly_forecast')}}
  WHERE forecast_gen_date = DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 3 MONTH)
  AND forecast_date IN (DATE_ADD(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 1 MONTH), DATE_ADD(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 2 MONTH), DATE_ADD(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 3 MONTH))
  AND active_version_flag = 1
  GROUP BY ALL
),

-- Step 2: Flatten the array to one row per day
daily_forecast_m3 AS (
  SELECT 
    forecast_gen_date,
    ean_code,
    platform_code,
    ai_model_forecast,
    consensus_forecast,
    validated_forecast,
    day AS forecast_date,
    EXTRACT(DAY FROM day) AS date_index
  FROM expanded_forecast_m3,
  UNNEST(daily_dates) AS day
),

-- Step 3: Calculate number of days in the month and divide forecast
final_daily_split_m3 AS (
  SELECT
    forecast_gen_date,
    forecast_date,
    ean_code,
    platform_code,    
    CASE
      WHEN date_index > MOD(ai_model_forecast, EXTRACT(DAY FROM LAST_DAY(forecast_date)))
        THEN CAST(((ai_model_forecast - MOD(ai_model_forecast, EXTRACT(DAY FROM LAST_DAY(forecast_date)))) / EXTRACT(DAY FROM LAST_DAY(forecast_date))) AS INT64)
      ELSE CAST(((ai_model_forecast - MOD(ai_model_forecast, EXTRACT(DAY FROM LAST_DAY(forecast_date)))) / EXTRACT(DAY FROM LAST_DAY(forecast_date))) AS INT64) + 1
    END AS ai_model_forecast,
    CASE
      WHEN date_index > MOD(consensus_forecast, EXTRACT(DAY FROM LAST_DAY(forecast_date)))
        THEN CAST(((consensus_forecast - MOD(consensus_forecast, EXTRACT(DAY FROM LAST_DAY(forecast_date)))) / EXTRACT(DAY FROM LAST_DAY(forecast_date))) AS INT64)
      ELSE CAST(((consensus_forecast - MOD(consensus_forecast, EXTRACT(DAY FROM LAST_DAY(forecast_date)))) / EXTRACT(DAY FROM LAST_DAY(forecast_date))) AS INT64) + 1
    END AS consensus_forecast,
    CASE
      WHEN date_index > MOD(validated_forecast, EXTRACT(DAY FROM LAST_DAY(forecast_date)))
        THEN CAST(((validated_forecast - MOD(validated_forecast, EXTRACT(DAY FROM LAST_DAY(forecast_date)))) / EXTRACT(DAY FROM LAST_DAY(forecast_date))) AS INT64)
      ELSE CAST(((validated_forecast - MOD(validated_forecast, EXTRACT(DAY FROM LAST_DAY(forecast_date)))) / EXTRACT(DAY FROM LAST_DAY(forecast_date))) AS INT64) + 1
    END AS validated_forecast_m3
  FROM daily_forecast_m3
),
m_3_data AS (
    SELECT DISTINCT
        DATE_TRUNC(CURRENT_DATE(), MONTH) AS forecast_gen_date, 
        forecast_date, 
        ean_code, 
        platform_code, 
        ai_model_forecast,
        consensus_forecast,
        validated_forecast
    FROM {{ this }}
    WHERE forecast_gen_date = DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 3 MONTH)
    AND active_version_flag = 1

    UNION ALL

    SELECT *
    FROM final_daily_split_m3
),
{% endif %}

forecast_data AS (        
    SELECT  CAST(M0.ean_code AS STRING) AS ean_code,
        M0.forecast_gen_date,
        M0.forecast_date,
        M0.fca_month,
        CAST(M0.forecast_sales AS INTEGER) AS forecast_sales,
        CAST(M0.actual_sales AS INTEGER) AS actual_sales,
        M0.signature_code,
        M0.signature_name,
        M0.marketplace_code,
        CAST(M1.m_1_ai_fc AS INTEGER) AS m_1_ai_fc,
        CAST(M1.m_1_ac AS INTEGER) AS m_1_ac, 
        M1.check_model_run_date, 
        M1.check_target_date,
        CAST(M3.m_3_ai_fc AS INTEGER) AS m_3_ai_fc, 
        CAST(M3.m_3_ac AS INTEGER) AS m_3_ac, 
        M3.check_model_run_date_3, 
        M3.check_target_date_3,
        M0.load_ts    
    FROM
        (SELECT
            ean_code ,
            a.forecast_gen_date,
            forecast_date,
            fca_month,
            forecast_sales,
            actual_sales,
            signature_code,
            signature_name,
            marketplace_code,
            load_ts
        FROM raw_data AS a
        INNER JOIN model_run_date AS b
        ON a.forecast_gen_date=b.model_run_date
        ) M0
        LEFT JOIN
        (SELECT
            ean_code ,
            b.model_run_date AS forecast_gen_date,
            forecast_date,
            a.forecast_gen_date AS check_model_run_date,
            forecast_date AS check_target_date,
            fca_month,
            forecast_sales AS m_1_ai_fc,
            actual_sales m_1_ac,
            signature_code,
            marketplace_code,
        FROM raw_data AS a
        INNER JOIN model_run_date AS b
        ON a.forecast_gen_date=b.m1_date
        ) M1
        ON M0.forecast_gen_date=M1.forecast_gen_date
        AND M0.forecast_date=M1.forecast_date
        AND M0.marketplace_code=M1.marketplace_code
        AND M0.signature_code=M1.signature_code
        AND M0.ean_code=M1.ean_code
        LEFT JOIN
        (SELECT
            ean_code ,
            b.model_run_date AS forecast_gen_date,
            forecast_date,
            a.forecast_gen_date AS check_model_run_date_3,
            forecast_date AS check_target_date_3,
            fca_month,
            forecast_sales AS m_3_ai_fc,
            actual_sales m_3_ac,
            signature_code,
            marketplace_code,
        FROM raw_data AS a
        INNER JOIN model_run_date AS b
        ON a.forecast_gen_date=b.m3_date
        ) M3
        ON M0.forecast_gen_date=M3.forecast_gen_date
        AND M0.forecast_date=M3.forecast_date
        AND M0.marketplace_code=M3.marketplace_code
        AND M0.signature_code=M3.signature_code
        AND M0.ean_code=M3.ean_code 
),
unecorn_details AS (
    SELECT 
        unecorn_lifecycle,
        ean_code,
        marketplace_code,
        {% if is_incremental() == false %}
        forecast_gen_date
        {% endif %}
    FROM
        {% if is_incremental() %}
        {{ref('unecorn_ean_details')}}
        {% else %}
        {{ref('unecorn_ean_details_history')}}
        {% endif %}
),
source_data AS (
    SELECT
        forecast.ean_code,
        forecast.forecast_gen_date,
        forecast.forecast_date,
        forecast.fca_month,
        forecast.forecast_sales,
        forecast.actual_sales,
        forecast.signature_name,
        forecast.signature_code,
        'Single' AS bundle_type,
        'Single+PB+VB' AS bundle_explosion,
        CASE WHEN forecast.fca_month IN ("M0", "M1") THEN "ST" ELSE "MT" END AS time_flag,
        dc.campaign_type,
        dc.campaign_sk AS campaign_sk,
        dim_date.date_key AS date_sk,
        CASE
            WHEN product.discontinued_date IS NOT NULL AND PARSE_DATE('%Y-%m', product.discontinued_date) < DATE_TRUNC(forecast.forecast_date, MONTH) THEN 0
            ELSE forecast.forecast_sales
        END AS ai_model_forecast,
        CASE
            WHEN product.discontinued_date IS NOT NULL AND PARSE_DATE('%Y-%m', product.discontinued_date) < DATE_TRUNC(forecast.forecast_date, MONTH) THEN 0
			{% if is_incremental() %}
			    WHEN ud.unecorn_lifecycle IN ('New Launch (<3M sales)','Future Launch') THEN COALESCE(m_1.validated_forecast, forecast.forecast_sales)
            {% endif %}
            ELSE forecast.forecast_sales
        END AS consensus_forecast,
        CAST(NULL AS STRING) AS comments_consensus,
        CASE
            WHEN product.discontinued_date IS NOT NULL AND PARSE_DATE('%Y-%m', product.discontinued_date) < DATE_TRUNC(forecast.forecast_date, MONTH) THEN 0
			{% if is_incremental() %}
			    WHEN ud.unecorn_lifecycle IN ('New Launch (<3M sales)','Future Launch') THEN COALESCE(m_1.validated_forecast, forecast.forecast_sales)
			{% endif %}
            ELSE forecast.forecast_sales
        END AS validated_forecast,
        CAST(NULL AS STRING) AS comments_validated,
        CASE
            WHEN forecast.marketplace_code = {{variable_macro('shopee_vn_var')}} THEN {{variable_macro('shp_lower_var')}}
            WHEN forecast.marketplace_code = {{variable_macro('lazada_vn_var')}} THEN {{variable_macro('lzd_lower_var')}}
            WHEN forecast.marketplace_code = {{variable_macro('tiktok_vn_var')}} THEN {{variable_macro('tiktok_lower_var')}}
        ELSE
            forecast.marketplace_code
        END AS platform_name,
        forecast.marketplace_code AS platform_code,
        product.country_code AS country_code,
        product.division_code AS division_code,
        CASE 
            WHEN forecast.forecast_gen_date = (SELECT MAX(model_run_date.model_run_date) FROM model_run_date) THEN 1
            ELSE 0 
        END AS active_month_flag,
        1 AS active_version_flag,   
        forecast.m_1_ai_fc,
		{% if is_incremental() %}
            m_1.validated_forecast AS m_1_validated_fc,
            m_1.consensus_forecast AS m_1_consensus_fc,
		{% else %}
            forecast.m_1_ai_fc AS m_1_validated_fc,
            forecast.m_1_ai_fc AS m_1_consensus_fc,
		{% endif %}
        forecast.m_3_ai_fc,
		{% if is_incremental() %}
            m_3.validated_forecast AS m_3_validated_fc,
            m_3.consensus_forecast AS m_3_consensus_fc,
		{% else %}
            forecast.m_3_ai_fc AS m_3_validated_fc,
            forecast.m_3_ai_fc AS m_3_consensus_fc,
		{% endif %}
        CASE 
            WHEN ud.unecorn_lifecycle IN ('Ongoing (modelled)','To be Discont. (modelled)','New Launch (<3M sales)','Do not show in tool','Active & Not Modelled') AND promo_discount_percentage IS NULL THEN COALESCE(nmv_avg,rs.final_rsp,0)
            WHEN ud.unecorn_lifecycle IN ('Ongoing (modelled)','To be Discont. (modelled)','New Launch (<3M sales)','Do not show in tool','Active & Not Modelled') AND promo_discount_percentage IS NOT NULL THEN promo_discount_price*rs.final_rsp
            WHEN ud.unecorn_lifecycle IN ('Future Launch') AND promo_franchise_discount_price IS NULL THEN COALESCE(rs.final_rsp,0)
            WHEN ud.unecorn_lifecycle IN ('Future Launch') AND promo_franchise_discount_price IS NOT NULL  THEN promo_franchise_discount_price*rs.final_rsp
            WHEN ud.unecorn_lifecycle IN ('Discont.') AND promo_discount_percentage IS NULL THEN COALESCE(rs.final_rsp,0)
            WHEN ud.unecorn_lifecycle IN ('Discont.') AND promo_discount_percentage IS NOT NULL THEN promo_discount_price*rs.final_rsp
        END AS expected_sales_price,
        rs.final_rsp AS retail_sales_price,
        product.category,
        product.group,
        product.hero_type,
        product.ean_description,
        product.product_sk,
        ud.unecorn_lifecycle,
        forecast.load_ts AS source_load_ts
    FROM
        forecast_data AS forecast
    LEFT JOIN {{ref('dim_campaign')}} AS dc
    ON
        forecast_date=CAST(`date` AS DATE)
        AND forecast.marketplace_code=dc.platform_code
        AND forecast.signature_code = dc.signature_code 
    LEFT JOIN
    (
        SELECT DISTINCT
            ean_code,
            platform_code,
            promo_discount_percentage,
            promo_discount_price,
            promo_franchise_discount_price,
            nmv_avg,
            gmv_avg,
            final_nmv,
            final_gmv,
            campaign_type,
            lifecycle_status
        FROM {{ref('dim_ean_valorisation')}}
    ) AS ean_price
    ON forecast.ean_code = ean_price.ean_code
    AND forecast.marketplace_code = ean_price.platform_code
    AND dc.campaign_type = ean_price.campaign_type
    LEFT JOIN {{ref('dim_product')}} AS product
    ON forecast.ean_code = product.ean_code AND UPPER(forecast.marketplace_code) = UPPER(product.platform_code)
    LEFT JOIN {{ref('dim_date')}} AS dim_date 
    ON forecast.forecast_date = dim_date.date
    LEFT JOIN unecorn_details AS ud 
    ON forecast.ean_code = ud.ean_code 
    AND  forecast.marketplace_code = ud.marketplace_code
    {% if is_incremental() == false %}
    AND forecast.forecast_gen_date = ud.forecast_gen_date
    {% endif %}
    LEFT JOIN {{ref('dim_rsp_valorization')}} AS rs
    ON forecast.ean_code = rs.ean_code
    AND forecast.marketplace_code = rs.platform_code
    AND DATE_TRUNC(forecast.forecast_date, MONTH) = month_date
	
	{% if is_incremental() %}
    LEFT JOIN m_1_data AS m_1
    ON forecast.forecast_gen_date = m_1.forecast_gen_date 
    AND forecast.forecast_date = m_1.forecast_date 
    AND forecast.ean_code = m_1.ean_code
    AND forecast.marketplace_code = m_1.platform_code

    LEFT JOIN m_3_data AS m_3
    ON forecast.forecast_gen_date = m_3.forecast_gen_date 
    AND forecast.forecast_date = m_3.forecast_date 
    AND forecast.ean_code = m_3.ean_code
    AND forecast.marketplace_code = m_3.platform_code
	{% endif %}
)

SELECT
    product_sk AS forecast_sk,
    campaign_sk,
    date_sk,
    sd.ean_code,
    sd.forecast_gen_date,
    forecast_date,
    ai_model_forecast,
    consensus_forecast,
    comments_consensus,
    validated_forecast,
    comments_validated,
    bundle_type,
    bundle_explosion,
    time_flag,
    sd.platform_name,
    sd.platform_code,
    sd.signature_code,
    sd.signature_name,
    sd.country_code,
    sd.division_code,
    sd.ean_description,
    campaign_type,
    active_month_flag,
    active_version_flag,
    m_1_ai_fc,
    m_1_validated_fc,
    m_1_consensus_fc,
    m_3_ai_fc,
    m_3_validated_fc,
    m_3_consensus_fc,
    expected_sales_price,
    expected_sales_price * ai_model_forecast AS nmv_ai_model_forecast_value,
    expected_sales_price * validated_forecast AS nmv_validated_forecast_value,
    expected_sales_price * consensus_forecast AS nmv_consensus_forecast_value,
    retail_sales_price,
    retail_sales_price * ai_model_forecast AS retail_ai_model_forecast_value,
    retail_sales_price * validated_forecast AS retail_validated_forecast_value,
    retail_sales_price * consensus_forecast AS retail_consensus_forecast_value,
    expected_sales_price * m_1_ai_fc AS nmv_ai_model_forecast_value_m_1,
    expected_sales_price * m_1_validated_fc AS nmv_validated_forecast_value_m_1,
    expected_sales_price * m_1_consensus_fc AS nmv_consensus_forecast_value_m_1,
    retail_sales_price * m_1_ai_fc AS retail_ai_model_forecast_value_m_1,
    retail_sales_price * m_1_validated_fc AS retail_validated_forecast_value_m_1,
    retail_sales_price * m_1_consensus_fc AS retail_consensus_forecast_value_m_1,
    CAST(NULL AS TIMESTAMP) AS updated_date,
    CAST(NULL AS STRING) AS user_name,
    CAST(NULL AS STRING) AS file_name,
    sd.unecorn_lifecycle AS lifecycle,
    sd.source_load_ts,
    CURRENT_TIMESTAMP() AS load_ts
FROM source_data AS sd