import requests
from msal import ConfidentialClientApplication
import json
from google.cloud import secretmanager
import pandas as pd
import utils
import os

project_id = os.getenv('project_number') if os.getenv('project_number') is not None else '66052729779'
version_id = "latest"
gcp_env  = os.getenv('gcp_env') if os.getenv('gcp_env') is not None else 'dv'
secret_id = f'unecornde-sharepoint-srt-ew1-{gcp_env}'


config_parser = utils.ConfigParser()

# Fetch client ID, client secret, and tenant ID from Google Secret Manager
def access_secret_version(project_id: str, secret_id: str, version_id: str):
    client = secretmanager.SecretManagerServiceClient()
    name = f"projects/{project_id}/secrets/{secret_id}/versions/{version_id}"
    response = client.access_secret_version(request={"name": name})
    payload = response.payload.data.decode("UTF-8")
    return payload

def connect_sp(creds, sharepoint_dir_path):
    res = json.loads(creds)
    client_id = res["client_id"]
    client_secret = res["secret_key"]
    tenant_id = res["tenant_id"]

    msal_authority = f"https://login.microsoftonline.com/{tenant_id}"
    msal_scope = ["https://graph.microsoft.com/.default"]

    msal_app = ConfidentialClientApplication(
        client_id=client_id, client_credential=client_secret, authority=msal_authority
    )

    result = msal_app.acquire_token_for_client(scopes=msal_scope)

    if "access_token" in result:
        access_token = result['access_token']

    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }

    endpoint = config_parser.get_config_value('sharepoint_params', 'endpoint')
    sharepoint_base_url = config_parser.get_config_value('sharepoint_params', 'sharepoint_base_url')
    sharepoint_site = config_parser.get_config_value('sharepoint_params', 'sharepoint_site')
    site_response = requests.get(
        url=f"{endpoint}{sharepoint_base_url}{sharepoint_site}",
        headers=headers,
    )
    print("Connected to the site_end_points successfully")
    site_response.raise_for_status()
    site_info = site_response.json()
    site_id = site_info['id']
    print("Acquiring site_id from the site_end_point_response")

    return site_id, access_token

def sp_upload_blank_xlsx(access_token, site_id, sharepoint_dir_path, file_name):
    df = pd.DataFrame()

    local_file_path = f"/tmp/{file_name}"
    df.to_excel(local_file_path, index=False)

    with open(local_file_path, 'rb') as file:
        file_content = file.read()

    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    }

    endpoint = config_parser.get_config_value('sharepoint_params', 'endpoint')

    upload_url = f"{endpoint}/sites/{site_id}/drive/root:/{sharepoint_dir_path}/{file_name}:/content"
    upload_response = requests.put(
        url=upload_url,
        headers=headers,
        data=file_content
    )

    if upload_response.status_code == 201:
        print(f"File {file_name} successfully uploaded to SharePoint")
    else:
        print(f"Failed to upload file {file_name}. Status code: {upload_response.status_code}, Response: {upload_response.text}")

    return site_id, file_name

def transfer_file_from_sharepoint_to_gcs(sharepoint_dir_path, feed_id):
    # creds = access_secret_version(project_id, secret_id, version_id)
    creds = {
        "client_id": "b4e52d71-08b1-4ab2-8c54-3b90415d8b75",
        "secret_key": "YFv8Q~zx7xj-Nm81bbdwd4Uhae7xOFpvWB0SJcTi",
        "tenant_id":"e4e1abd9-eac7-4a71-ab52-da5c998aa7ba"
    }
    print("Acquired the Client_id, secret_key and tenant_id")

    site_id, access_token = connect_sp(creds, sharepoint_dir_path)

    file_name = f"power_bi_refresh_{gcp_env}.xlsx"
    site_id, file_name = sp_upload_blank_xlsx(access_token, site_id, sharepoint_dir_path, file_name)
    print("Completed pushing blank file to SharePoint... site_id:", site_id, "file_name:", file_name)

    return f"transfer_file_from_sharepoint_to_gcs is successfully completed for the feed id: {feed_id}"

# print(transfer_file_from_sharepoint_to_gcs("General/Adjustment_Dev_Upload", "sharepoint_directory"))
