{{ config(materialized='table') }}

{%- set target_relation = adapter.get_relation(
      database=this.database,
      schema=this.schema,
      identifier=this.name) -%}
{%- set table_exists=target_relation is not none -%}

WITH platform_signature_data AS (
    SELECT 
        `year`,	
        `month`,	
        `day`,	
        `date`,	
        date_key AS date_sk,
        `start_date`,	
        end_date,	
        marketplace_code AS platform_code,
        CASE 
            WHEN marketplace_code={{ variable_macro('shopee_vn_var') }} THEN {{ variable_macro('shp_lower_var') }} 
            WHEN  marketplace_code={{ variable_macro('lazada_vn_var') }} THEN {{ variable_macro('lzd_lower_var') }}
            WHEN  marketplace_code={{ variable_macro('tiktok_vn_var') }} THEN {{ variable_macro('tiktok_lower_var') }}
            ELSE marketplace_code 
        END AS platform_name,
        country AS country_code,	
        signature_name,
        signature_code,
        CAST(NULL AS STRING) AS store_or_franchise,	
        CAST(NULL AS STRING) AS campaign_title,	
        'BL'AS campaign_type,	
        CAST(NULL AS STRING) AS campaign_name,	
        division AS division_code,	
        CAST(NULL AS STRING) AS file_name,	
        CAST(NULL AS TIMESTAMP) AS created_date,	
        CAST(NULL AS TIMESTAMP) AS updated_date,	
        CURRENT_TIMESTAMP() AS load_ts 	 
    FROM 
    (
        SELECT 
            `year`,
            `month`,
            `day`,
            `date`,
            date_key,
            `date` AS start_date, 
            `date` AS end_date 
        FROM {{ref('dim_date')}}
        WHERE date >= DATE_TRUNC(CURRENT_DATE(), MONTH) 
        AND date < DATE_ADD(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 21 MONTH)
    )
    JOIN
    (
        SELECT DISTINCT 
            country,
            'CPD' AS division,
            marketplace_code,
            signature AS signature_code,
            brand AS signature_name
        FROM {{ref('dim_master_data_forecast')}} 
        WHERE signature <> 'P2'
        UNION DISTINCT 
        SELECT DISTINCT 
            country,
            division_name,
            marketplace_code,
            signature_code,
            signature_name
        FROM {{ref('dim_product_platform')}}  
    )    
    ON 1=1  
),
source_data AS (
    SELECT
        `year`,	
        `month`,	
        `day`,	
        CAST(`date` AS DATE) AS `date`,	
        CAST(FORMAT_DATE('%Y%m%d', cast(`date` AS DATE)) AS INTEGER) AS date_sk,
        CAST(`start_date` AS DATE) AS start_date,	
        CAST(end_date AS DATE) AS end_date,	
        marketplace_code AS platform_code,
        CASE 
            WHEN marketplace_code={{variable_macro('shopee_vn_var')}} THEN {{variable_macro('shp_lower_var')}} 
            WHEN  marketplace_code={{variable_macro('lazada_vn_var')}} THEN {{variable_macro('lzd_lower_var')}}
            WHEN  marketplace_code={{variable_macro('tiktok_vn_var')}} THEN {{variable_macro('tiktok_lower_var')}} 
            ELSE marketplace_code 
        END AS platform_name,
        country AS country_code,	
        signature_name,
        signature_code,
        store_or_franchise,	
        campaign_title,	
        campaign_type,	
        campaign_name,	
        division AS division_code,	
        file_name,	
        created_date,	
        updated_date,	
        CURRENT_TIMESTAMP() AS load_ts 	
    FROM {{ref('campaign_calendar')}}
),
missing_data AS (
    SELECT a.*
    FROM platform_signature_data AS a
    LEFT JOIN source_data AS b
    ON a.country_code = b.country_code
    AND a.division_code = b.division_code
    AND a.platform_code = b.platform_code
    AND a.signature_code = b.signature_code
    AND a.date_sk = b.date_sk
    WHERE b.date_sk IS NULL
),
final_data AS (
  SELECT * FROM source_data
  UNION ALL
  SELECT * FROM missing_data
),
row_sk AS (    
    {% if table_exists %}
    {{ print("Running table_exists ") }}
    SELECT
        CASE
            WHEN nd.campaign_sk IS NOT NULL THEN nd.campaign_sk
            ELSE max_campaign_sk + ROW_NUMBER() OVER(ORDER BY rd.`date`, rd.platform_code, rd.signature_code) 
        END AS campaign_sk,
        rd.platform_code,
        rd.signature_code,
        rd.date
    FROM
    (
      SELECT * FROM final_data
    ) AS rd 
    LEFT JOIN
    (
        SELECT DISTINCT
            platform_code,  
            signature_code,
            date,
            campaign_sk 
        FROM {{this}}
    ) AS nd
    ON
    rd.platform_code = nd.platform_code
    AND rd.signature_code = nd.signature_code
    AND rd.date = nd.date
    LEFT JOIN
    (
        SELECT 
            COALESCE(MAX(campaign_sk), 1) AS max_campaign_sk 
        FROM {{this}}
    ) AS M
    ON 1=1
    {% else %}
   
    SELECT 
        *, 
        ROW_NUMBER() OVER(ORDER BY `date`, platform_code, signature_code) AS campaign_sk
         
    FROM 
    (
        SELECT 
            ROW_NUMBER() OVER(PARTITION BY `date`, platform_code, signature_code ORDER BY `date`, platform_code, signature_code) AS c_sk, 
            `date`, 
            `signature_code`, 
            `platform_code`  
        FROM final_data 
    )
    WHERE c_sk = 1
    {% endif %}  
)
SELECT
    csk.campaign_sk,
    sd.*   
FROM final_data AS sd
LEFT JOIN 
row_sk AS csk 
ON sd.date=csk.date 
AND sd.platform_code = csk.platform_code  
AND sd.signature_code = csk.signature_code