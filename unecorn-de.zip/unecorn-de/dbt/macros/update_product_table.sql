{% macro update_product_table(dataset_name, table_name,flag) %}

{% set project_id = target.project %}

{% if execute %}
    EXECUTE IMMEDIATE '''UPDATE `{{ project_id }}.{{ dataset_name }}.{{ table_name }}`
                    SET active_flag = '{{flag}}'

                    WHERE wid in (
                    select wid from (
                    SELECT wid, product_sk, source_load_ts, oms_store_code, row_number() over(partition by product_sk order by source_load_ts DESC, oms_store_code DESC) AS rrank
                    FROM `{{ project_id }}.{{ dataset_name }}.{{ table_name }}`
                    )
                    where rrank = 1
                    )'''
  

{% endif %}

{% endmacro %}
