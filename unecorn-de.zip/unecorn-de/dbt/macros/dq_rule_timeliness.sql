{% macro dq_rule_timeliness() %}
    -- Query the BigQuery table to fetch data quality rules for Timeliness
    {% set dq_rules_query %}
        SELECT 
            dq_rule_sk,
            dq_type, 
            pre_post_processing, 
            source_type, 
            source_name, 
            table_name, 
            column_name, 
            domain, 
            platform_code, 
            signature_code, 
            expected_value, 
            filters,
            result_query
        FROM {{ db_source('src_dq_rule', 'dim_dq_rule') }}
        WHERE dq_type = 'Timeliness'
        ORDER BY dq_rule_sk
    {% endset %}
    
    -- Fetch and transform data quality rules into row-based records
    {% set dq_rules = transform_dict_to_rows(dbt_utils.get_query_results_as_dict(dq_rules_query)) %}

    -- Initialize results array
    {% set results = [] %}

    -- Get current date once (Asia/Kolkata timezone)
    {% set current_date = dbt_utils.get_query_results_as_dict("SELECT cast(DATETIME(CURRENT_TIMESTAMP(), 'Asia/Kolkata') as string) AS today")['today'] %}

    -- Process each timeliness rule
    {% for rule in dq_rules %}
        {% do log("Processing timeliness rule " ~ rule['dq_rule_sk'], info=true) %}
        
        -- Prepare table reference
        {% set table_ref %}
            {% if rule['source_type'] == 'CDS' %}
                {{ ref(rule['table_name']) }}
            {% else %}
                {{ db_source(rule['source_name'], rule['table_name']) }} 
            {% endif %}
        {% endset %}
        
        -- Prepare filter clause if present
        {% set filter_clause = '' %}
        {% if rule['filters'] %}
            {% set filter_clause = 'WHERE ' ~ rule['filters'] | replace('{env}', target.name) %}
        {% endif %}
        
        -- Build and execute main query
        {% set query %}
        BEGIN
            SELECT
                CAST(MAX({{ rule['column_name'] }}) AS DATE) AS row_count
            FROM {{ table_ref }}
            {{ filter_clause }};
        EXCEPTION WHEN ERROR THEN
            SELECT NULL AS row_count;
        END;
        {% endset %}
        
        -- Execute query and get result
        {% set query_result = dbt_utils.get_query_results_as_dict(query) %}
        {% set row_count = query_result['row_count'][0] %}
        {% do log("Query for rule " ~ rule['dq_rule_sk'] ~ ": " ~ query, info=true) %}
        {% do log("Max date for rule " ~ rule['dq_rule_sk'] ~ ": " ~ row_count, info=true) %}
        
        -- Default validity check (1 if we got a date, 0 if NULL)
        {% set valid_check = 0 if row_count == None else 1 %}
        
        -- Execute result query if provided
        {% set output_query_result = '' %}
        {% if rule['result_query'] %}
            {% set result_query = rule['result_query'] | replace('{env}', target.name) %}
            {% do log("Executing result query for rule " ~ rule['dq_rule_sk'], info=true) %}
            {% set result_query_output = dbt_utils.get_query_results_as_dict(result_query) %}
            {% set output_query_result = transform_dict_to_rows(result_query_output) %}
            
            -- Update validity check based on result query
            {% if tojson(output_query_result) == '[]' %}
                {% set valid_check = 0 %}
            {% endif %}
        {% endif %}
        
        -- Sanitize output for JSON
        {% set sanitized_output = tojson(output_query_result) | replace("'", '"') | replace('"Oreal', "\\'Oreal") %}
        
        -- Prepare formatted result row
        {% set result_row = [
            rule['dq_rule_sk'],
            '' if row_count == None else row_count | string,
            valid_check,
            '',
            current_date[0],
            "'" ~ sanitized_output ~ "'"
        ] %}
        
        -- Add to results list
        {% do results.append(result_row) %}
        {% do log("Added result for rule " ~ rule['dq_rule_sk'], info=true) %}
    {% endfor %}

    {% do log("Completed processing " ~ results | length ~ " timeliness rules", info=true) %}
    {% do log("Completed processing " ~ results, info=true) %}
    
    -- Generate and return the final query
    {{ dq_rule_query_generator(results) }}
{% endmacro %}