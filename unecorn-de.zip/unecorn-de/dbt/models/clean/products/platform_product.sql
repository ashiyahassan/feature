{{ 
  config(
    materialized='incremental',
    unique_key=['ean_code', 'marketplace_code', 'sku_code', 'oms_store_code'],
    log_path='/log/clean/product/platform_products/platform_model'
  ) 
}}

WITH source_data AS (
    SELECT market_code AS country,
    marketplace_code,
    marketplace_name,
    marketplace_shop_id,
    marketplace_shop_name,
    oms_store_code,
    oms_store_name,
    sap_distrib_channel_code AS channel_code,
    sap_division_name AS division_name,
    (CASE WHEN sap_division_code = 'CPD' THEN '20' ELSE sap_division_code END) AS division_code,
    sap_signature_code AS signature_code,
    sap_signature_name AS signature_name,
    sap_axe_code AS axe_code,
    sap_sub_axe_code AS sub_axe_code,
    product_description,
    oms_platform_product_status AS product_status,
    CAST(ean_code AS STRING) AS ean_code,
    oms_brand_classification,
    marketplace_category_code,
    active_flag,
    bundle_flag,
    (CASE WHEN sap_product_code = '-1' THEN NULL ELSE sap_product_code END) AS sku_code,
    sap_product_component_code AS product_component_code,
    sap_material_type_code AS material_type_code,
    sap_reference_code AS reference_code,
    (CASE WHEN sap_compass_code = '-1' THEN NULL ELSE sap_compass_code END) AS compass_code,
    hero_product_group_code,
    hero_product_group_description,
    currency,
    sap_mrsp,
    sap_inventory_price,
    platform_list_price,
    platform_special_list_price,
    product_height,
    product_width,
    product_length,
    product_weight,
    marketplace_category,
    hero_type,
    platform_product_id,
    load_ts AS source_load_ts,
    CURRENT_TIMESTAMP() AS load_timestamp
    FROM {{db_source('src_platform_product','dim_oms_platformproducts')}}   
    WHERE market_code IN {{variable_macro('country_var')}}
    AND sap_division_name IN {{variable_macro('division_var')}}
    AND marketplace_code IN {{variable_macro('platform_country_var')}}
    {% if is_incremental() %}
    AND load_ts > (SELECT MAX(source_load_ts) FROM {{ this }})
    {% endif %}
)

SELECT * FROM source_data
