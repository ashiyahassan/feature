import functions_framework
import io
import json
import requests
import pandas as pd
from google.cloud import storage, bigquery
from config import *
from datetime import datetime
import time
from google.api_core.exceptions import NotFound
import importlib
import schema_file
import base64
from google.auth import default
from google.auth.transport.requests import Request
import logging
import google.cloud.logging

importlib.reload(schema_file)

bigquery_client = bigquery.Client()
storage_client = storage.Client()

client = google.cloud.logging.Client()
client.setup_logging(log_level = logging.INFO)

columns_to_remove = ['wid', 'country_code', 'created_date', 'modified_date', 'active_status']
sheet_dict = schema_file.sheet_dict
run_validation_dict = schema_file.run_validation_dict
merge_dict = schema_file.merge_dict


def remove_columns(data, columns_to_remove):
    logging.info("Entered remove_columns")
    for key in data:
        data[key] = [column for column in data[key] if column not in columns_to_remove]
    return data


# Triggered by a change in a storage bucket
@functions_framework.http
def http_hello(cloud_event):
    logging.info("Cloud Function started")
    logging.info("Entered http_hello")
    print(cloud_event.get_json())
    data = cloud_event.get_json()

    bucket = data["bucket"]
    name = data["name"]

    print(f"Bucket: {bucket}")
    print(f"File: {name}")
    
    df = 200
    
    try:
        if check_folder(name):
            df = process_excel_file(bucket, name)
            logging.info("Cloud Function End")
        else:
            df = 500
            raise ValueError(f"File not from 'master_data_forecast' folder")
            
    except Exception as e:
        df = 500
        logging.error("error in http_hello function")
        print(e)
    
    return df


def check_folder(input_string):
    logging.info("Entered check_folder")
    prefix = "master_data_forecast"
    return input_string.startswith(prefix)


def process_excel_file(bucket_name, file_path):
    logging.info("Entered process_excel_file")
    # Extracting file details from the event
    file_name = file_path.split("/")[-1]
    file_name = file_name.replace('_adhoc','')

    table_id = f'{project_id}.{dataset_id}.{file_name.split(".")[0]}_file_data'
    print(f"Manual files Ingestion :{file_name} : file_path - {file_path}")
    print(f"Manual files Ingestion :{file_name} : bucket_name - {bucket_name}")
    print(f"Manual files Ingestion :{file_name} : table_id - {table_id}")
    df = read_csv(bucket_name=bucket_name, file_path=file_path)
    print(f"Manual files Ingestion :{file_name} : ", "Manual File to BQ")
    return df


def master_data_file(schema, file_path, file_data_bytes):
    logging.info("Entered master_data_file")
    data = pd.read_excel(file_data_bytes, sheet_name="masterdata")
    data["country_code"] = None
    for ind in schema:
        if ind in data.columns:
            pass
        else:
            print("SCHEMA ERROR : MASTER DATA FILES")
            return None

    return data[schema]


def read_csv(bucket_name, file_path):
    logging.info("Entered read_csv")
    file = file_path.split("/")[-1].split(".")[0]
    bucket = storage_client.get_bucket(bucket_name)
    print("READ CSV")
    df = {"status":200}
    if file_path.split(".")[1] == "xlsx":
        print("Started Excell")
        try:
            df = process_df(bucket_name, file_path, "xlsx")
        except Exception as e:
            logging.error("error in read_csv function")
            print("FAILED WITH", e)
            return 500
        print("Read Excel END")
    elif file_path.split(".")[1] == "csv":
        try:
            df = process_df(bucket_name, file_path, "csv")
        except Exception as e:
            logging.error("error in read_csv function")
            print("FAILED WITH", e)
            return 500
        print("Read CSV END")

    return df["status"]


def validate_schema_master_data(df, old_schema, schema):
    logging.info("Entered validate_schema_master_data")
    print(f"Expected Schema: {schema}")
    s = []
    for i in df:
        s.append(i)
    print(f"File Schema: {s}")
    df = df[schema]
    print("SCHEMA VALIDATED")
    return to_string(df, schema)


def to_string(df, schema):
    logging.info("Entered to_string")
    for i in schema:
        df[i] = df[i].astype(str)

    df['modified_date'] = df['modified_date'].astype(object)
    print("schema conversion done")

    return df


def move_to_archive(bucket_name, file_path, destination_folder, file_name):
    logging.info("Entered move_to_archive")
    source_blob_path = f"{file_path}"
    destination_blob_path = f"{file_path}"
    print(f"GCS destination path: {destination_blob_path}")
    print(f"Manual files Ingestion :{file_name} : ", f"File {file_name} moved from {file_path} to {GCS_ARCHIVE_BUCKET_NAME}/ {destination_folder}")

    storage_client = storage.Client()
    source_bucket_name = bucket_name
    source_blob_name = file_path
    source_blob_name_ts = file_path.split('/')[0] + '/' + str(time.time()) + '_' + file_path.split('/')[1]
    print(f"Manual files Ingestion :{file_name} : ", f"{source_blob_name_ts}")


    source_bucket = storage_client.get_bucket(source_bucket_name)
    source_blob = source_bucket.blob(source_blob_name)

    destination_bucket = storage_client.bucket(GCS_ARCHIVE_BUCKET_NAME)
    destination_blob = source_bucket.copy_blob(
        source_blob, destination_bucket, source_blob_name_ts
    )

    source_blob.delete()  # Delete file from source bucket after copying


def rename_duplicate_columns(df):
    # Count occurrences of column names
    logging.info("Entered rename_duplicate_columns")
    print("BEFORE COLUMNS",df.columns)
    cols = pd.Series(df.columns)
    new_cols = []
    for dup in cols[cols.duplicated()].unique():
        dup_count = cols[cols == dup].index
        for i in range(1, len(dup_count)):
            cols[dup_count[i]] = f"{dup}_{i}"
    new_cols = list(cols)
    df.columns = cols
    print("AFTER COLUMNS",df.columns)
  
    return df, new_cols


def insert_job(df, table_id, file_name, schema):
    print("ENTERD insert_job")
    df, schema = rename_duplicate_columns(df)
    try:
        schema_val = []
        for sch in schema:
            schema_val.append(bigquery.SchemaField(sch, "STRING"))
        print("SCHEMA CREATED")
        job_config = bigquery.LoadJobConfig(
            write_disposition="WRITE_TRUNCATE",
            schema=schema_val  # Define schema fields
        )
        print("JOB CONFIG SET")
        print(f"Table id: {table_id}")
        print(f"df: {df}")
        print(f"Schema: {schema_val}")
        try:
            print("JOB STARTED INSERT", table_id)
            job = bigquery_client.load_table_from_dataframe(df, table_id, job_config=job_config)
        except Exception as e:
            logging.error("error in inserting")
            print("FAILED", e)

        print("TEMP TABLE LOADED")
        job.result()
        print("TABLE INSERT JOB COMPLETE")
        return schema
        # df.to_gbq(table_id, **gbq_config)
    except Exception as e:
        job = bigquery_client.get_job(job.job_id)
        logging.error("error in insert_job function")
        print("Job errors: %s", job.errors)
        raise ValueError(e)

    print(f"Manual files Ingestion :{file_name} : ", f"File {file_name} loaded into BigQuery table {table_id}")


def process_df(bucket_name, file_path, key):
    """
    process_df function orchestrates :
        -read files
        -add columns
        -file validations
        -insert staging table
        -upsert logic for comparisons
        -file archival
        -feature table deletion

    :param bucket_name: bucket_name from event
    :param file_path: file_path from event
    :return: Status
    """
    logging.info("Entered process_df")
    try:
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(file_path)
        data_bytes = io.BytesIO(blob.download_as_string())
        file_name = file_path.split("/")[-1]
        file_name = file_name.replace('_adhoc','')
        file_key = file_name.split(".")[0]
        stage_table_id = f'{project_id}.{dataset_id}.stage_{file_key}_file_data'
        destination_folder ='master_data_forecast'
        schema = remove_columns(schema_file.schema_dict, columns_to_remove)[file_key]

        # Step 1 : Read Master_data_file
        if key == "xlsx":
            df = pd.read_excel(data_bytes, sheet_name=sheet_dict[file_key])
        # elif key == 'csv' :
        else:
            df = pd.read_csv(data_bytes)
        df.columns = [col.strip().lower() for col in df.columns]
        # Step 2 : Add columns
        df_list = add_columns(df, schema)
        df = df_list[0]
        old_schema = schema
        new_schema = df_list[1]

        # format status col
        for col in ['lzd_status', 'shp_status', 'tiktok_status','unecorn_lzd_status', 'unecorn_shp_status', 'unecorn_tiktok_status']:
            if col in df.columns:
                df[col] = df[col].apply(format_status)

        # Step 3 : Add Validations
        df = validate_schema_master_data(df, old_schema, new_schema)
        print(f"old_schema: {old_schema}")
        print(f"new_schema: {new_schema}")
        # Step 4 : insert table
        new_schema = insert_job(df, stage_table_id, file_name, new_schema)

        # run Validation
        if run_validation_dict[file_key]:
            run_validation(stage_table_id, file_key)
            dq_rank = check_unecorn_dq_results(stage_table_id)
            print(f"dq rank: {dq_rank}")
        else:
            dq_rank = 0
        """
        WRITE CODE TO INCLUDE DQ WITH GREAT EXPECTATIONS


        WRITE FUNCTION TO READ BQ REPORT
        """
        print('VALIDATION COMPLETE')
        if dq_rank == 0:
            # Call ingestion framework
            print('MERGE TARGET TABLE INIT CHECK')
            if merge_dict[file_key]:
                print('ENTERED MERGE')
                if check_table_exists(df, stage_table_id.replace('stage_', ''), file_name, new_schema, old_schema) == 0:
                    print('TABLE EXISTS')
                    update_hash(stage_table_id, file_name, old_schema)
                    print("UPDATE HASH  DONE")
                    # Step 6 : Upsert Logic
                    print("UPSERT INIT")
                    upsert_logic(stage_table_id, stage_table_id.replace('stage_', ''), file_key, new_schema)
                    print("UPSERT END")
            else:
                insert_job(df, stage_table_id.replace('stage_', ''), file_name, new_schema)
            print("FILE PATH CHECK COMPLETE")
            move_to_archive(bucket_name, file_path, destination_folder, file_name)
            return {"status": "200", "message": 'DQ Framework implemented'}

        else:
            # Call CF notification
            send_email( file_path)
            move_to_archive(bucket_name, file_path, destination_folder, file_name)
            return {"status": "500", "message": 'DQ Validation Failed '}
    except Exception as e:
        send_email( file_path)
        move_to_archive(bucket_name, file_path, destination_folder, file_name)
        return {"status": "500", "message": 'DQ Validation Failed'}


def get_wid():
    logging.info("Entered get_wid")
    try:
        query = f"""
                SELECT MAX(wid) as wid
                FROM `practicebigdataanalytics.loreal_raw_zone.master_data_forecast`
            """
        query_job = bigquery.Client().query(query)
        result = query_job.result()

        # Extract the last batch ID
        wid = None
        for row in result:
            if row.wid is None:
                wid = 0
            else:
                wid = row.wid
        return int(wid) + 1
    except:
        return 1


def add_columns(df, schema):
    logging.info("Entered add_columns")
    schema1 = schema
    schema1.append('wid')
    schema1.append('country_code')
    schema1.append('created_date')
    schema1.append('modified_date')
    schema1.append('active_status')
    # schema.append('hash_map')

    df['wid'] = get_wid()
    df['country_code'] = 'VN'
    df['created_date'] = datetime.now()
    df['modified_date'] = datetime.now()
    df['active_status'] = 'Y'
    # df['hash_map'] = 0

    print("COLUMNS ADDED")
    return [df, schema1]



def check_unecorn_dq_results(table_id):
    """Checks the error_rows column in unecorn_dq_results table and returns the total error count.

    Args:
        project_id: The Google Cloud project ID containing the BigQuery dataset.

    Returns:
        The total number of errors found (or -1 if an error occurs).

    Raises:
        Exception: If an error occurs during BigQuery client creation or query execution.
    """
    logging.info("Entered check_unecorn_dq_results")
    # Create a BigQuery client
    try:
        client = bigquery.Client()
    except Exception as e:
        print(f"Error creating BigQuery client: {e}")
        return -1  # Return -1 to indicate error

    # Construct the query
    query = f"""
  SELECT
    COALESCE(SUM(IFNULL(number_of_errors, 0)),0) AS total_errors
  FROM `{project_id}.{dataset_id}.{invalid_table_id}` 
  """

    # Execute the query
    try:
        query_job = client.query(query)
        results = query_job.result()
        # print(results[0].total_errors)  # Waits for job to complete
    except Exception as e:
        print(f"Error executing BigQuery query: {e}")
        return -1  # Return -1 to indicate error

    # Check for rows and process results

    rows = list(results)
    # val = "0"
    # for row in query_job.result():
    #     if row.total_errors is not None:
    #         val = row.total_errors

    if not rows:
        print("No rows returned from query. Assuming error.")
        return -1  # Return -1 to indicate error

    total_errors = rows[0].total_errors
    print(f"Total error while processing file {total_errors}")
    return total_errors


def update_hash(table_id, file_name, schema):
    logging.info("Entered update_hash")
    schema = ",".join(schema)
    schema = schema.replace(',created_date,modified_date,active_status', '')
    print(f"Schema: {schema}")
    query = f"""
ALTER TABLE {table_id} 
ADD COLUMN hash_map INT64;

update {table_id} 
set hash_map = FARM_FINGERPRINT(TO_JSON_STRING(STRUCT({schema.replace(',group,', ',`group`,')}))) 
Where 1=1;
        """
    print(f"Alter query: {query}")
    query_job = bigquery_client.query(query)
    result = query_job.result()

    print(f"Master Data files Ingestion :{file_name} : ", f"File {file_name} loaded into BigQuery table {table_id}")


def upsert_logic(stage_table, master_table, file_key, schema):
    logging.info("Entered upsert_logic")
    schema = ",".join(schema)
    schema = schema.replace(',group,', ',`group`,').replace(',sub_group,', ',`sub_group`,').replace(',sub_category,',
                                                                                                    ',`sub_category`,').replace(
        ',sub_brand,', ',`sub_brand`,').replace(',old_ean,', ',`old_ean`,')

    print(f"schema: {schema}")
    query = schema_file.merge_query_dict_function(master_table, stage_table, file_key, schema)
    print(f"Merge Query: {query}")

    query_job = bigquery_client.query(query)
    try:
        result = query_job.result()
        print(f"Merge result: {result}")
    except Exception as e:
        logging.error("error in upsert_logic function")
        print("MERGE FAILED", e)


def format_status(text):
    # Check if text is NaN or not a string
    if pd.isna(text) or not isinstance(text, str):
        return text
    
    # Special case: preserve specific abbreviations in uppercase
    special_cases = ['DC', 'TBDC']
    if text.upper() in special_cases:
        return text.upper()
    
    # For all other cases, convert to title case (first letter capital)
    return text.title()


def export_table_to_csv():
    logging.info("Entered export_table_to_csv")
    # Fetch data from BigQuery table into a DataFrame
    table_ref = f"{project_id}.{dataset_id}.{invalid_table_id}"
    table = bigquery_client.get_table(table_ref)
    df = bigquery_client.list_rows(table).to_dataframe()

    # Convert DataFrame to CSV string
    csv_string = df.to_csv(index=False)

    return csv_string


def send_email( file_name):
    logging.info("Entered send_email")
    file_name = str(file_name.split('/')[-1].split('.')[0] + '.csv')
    invalid_table_csv = export_table_to_csv()

    current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    file_location = "https://loreal.sharepoint.com/:x:/r/sites/-SG-UNeCORN-PORTAL/Documents%20partages/General/VNCPD/" #file_name
    # Define the scope required for the OAuth token
    scope = ["https://www.googleapis.com/auth/cloud-platform"]
    html_content = f"""
<html>
<head>
    <meta charset="UTF-8">
    <title>Data Validation Failure</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            color: #333;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }}
        .container {{
            width: 80%;
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }}
        .header {{
            background-color: #E91E63;
            color: #fff;
            padding: 10px;
            text-align: center;
            border-radius: 10px 10px 0 0;
        }}
        .content {{
            padding: 20px;
        }}
        .content p {{
            line-height: 1.6;
        }}
        .file-details {{
            margin-top: 20px;
        }}
        .file-details table {{
            width: 100%;
            border-collapse: collapse;
        }}
        .file-details th, .file-details td {{
            text-align: left;
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }}
        .footer {{
            margin-top: 20px;
            text-align: center;
            font-size: 0.9em;
            color: #777;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Data Validation Failure</h1>
        </div>
        <div class="content">
            <p>Dear User,</p>
            <p>We regret to inform you that the manual file '<strong>{file_name}</strong>' submitted for validation on <strong>{current_time}</strong> has failed the data validation process.</p>
            <div class="file-details">
                <h3>File Details:</h3>
                <table>
                    <tr>
                        <th>File Name:</th>
                        <td>{file_name}</td>
                    </tr>
                    <tr>
                        <th>File Location:</th>
                        <td><a href="{file_location}" target="_blank">Access the file on SharePoint</a></td>
                    </tr>
                </table>
            </div>
            <p>We kindly request you to review the file and make necessary corrections in the next 48 hours before resubmitting it for validation.</p>
            <p>Thank you for your attention to this matter.</p>
            <p>Best regards,</p>
            <p><strong>{EMAIL_FROM_NAME}</strong></p>
        </div>
        <div class="footer">
            &copy; 2024 L'Oréal. All rights reserved.
        </div>
    </div>
</body>
</html>
"""

    # Encode the HTML content to base64
    encoded_html_content = base64.b64encode(html_content.encode('utf-8')).decode('utf-8')

    try:
        creds, project = google.auth.default()
        auth_req = google.auth.transport.requests.Request()
        creds.refresh(auth_req)
        access_token = creds.token
    except (DefaultCredentialsError, RefreshError) as e:
        logging.warning(f"Failed to retrieve or refresh credentials: {e}")
        return "Authentication error", 500


    if not access_token:
        raise Exception("Access token not provided")

    # Define headers and payload
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }


    recipients = TO_EMAIL
    subject = f"Data Validation Failure: Manual File '{file_name}'"
    body = f"Dear User,\n\nWe regret to inform you that the manual file '{file_name}' submitted for validation on {current_time} has failed the data validation process.\n\nFile Details:\n\nFile Name: {file_name}\nFile Location: {file_location}\n\nWe kindly request you to review the file and make necessary corrections in the next 48 hours before resubmitting it for validation.\n\nThank you for your attention to this matter.\n\nBest regards,\n{EMAIL_FROM_NAME}"
    attachments = [
        {
            "file_name": "invalid_records.csv",
            "file_type": "text/csv",
            "file_content": invalid_table_csv
        }
    ]

    payload = [{
        "to": recipients,
        "subject": subject,
        "sender": "unecorn-noreply@data-platform.beauty.tech",
        "content": html_content,
        "attachments":attachments
    }]

    # print(payload)
    # print(access_token)
    response = requests.post(api_url, headers=headers, json=payload)
    # Log the response content and status code
    print(f"API response: {response.content.decode('utf-8')}")
    print(f"API response status code: {response.status_code}")
    # print(response.content, response.status_code)
    return response.content, response.status_code


def run_validation(stage_table_id, file_key):
    # Instantiates a client
    logging.info("Entered run_validation")

    # Get the filename containing the SQL query
    filename = f"dq_validate_{file_key}.sql"
    # Read the SQL query from the file
    with open(filename, "r") as file:
        query = file.read()

    # Set destination table for the result

    table_id = "dq_invalid_master_data_forecast_file_data"

    table_ref = f"{project_id}.{dataset_id}.{invalid_table_id}"
    print("ENTERD VALIDATION")
    # Run the query

    query_job = bigquery_client.query(query.format(table_ref, stage_table_id))
    # print(table_ref)
    # Wait for the query to finish
    query_job.result()

    print(f"Query results saved to table {table_ref}")


def check_table_exists(df, table_id, file_name, schema, old_schema):
    logging.info("Entered check_table_exists")
    client = bigquery.Client()

    table_ref = table_id

    try:
        client.get_table(table_ref)
        print(f"Table {table_ref} exists.")
        return 0
    except NotFound:
        print("NO SUCH TABLE")
        insert_job(df, table_id, file_name, schema)
        update_hash(table_id, file_name, old_schema)

        print("TABLE ADDED")
        return 1
