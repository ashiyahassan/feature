{% macro dq_rule_uniqueness() %}
    -- Query the BigQuery table to fetch data quality rules for Uniqueness checks
    {% set dq_rules_query %}
        SELECT 
            dq_rule_sk,
            dq_type, 
            pre_post_processing, 
            source_type, 
            source_name, 
            table_name, 
            column_name, 
            domain, 
            platform_code, 
            signature_code, 
            expected_value, 
            filters,
            result_query
        FROM {{ db_source('src_dq_rule', 'dim_dq_rule') }}
        WHERE dq_type = 'Uniqueness'
        ORDER BY dq_rule_sk
    {% endset %}
    
    -- Fetch and transform data quality rules into row-based records
    {% set dq_rules = transform_dict_to_rows(dbt_utils.get_query_results_as_dict(dq_rules_query)) %}

    -- Initialize results array
    {% set results = [] %}

    -- Get current timestamp once (Asia/Kolkata timezone)
    {% set current_date = dbt_utils.get_query_results_as_dict("SELECT cast(DATETIME(CURRENT_TIMESTAMP(), 'Asia/Kolkata') as string) AS today")['today'] %}

    -- Process each uniqueness rule
    {% for rule in dq_rules %}
        {% do log("Processing uniqueness rule " ~ rule['dq_rule_sk'], info=true) %}
        
        -- Prepare table reference
        {% set table_ref %}
            {% if rule['source_type'] == 'CDS' %}
                {{ ref(rule['table_name']) }}
            {% else %}
                {{ db_source(rule['source_name'], rule['table_name']) }} 
            {% endif %}
        {% endset %}
        
        -- Prepare filter clause if present
        {% set filter_clause = '' %}
        {% if rule['filters'] %}
            {% set filter_clause = 'WHERE ' ~ rule['filters'] | replace('{env}', target.name) %}
        {% endif %}
        
        -- Build and execute main query to find duplicates
        {% set query %}
        BEGIN
            SELECT COUNT(*) AS row_count
            FROM (
                SELECT {{ rule['column_name'] }}, COUNT(*)
                FROM {{ table_ref }}
                {{ filter_clause }}
                GROUP BY {{ rule['column_name'] }}
                HAVING COUNT(*) > 1
            );
        EXCEPTION WHEN ERROR THEN
            SELECT -1 AS row_count;
        END;
        {% endset %}
        
        -- Execute query and get duplicate count
        {% set query_result = dbt_utils.get_query_results_as_dict(query) %}
        {% set row_count = query_result['row_count'][0] %}
        {% do log("Duplicate count for rule " ~ rule['dq_rule_sk'] ~ ": " ~ row_count, info=true) %}
        
        -- Check passes if no duplicates found (row_count = 0)
        {% set valid_check = 1 if row_count == 0 else 0 %}
        
        -- Execute result query if provided
        {% set output_query_result = '' %}
        {% if rule['result_query'] %}
            {% set result_query = rule['result_query'] | replace('{env}', target.name) %}
            {% do log("Executing result query for rule " ~ rule['dq_rule_sk'], info=true) %}
            {% set result_query_output = dbt_utils.get_query_results_as_dict(result_query) %}
            {% set output_query_result = transform_dict_to_rows(result_query_output) %}
            
            -- Update validity check based on result query output
            {% if tojson(output_query_result) == '[]' %}
                {% set valid_check = 0 %}
            {% endif %}
        {% endif %}
        
        -- Sanitize output for JSON formatting
        {% set sanitized_output = tojson(output_query_result) | replace("'", '"') | replace('"Oreal', "\\'Oreal") %}
        
        -- Prepare result row with consistent formatting
        {% set result_row = [
            rule['dq_rule_sk'],
            '',
            valid_check,
            '',
            current_date[0],
            "'" ~ sanitized_output ~ "'"
        ] %}
        
        -- Add to results list
        {% do results.append(result_row) %}
        {% do log("Added result for rule " ~ rule['dq_rule_sk'], info=true) %}
        {% do log("Query used: " ~ query, info=true) %}
    {% endfor %}

    {% do log("RESULT " ~ results , info=true) %}
    {% do log("Completed processing " ~ results | length ~ " uniqueness rules", info=true) %}
    
    -- Generate and return the final query
    {{ dq_rule_query_generator(results) }}
{% endmacro %}