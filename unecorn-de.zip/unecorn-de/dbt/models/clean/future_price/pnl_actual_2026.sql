{{ config(materialized='view') }}

WITH price_2026 AS (
    SELECT year, 
    period, 
    product_code AS compass_code, 
    dist_channel_code, 
    dist_channel, 
    product, 
    value_local
    FROM {{db_source('src_future_price','pnl_by_product_prebudget_official_2026_aggregated_v1')}}   
    WHERE pnl_product = {{variable_macro('unit_list_price_var')}}
    AND multidivision_cluster IN {{variable_macro('vietnam_var')}}
    -- AND dist_channel IN {{variable_macro('dist_channel_var')}}
)

SELECT * FROM price_2026