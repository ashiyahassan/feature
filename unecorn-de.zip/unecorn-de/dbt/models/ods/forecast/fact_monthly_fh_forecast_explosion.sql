-- depends_on: {{ ref('fact_monthly_forecast') }}

{{ 
    config(
        materialized='incremental',
        pre_hook = [
            "{{ update_active_flag('cds_unecorn_process_zn','fact_monthly_fh_forecast_explosion') }}"
        ], 
        post_hook =[
             "{{ upd_active_ver_flag('cds_unecorn_process_zn','fact_monthly_fh_forecast_explosion') }}"
        ],
        partition_by = {
            "field": "forecast_gen_date",
            "data_type": "date",
            "granularity": "day"
        }
    ) 
}}
WITH model_run_date AS ( 
    SELECT * FROM 
    (
        SELECT 
            CAST(forecast_gen_date AS DATE) AS model_run_date,
            CAST(LAG(forecast_gen_date) OVER(ORDER BY forecast_gen_date) AS DATE) AS m1_date,
            CAST(LAG(forecast_gen_date,3) OVER(ORDER BY forecast_gen_date) AS DATE) AS m3_date
        FROM 
        (
            SELECT DISTINCT 
                forecast_gen_date 
            FROM {{ref('fact_monthly_forecast')}}
            ORDER BY forecast_gen_date 
        )  
        ORDER BY model_run_date 
    )
    {% if is_incremental() %}
    WHERE  model_run_date >= (SELECT MAX(forecast_gen_date) FROM {{ref('fact_monthly_forecast')}})
    -- AND active_version_flag = 1 AND active_month_flag = 1
    -- {% else %}
    -- WHERE  model_run_date > DATE_TRUNC(DATE_SUB(CURRENT_DATE(), INTERVAL 15 MONTH), MONTH)
    -- AND active_version_flag = 1 
    {% endif %}

),
monthly_forecast AS (
    SELECT  
        ean_code,
        forecast_gen_date,
        forecast_date,
        platform_code,
        platform_name, 
        country_code,
        division_code,
        signature_code,
        signature_name,
        bundle_explosion,
        bundle_type,
        campaign_type,
        lifecycle,  
        ai_model_forecast,
        consensus_forecast,
        validated_forecast,
        -- m_1_ai_fc,
        -- m_1_validated_fc,
        -- m_1_consensus_fc,
        -- m_3_ai_fc,
        -- m_3_validated_fc,
        -- m_3_consensus_fc,
        comments_consensus,
        comments_validated,
        expected_sales_price,
        nmv_ai_model_forecast_value,
        nmv_validated_forecast_value,
        nmv_consensus_forecast_value,
        retail_sales_price,
        retail_ai_model_forecast_value,
        retail_validated_forecast_value,
        retail_consensus_forecast_value,
        -- nmv_ai_model_forecast_value_m_1,
        -- nmv_validated_forecast_value_m_1,
        -- nmv_consensus_forecast_value_m_1,
        -- retail_ai_model_forecast_value_m_1,
        -- retail_validated_forecast_value_m_1,
        -- retail_consensus_forecast_value_m_1
    FROM {{ref('fact_monthly_forecast_explosion')}}
    WHERE active_version_flag = 1
),

daily_forecast AS (
    SELECT 
        ean_code, 
        forecast_gen_date,
        DATE_TRUNC(forecast_date, MONTH) AS forecast_date,
        platform_code,
        platform_name, 
        country_code,
        division_code,
        signature_code,
        signature_name,
        bundle_explosion,
        bundle_type,
        campaign_type,
        lifecycle,
        SUM(ai_model_forecast) AS ai_model_forecast,
        SUM(consensus_forecast) AS consensus_forecast, 
        SUM(validated_forecast) AS validated_forecast,
        -- SUM(m_1_ai_fc) AS m_1_ai_fc,
        -- SUM(m_1_validated_fc) AS m_1_validated_fc,
        -- SUM(m_1_consensus_fc) AS m_1_consensus_fc,
        -- SUM(m_3_ai_fc) AS m_3_ai_fc,
        -- SUM(m_3_validated_fc) AS m_3_validated_fc, 
        -- SUM(m_3_consensus_fc) AS m_3_consensus_fc, 
        MAX(comments_consensus),
        MAX(comments_validated),
        MAX(expected_sales_price) AS expected_sales_price,
        SUM(nmv_ai_model_forecast_value) AS nmv_ai_model_forecast_value,
        SUM(nmv_validated_forecast_value) AS nmv_validated_forecast_value,
        SUM(nmv_consensus_forecast_value) AS nmv_consensus_forecast_value,
        MAX(retail_sales_price) AS retail_sales_price,
        SUM(retail_ai_model_forecast_value) AS retail_ai_model_forecast_value,
        SUM(retail_validated_forecast_value) AS retail_validated_forecast_value,
        SUM(retail_consensus_forecast_value) AS retail_consensus_forecast_value,
        -- SUM(nmv_ai_model_forecast_value_m_1) AS nmv_ai_model_forecast_value_m_1,
        -- SUM(nmv_validated_forecast_value_m_1) AS nmv_validated_forecast_value_m_1,
        -- SUM(nmv_consensus_forecast_value_m_1) AS nmv_consensus_forecast_value_m_1,
        -- SUM(retail_ai_model_forecast_value_m_1) AS retail_ai_model_forecast_value_m_1,
        -- SUM(retail_validated_forecast_value_m_1) AS retail_validated_forecast_value_m_1,
        -- SUM(retail_consensus_forecast_value_m_1) AS retail_consensus_forecast_value_m_1        
    FROM {{ref('fact_daily_forecast_explosion')}} 
    WHERE active_version_flag = 1 
    GROUP BY 
    forecast_sk, 
    ean_code, 
    forecast_gen_date,
    DATE_TRUNC(forecast_date,MONTH),
    platform_code,
    platform_name, 
    country_code,
    division_code,
    signature_code,
    signature_name,
    bundle_explosion,
    bundle_type,
    campaign_type,
    lifecycle  
),
src_data AS (
    SELECT * FROM monthly_forecast 
    UNION ALL 
    SELECT * FROM daily_forecast
),
forecast_data AS (        
    SELECT  DISTINCT
        M0.ean_code,
        M0.forecast_gen_date,
        M0.forecast_date,
        M0.platform_code,
        M0.platform_name, 
        M0.country_code,
        M0.division_code,
        M0.signature_code,
        M0.signature_name,
        M0.bundle_explosion,
        M0.bundle_type, 
        M0.campaign_type,
        M0.lifecycle,
        M0.ai_model_forecast,
        M0.consensus_forecast,
        M0.comments_consensus,
        M0.validated_forecast,
        M0.comments_validated,
        M1.ai_model_forecast AS m_1_ai_fc,
        M1.consensus_forecast AS m_1_consensus_fc,
        M1.validated_forecast AS m_1_validated_fc,
        M3.ai_model_forecast AS m_3_ai_fc,
        M3.consensus_forecast AS m_3_consensus_fc,
        M3.validated_forecast AS m_3_validated_fc,
        M0.expected_sales_price,
        -- M0.nmv_ai_model_forecast_value,
        -- M0.nmv_validated_forecast_value,
        -- M0.nmv_consensus_forecast_value,
        M0.retail_sales_price,
        -- M0.retail_ai_model_forecast_value,
        -- M0.retail_validated_forecast_value,
        -- M0.retail_consensus_forecast_value,
        -- M1.nmv_ai_model_forecast_value AS nmv_ai_model_forecast_value_m_1,
        -- M1.nmv_validated_forecast_value AS nmv_validated_forecast_value_m_1,
        -- M1.nmv_consensus_forecast_value AS nmv_consensus_forecast_value_m_1,
        -- M1.retail_ai_model_forecast_value AS retail_ai_model_forecast_value_m_1,
        -- M1.retail_validated_forecast_value AS retail_validated_forecast_value_m_1,
        -- M1.retail_consensus_forecast_value AS retail_consensus_forecast_value_m_1,
    FROM
    (
        SELECT
            ean_code ,
            a.forecast_gen_date,
            forecast_date,            
            platform_code,
            platform_name, 
            country_code,
            division_code,
            signature_code, 
            signature_name,
            bundle_explosion,
            bundle_type,
            campaign_type,
            lifecycle,
            ai_model_forecast,
            consensus_forecast,
            comments_consensus,
            validated_forecast,
            comments_validated,
            expected_sales_price,
            nmv_ai_model_forecast_value,
            nmv_validated_forecast_value,
            nmv_consensus_forecast_value,
            retail_sales_price,
            retail_ai_model_forecast_value,
            retail_validated_forecast_value,
            retail_consensus_forecast_value,
            -- load_ts
        FROM src_data AS a
        INNER JOIN model_run_date AS b
        ON a.forecast_gen_date = b.model_run_date
    ) AS M0
    LEFT JOIN
    (
        SELECT
            ean_code ,
            b.model_run_date AS forecast_gen_date,
            forecast_date,
            platform_code,
            platform_name, 
            country_code,
            division_code,
            signature_code,
            signature_name,
            bundle_explosion,
            bundle_type, 
            campaign_type,
            lifecycle,
            ai_model_forecast,
            consensus_forecast,
            comments_consensus,
            validated_forecast,
            comments_validated,
            expected_sales_price,
            nmv_ai_model_forecast_value,
            nmv_validated_forecast_value,
            nmv_consensus_forecast_value,
            retail_sales_price,
            retail_ai_model_forecast_value,
            retail_validated_forecast_value,
            retail_consensus_forecast_value,
        FROM src_data AS a
        INNER JOIN model_run_date AS b
        ON a.forecast_gen_date = b.m1_date
    ) AS M1
    ON M0.forecast_gen_date = M1.forecast_gen_date
    AND M0.forecast_date = M1.forecast_date
    AND M0.platform_code = M1.platform_code
    AND M0.signature_code = M1.signature_code
    AND M0.ean_code = M1.ean_code
    AND M0.campaign_type = M1.campaign_type
    AND M0.bundle_explosion = M1.bundle_explosion
    AND M0.bundle_type = M1.bundle_type
    LEFT JOIN
    (
        SELECT
            ean_code ,
            b.model_run_date AS forecast_gen_date,
            forecast_date,
            platform_code,
            platform_name, 
            country_code,
            division_code,
            signature_code,
            signature_name,
            bundle_explosion,
            bundle_type, 
            campaign_type,
            lifecycle,
            ai_model_forecast,
            consensus_forecast,
            comments_consensus,
            validated_forecast,
            comments_validated,
            expected_sales_price,
            nmv_ai_model_forecast_value,
            nmv_validated_forecast_value,
            nmv_consensus_forecast_value,
            retail_sales_price,
            retail_ai_model_forecast_value,
            retail_validated_forecast_value,
            retail_consensus_forecast_value,
        FROM src_data AS a
        INNER JOIN model_run_date AS b
        ON a.forecast_gen_date = b.m3_date
    ) AS M3
    ON M0.forecast_gen_date = M3.forecast_gen_date
    AND M0.forecast_date = M3.forecast_date
    AND M0.platform_code = M3.platform_code
    AND M0.signature_code = M3.signature_code
    AND M0.ean_code = M3.ean_code 
    AND M0.campaign_type  =  M3.campaign_type
    AND M0.bundle_explosion  =  M3.bundle_explosion
    AND M0.bundle_type  =  M3.bundle_type
)

SELECT 
    dp.forecast_sk,
    dc.campaign_sk,
    sd.*,
    expected_sales_price * ai_model_forecast AS nmv_ai_model_forecast_value,
    expected_sales_price * validated_forecast AS nmv_validated_forecast_value,
    expected_sales_price * consensus_forecast AS nmv_consensus_forecast_value,
    -- retail_sales_price,
    retail_sales_price * ai_model_forecast AS retail_ai_model_forecast_value,
    retail_sales_price * validated_forecast AS retail_validated_forecast_value,
    retail_sales_price * consensus_forecast AS retail_consensus_forecast_value,
    expected_sales_price * m_1_ai_fc AS nmv_ai_model_forecast_value_m_1,
    expected_sales_price * m_1_validated_fc AS nmv_validated_forecast_value_m_1,
    expected_sales_price * m_1_consensus_fc AS nmv_consensus_forecast_value_m_1,
    retail_sales_price * m_1_ai_fc AS retail_ai_model_forecast_value_m_1,
    retail_sales_price * m_1_validated_fc AS retail_validated_forecast_value_m_1,
    retail_sales_price * m_1_consensus_fc AS retail_consensus_forecast_value_m_1,
    'LT' AS time_flag,
    dim_date.date_key AS date_sk,
    CAST(DATE_TRUNC(sd.forecast_date, MONTH)AS DATE) AS month_start_date,
    CAST(DATE_ADD(DATE_TRUNC(sd.forecast_date, MONTH), INTERVAL 1 MONTH) - INTERVAL 1 DAY AS DATE) AS month_end_date,
    bet.bundle_sk,
    CAST(NULL AS TIMESTAMP) AS updated_date,
    CAST(NULL AS STRING) AS user_name,
    CAST(NULL AS STRING) AS file_name,
    CASE 
        WHEN forecast_gen_date = (SELECT MAX(forecast_gen_date) FROM {{ref('fact_monthly_forecast_explosion')}} ) THEN 1
        ELSE 0 
    END AS active_month_flag,
    1 AS active_version_flag,
    CURRENT_TIMESTAMP() AS load_ts
FROM
forecast_data AS sd 
JOIN 
(
    SELECT 
        product_sk AS forecast_sk,
        ean_code,
        platform_name,
        country_code,
        division_code
    FROM {{ref('dim_product')}}
) dp
ON sd.ean_code = dp.ean_code
AND UPPER(sd.platform_name) = UPPER(dp.platform_name)
AND sd.country_code = dp.country_code
AND sd.division_code = dp.division_code
LEFT JOIN {{ref('dim_date')}} AS dim_date 
ON sd.forecast_date = dim_date.date
LEFT JOIN
(
    SELECT 
        bundle_sk,
        bundle_type,
        bundle_explosion
    FROM {{ref('bundle_explosion_type')}}
) AS bet
ON sd.bundle_type = bet.bundle_type
AND sd.bundle_explosion = bet.bundle_explosion
LEFT JOIN {{ref('dim_campaign')}} AS dc
ON sd.forecast_date = CAST(dc.date AS DATE)
AND sd.platform_name = dc.platform_name
AND sd.signature_code = dc.signature_code