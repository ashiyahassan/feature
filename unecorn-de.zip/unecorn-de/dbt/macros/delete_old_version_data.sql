{% macro delete_old_version_data(dataset_name, table_name,base_table_name) %}

{% set project_id = target.project %}

{% if project_id == 'spmena-unecorn-zn-apac-dv' %}
    {% set base_dataset = 'cds_unecorn_ml_output_zn_e2e' %}
{% else %}
    {% set base_dataset = 'cds_unecorn_ml_output_zn' %}
{% endif %}

{% if execute and is_incremental() %}

    {{ print("Running delete_old_version_data: "~ dataset_name ~", "~ table_name~","~project_id) }}
    EXECUTE IMMEDIATE '''DELETE FROM `{{ project_id }}.{{ dataset_name }}.{{ table_name }}`
                        WHERE forecast_gen_date = (SELECT MAX(CAST(model_run_date AS DATE )) 
                        FROM `{{ project_id }}.{{ base_dataset }}.{{ base_table_name }}`)
                '''


{% endif %}
{{ print("completed delete_old_version_data: ") }} 
{% endmacro %}