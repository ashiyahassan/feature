{{ config(materialized='table') }}

WITH source_data AS (
    SELECT
        ean_code,
        marketplace_code,
        oms_platform_product_status,
        status_from_masterdata,
        launch_date,
        discontinuation_date,
        mm_status,
        sd_status,
        material_type,
        material_group,
        histroical_sales_flag,
        unecorn_status,
        scope_within_unecorn,
        unecorn_status_flag,
        unecorn_histroical_sales_flag,
        discontinue_flag,
        launch_flag,
        CASE
            WHEN scope_within_unecorn=2 AND unecorn_status_flag=1 THEN 'Active & Not Modelled'          
            WHEN scope_within_unecorn=2 AND unecorn_status_flag in (1,2) THEN 'Dummy Code & Not Modelled'
            WHEN scope_within_unecorn=1 AND unecorn_status_flag=1 AND unecorn_histroical_sales_flag IN (0,2) AND discontinue_flag IN (1,2) AND launch_flag=0
            THEN 'Future Launch'
            WHEN scope_within_unecorn=1 AND unecorn_status_flag=1 AND unecorn_histroical_sales_flag IN (0,2) AND discontinue_flag IN (1,2) AND launch_flag=1
            THEN 'New Launch (<3M sales)'
            WHEN scope_within_unecorn=1 AND unecorn_status_flag=1 AND unecorn_histroical_sales_flag=1 AND discontinue_flag =2 AND launch_flag=1
            THEN 'Ongoing (modelled)'
            WHEN scope_within_unecorn=1 AND unecorn_status_flag=1 AND unecorn_histroical_sales_flag=1 AND discontinue_flag=1 AND launch_flag=1
            THEN 'To be Discont. (modelled)'
            WHEN scope_within_unecorn IN (1,2) AND unecorn_status_flag=0 AND unecorn_histroical_sales_flag IN (0,1) AND discontinue_flag IN (0,2) AND launch_flag=1
            THEN 'Discont.'
            WHEN  scope_within_unecorn IN (1,2) AND unecorn_status_flag=0 AND unecorn_histroical_sales_flag=2  
            THEN 'Do not show in tool'
            WHEN  scope_within_unecorn=0
            THEN 'Do not show in tool'
            ELSE 'Not define'
            END AS unecorn_lifecycle
    FROM
    (
        SELECT
            a.ean_code,
            marketplace_code,
            oms_platform_product_status,
            status_from_masterdata,
            launch_date,
            discontinuation_date,
            mm_status,
            sd_status,
            material_type,
            material_group,
            histroical_sales_flag,
            unecorn_status,
            CASE
                WHEN L_3_flag='out of scope' AND unecorn_status IS NULL THEN  0
                WHEN (material_type='YFG' AND material_group IN ('110','140')) OR (material_type='YVIB' AND material_group='183') OR (a.ean_code LIKE '%DUM%') THEN 1
                WHEN (material_type='YSM2' AND  material_group IN ('190','401','YE010101')) THEN 2
                WHEN (material_type IN ('YPL2','YPS2') AND flag = 1) THEN 2
                ELSE 0
            END AS scope_within_unecorn,
            CASE
                WHEN  unecorn_status='Active' THEN 1
                WHEN  unecorn_status='Inactive' THEN 0
                WHEN COALESCE(unecorn_status,'') ='' THEN
                    CASE
                        WHEN oms_platform_product_status IN ('create_failed','draft','listed','listing_inprocess','new','ready_to_go','rejected','update_failed','under_review') THEN 1
                        WHEN oms_platform_product_status IN ('deleted','delisted') THEN 0
                        ELSE 2
                    END
                END AS unecorn_status_flag,
            CASE
                WHEN  l_3_flag = 'out of scope' THEN 2
                WHEN  l_3_flag = 'in scope' THEN
                    CASE
                        WHEN histroical_sales_flag = 'N' THEN 0
                        WHEN  histroical_sales_flag = 'Y' THEN 1
                    END
            END AS unecorn_histroical_sales_flag,
            CASE
                WHEN discontinuation_date= '' OR discontinuation_date IS  NULL THEN 2
                WHEN PARSE_DATE('%Y-%m',discontinuation_date ) >=  DATE_TRUNC(CURRENT_DATE(), MONTH)   THEN 1
                WHEN PARSE_DATE('%Y-%m',discontinuation_date ) <  DATE_TRUNC(CURRENT_DATE(), MONTH)   THEN 0
            END AS discontinue_flag,
            CASE
                WHEN launch_date= '' OR launch_date IS  NULL THEN 1
                WHEN PARSE_DATE('%Y-%m',launch_date ) <=  DATE_TRUNC(CURRENT_DATE(), MONTH)   THEN 1
                WHEN PARSE_DATE('%Y-%m',launch_date ) >  DATE_TRUNC(CURRENT_DATE(), MONTH)   THEN 0
            END AS launch_flag                                        
        FROM {{ref('int_ean_list')}} AS a
        LEFT JOIN 
        (
            SELECT DISTINCT 
                ean_code, 1 flag 
            FROM {{ref('platform_product')}} 
            WHERE signature_code = 'PH'
            UNION DISTINCT
            SELECT DISTINCT 
                ean_code, 1 flag 
            FROM {{ref('master_data_forecast_file_data')}} 
            WHERE active_status = 'Y' AND signature = 'PH'
        ) AS ce_ean
        ON a.ean_code = ce_ean.ean_code
    )
)
SELECT sd.ean_code,
        sd.marketplace_code,
        sd.oms_platform_product_status,
        sd.status_from_masterdata,
        sd.launch_date,
        sd.discontinuation_date,
        sd.mm_status,
        sd.sd_status,
        sd.material_type,
        sd.material_group,
        sd.histroical_sales_flag,
        sd.unecorn_status,
        sd.scope_within_unecorn,
        sd.unecorn_status_flag,
        sd.unecorn_histroical_sales_flag,
        sd.discontinue_flag,
        sd.launch_flag,
        CASE 
            WHEN sd.unecorn_lifecycle = "Ongoing (modelled)" AND SD.marketplace_code = "TIKTOK_VN" THEN "New Launch (<3M sales)"
            WHEN sd.unecorn_lifecycle = "To be Discont. (modelled)" AND SD.marketplace_code = "TIKTOK_VN" THEN "New Launch (<3M sales)"
            ELSE sd.unecorn_lifecycle
        END AS unecorn_lifecycle,
mm.d2c_unecorn_status, 
CURRENT_TIMESTAMP() AS load_ts 
FROM source_data sd
LEFT JOIN 
( 
    SELECT * FROM {{ref('master_data_forecast_file_data')}}
    WHERE active_status = 'Y'
) AS mm
ON sd.ean_code = mm.ean_code
AND sd.marketplace_code = mm.marketplace_code