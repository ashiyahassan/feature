{{ config(materialized='table') }}

WITH OMS AS (
  SELECT 
  DISTINCT order_date
FROM {{db_source('src_selluseller_data','oms_selluseller')}}
    WHERE  kit_sku = ''
    AND DATE_TRUNC(order_date, MONTH) = DATE_TRUNC(CURRENT_DATE(), MONTH)
)

SELECT 
    *, 
    'sellout_v3' AS source_table,
    CURRENT_TIMESTAMP() AS load_ts
FROM
(
    SELECT
        country,
        division,
        marketplace_code,
        signature_code,
        ean_code,
        sellout_year,
        sellout_month,
        sellout_date,
        sellout_date_code,        
        SUM(
            CASE
                WHEN order_status IN ('COMPLETED', 'DELIVERED') THEN bundle_quantity
            ELSE
                0
            END
        ) AS daily_delivered_units,
        SUM(
            CASE
                WHEN order_status IN ('CANCELLED', 'CANCELLATION IN PROGRESS','FAILED DELIVERY') THEN bundle_quantity
            ELSE
                0
            END
        ) AS daily_cancelled_units,
        SUM(
            CASE
                WHEN order_status IN ('RETURN APPROVED', 'RETURN IN PROGRESS', 'RETURN COMPLETED', 'RETURN INITIATED', 'RETURN REJECTED') THEN bundle_quantity
            ELSE
                0
            END
        ) AS daily_returned_units,
        SUM(
            CASE
                WHEN order_status IN ('COMPLETED', 'DELIVERED', 'MULTIPLE_STATUS', 'NEW', 'CANCELLED', 'FAILED DELIVERY', 'CANCELLATION IN PROGRESS', 'SHIPPED', 'READY TO SHIP') THEN bundle_quantity
            ELSE
                0
            END
        ) AS daily_gmv_units,
        SUM(COALESCE(net_sellout_value_loc_tax_included,0)) AS daily_net_sellout_value_local_tax_included,
        SUM(
            CASE
                WHEN order_status IN ('COMPLETED', 'MULTIPLE_STATUS', 'READY TO SHIP', 'PENDING', 'CANCELLED', 'SHIPPED', 'FAILED DELIVERY', 'DELIVERED', 'NEW', 'CANCELLATION IN PROGRESS') THEN net_sellout_value_loc_tax_included
            ELSE
                0
            END
        ) AS gmv,
        SUM(COALESCE(net_sellout_value_eur_tax_included,0)) AS daily_net_sellout_value_eural_tax_included,
        SUM(COALESCE(net_sellout_value_usd_tax_included,0)) AS daily_net_sellout_value_usdal_tax_included,
        SUM(COALESCE(net_sellout_value_loc_tax_excluded,0)) AS daily_net_sellout_value_local_tax_excluded,
        SUM(COALESCE(net_sellout_value_eur_tax_excluded,0)) AS daily_net_sellout_value_eural_tax_excluded,
        SUM(COALESCE(net_sellout_value_usd_tax_excluded,0)) AS daily_net_sellout_value_usdal_tax_excluded,
        SUM(COALESCE(gross_sellout_value_loc_tax_included,0)) AS daily_gross_sellout_value_local_tax_included,
        SUM(COALESCE(gross_sellout_value_eur_tax_included,0)) AS daily_gross_sellout_value_eural_tax_included,
        SUM(COALESCE(gross_sellout_value_usd_tax_included,0)) AS daily_gross_sellout_value_usdal_tax_included,
        SUM(COALESCE(gross_sellout_value_loc_tax_excluded,0)) AS daily_gross_sellout_value_local_tax_excluded,
        SUM(COALESCE(gross_sellout_value_eur_tax_excluded,0)) AS daily_gross_sellout_value_eural_tax_excluded,
        SUM(COALESCE(gross_sellout_value_usd_tax_excluded,0)) AS daily_gross_sellout_value_usdal_tax_excluded,
        -- SUM(COALESCE(nmv_doc,0)) AS nmv,
        SUM(
            CASE
                WHEN order_status IN ('COMPLETED', 'DELIVERED') THEN nmv_doc
            ELSE
                0
            END
        ) AS nmv,
        AVG(COALESCE(unit_price,0)) AS unit_price
    FROM {{ref('sellout_d2c_v3')}}
	WHERE sellout_date < DATE_TRUNC(DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL {{ var('month_interval')}} MONTH), MONTH)
    GROUP BY
        country,
        division,
        marketplace_code,
        signature_code,
        ean_code,
        sellout_year,
        sellout_month,
        sellout_date,
        sellout_date_code
)

UNION ALL

(SELECT  
    'VN' AS country, 
    'CPD' AS division,
    CASE 
        WHEN Marketplace = 'Lazada Vietnam' THEN {{ variable_macro('lazada_vn_var')}}  
        WHEN Marketplace = 'Shopee Vietnam' THEN {{ variable_macro('shopee_vn_var')}} 
        WHEN Marketplace = 'Tiktok Vietnam' THEN {{ variable_macro('tiktok_vn_var')}}
    END AS  marketplace_code,
    signature_code,
    ean_code,
    sellout_year,
    sellout_month,
    sellout_date, 
    CAST(CAST(sellout_date AS STRING FORMAT 'YYYYMMDD') AS INT64) AS sellout_date_code,
    COALESCE(delivered_units, 0) AS delivered_units,
    COALESCE(cancelled_units, 0) AS cancelled_units, 
    COALESCE(returned_units, 0) AS returned_units,
    gmv_units,
    bpa_inc_shipping,
    gmv,
    daily_net_sellout_value_eural_tax_included,
    daily_net_sellout_value_usdal_tax_included,
    daily_net_sellout_value_local_tax_excluded,
    daily_net_sellout_value_eural_tax_excluded,
    daily_net_sellout_value_usdal_tax_excluded,
    daily_gross_sellout_value_local_tax_included,
    daily_gross_sellout_value_eural_tax_included,
    daily_gross_sellout_value_usdal_tax_included,
    daily_gross_sellout_value_local_tax_excluded,
    daily_gross_sellout_value_eural_tax_excluded,
    daily_gross_sellout_value_usdal_tax_excluded,
    nmv,
    unit_price,
    'selluseller' AS source_table,
    CURRENT_TIMESTAMP() AS load_ts
FROM
(
    SELECT 
        CAST(REGEXP_REPLACE( UPC, r'^0+','') AS STRING) AS ean_code,
        Marketplace,
        signature_code,
        EXTRACT(year FROM order_date) AS sellout_year,
        EXTRACT(month FROM order_date) AS sellout_month,
        order_date AS sellout_date,
        SUM(CASE WHEN Order_Status IN ('Completed','Delivered')  THEN  CAST(Item_Quantity AS NUMERIC) END ) AS delivered_units,
        SUM(CASE WHEN Order_Status IN ('Cancelled')  THEN  CAST(Item_Quantity AS NUMERIC) END ) AS cancelled_units,
        SUM(CASE WHEN Order_Status IN ('Return Scrapped','Return Completed','Return In Progress','Return Approved','Return Rejected','Return Initiated')  THEN  CAST(Item_Quantity AS NUMERIC) END ) AS returned_units,
        SUM(CASE WHEN Order_Status IN ('Completed','Delivered','Cancelled','Failed Delivery','New','Draft','Cancellation in Progress','Pending','Unpaid','Ready to Ship','Shipped')  THEN  CAST(Item_Quantity AS NUMERIC) END ) AS gmv_units,
        SUM(COALESCE(bpa_inc__shipping,0)) AS bpa_inc_shipping,
        SUM(CASE WHEN Order_Status IN ('Completed','Delivered','Cancelled','Failed Delivery','New','Draft','Cancellation in Progress','Pending','Unpaid','Ready to Ship','Shipped')  THEN  (COALESCE(bpa_inc__shipping,0)) END ) AS gmv,
        NULL AS daily_net_sellout_value_eural_tax_included,
        NULL AS daily_net_sellout_value_usdal_tax_included,
        NULL AS daily_net_sellout_value_local_tax_excluded,
        NULL AS daily_net_sellout_value_eural_tax_excluded,
        NULL AS daily_net_sellout_value_usdal_tax_excluded,
        NULL AS daily_gross_sellout_value_local_tax_included,
        NULL AS daily_gross_sellout_value_eural_tax_included,
        NULL AS daily_gross_sellout_value_usdal_tax_included,
        NULL AS daily_gross_sellout_value_local_tax_excluded,
        NULL AS daily_gross_sellout_value_eural_tax_excluded,
        NULL AS daily_gross_sellout_value_usdal_tax_excluded,
        SUM
        (
            CASE 
                WHEN Order_Status IN ('Completed','Delivered')  THEN  (COALESCE(bpa_inc__shipping,0)) 
            END 
        ) AS nmv,
        NULL AS unit_price,
    FROM 
    (
        SELECT 
            *,
            CASE 
                WHEN storename LIKE '%Garnier%' THEN 'P4'
                WHEN storename LIKE '%Maybelline%' THEN 'P5'
                WHEN storename LIKE '%L\'Oreal Paris%' THEN 'P2'
                WHEN storename LIKE '%3CE%' THEN 'PH'
                ELSE NULL 
            END AS signature_code 
        FROM 


{{db_source('src_selluseller_data','oms_selluseller')}}



    )
    WHERE  kit_sku = ''
    AND order_date >= DATE_TRUNC(DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL {{ var('month_interval')}} MONTH), MONTH)
    GROUP BY 1,2,3,4,5,6

    UNION ALL 


    --------------------Header ean  calculation  KITSKU<>'nan'------------------------------------------------------
    SELECT  
        ean_code,
        Marketplace,
        signature_code,
        sellout_year,
        sellout_month,
        sellout_date,
        delivered_units/component_quantity AS delivered_units,
        cancelled_units/component_quantity AS cancelled_units,
        returned_units/component_quantity AS returned_units,
        gmv_units/component_quantity AS gmv_units,
        bpa_inc_shipping,
        gmv,
        daily_net_sellout_value_eural_tax_included,
        daily_net_sellout_value_usdal_tax_included,
        daily_net_sellout_value_local_tax_excluded,
        daily_net_sellout_value_eural_tax_excluded,
        daily_net_sellout_value_usdal_tax_excluded,
        daily_gross_sellout_value_local_tax_included,
        daily_gross_sellout_value_eural_tax_included,
        daily_gross_sellout_value_usdal_tax_included,
        daily_gross_sellout_value_local_tax_excluded,
        daily_gross_sellout_value_eural_tax_excluded,
        daily_gross_sellout_value_usdal_tax_excluded,
        nmv,
        unit_price
    FROM
    (
        SELECT 
            SUBSTR(KIT_SKU, 1, 13) AS ean_code,
            Marketplace,
            signature_code,
            EXTRACT(year FROM order_date) AS sellout_year,
            EXTRACT(month FROM order_date) AS sellout_month,
            order_date AS sellout_date,
            SUM(CASE WHEN Order_Status IN ('Completed','Delivered')  THEN  CAST(Item_Quantity AS NUMERIC) END ) AS delivered_units,
            SUM(CASE WHEN Order_Status IN ('Cancelled')  THEN  CAST(Item_Quantity AS NUMERIC) END ) AS cancelled_units,
            SUM(CASE WHEN Order_Status IN ('Return Scrapped','Return Completed','Return In Progress','Return Approved','Return Rejected','Return Initiated')  THEN  CAST(Item_Quantity AS NUMERIC) END ) AS returned_units,
            SUM(CASE WHEN Order_Status IN ('Completed','Delivered','Cancelled','Failed Delivery','New','Draft','Cancellation in Progress','Pending','Unpaid','Ready to Ship','Shipped')  THEN  CAST(Item_Quantity AS NUMERIC) END ) AS gmv_units,
            SUM(COALESCE(bpa_inc__shipping,0)) AS bpa_inc_shipping,
            SUM(CASE WHEN Order_Status IN ('Completed','Delivered','Cancelled','Failed Delivery','New','Draft','Cancellation in Progress','Pending','Unpaid','Ready to Ship','Shipped')  THEN  (COALESCE(bpa_inc__shipping,0)) END ) AS gmv,
            NULL AS daily_net_sellout_value_eural_tax_included,
            NULL AS daily_net_sellout_value_usdal_tax_included,
            NULL AS daily_net_sellout_value_local_tax_excluded,
            NULL AS daily_net_sellout_value_eural_tax_excluded,
            NULL AS daily_net_sellout_value_usdal_tax_excluded,
            NULL AS daily_gross_sellout_value_local_tax_included,
            NULL AS daily_gross_sellout_value_eural_tax_included,
            NULL AS daily_gross_sellout_value_usdal_tax_included,
            NULL AS daily_gross_sellout_value_local_tax_excluded,
            NULL AS daily_gross_sellout_value_eural_tax_excluded,
            NULL AS daily_gross_sellout_value_usdal_tax_excluded,
            SUM
            (
                CASE WHEN Order_Status IN ('Completed','Delivered')  THEN  (COALESCE(bpa_inc__shipping,0)) END 
            ) AS nmv,
            NULL AS unit_price
        FROM 
        (
            SELECT 
                *,
                CASE 
                    WHEN storename LIKE '%Garnier%' THEN 'P4'
                    WHEN storename LIKE '%Maybelline%' THEN 'P5'
                    WHEN storename LIKE '%L\'Oreal Paris%' THEN 'P2'
                    WHEN storename LIKE '%3CE%' THEN 'PH'
                    ELSE NULL 
                END AS signature_code
            FROM 


{{db_source('src_selluseller_data','oms_selluseller')}}



        )
        WHERE  kit_sku <> ''
        AND order_date >= DATE_TRUNC(DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL {{ var('month_interval')}} MONTH), MONTH)
        GROUP BY 1,2,3,4,5,6
    ) AS a
    ---------------------------- Bom table -----------------------------------------------
    LEFT JOIN 
    (
        SELECT DISTINCT 
            bom_header_ean_code,
            SUM(m_factor * component_quantity) AS component_quantity 
        FROM {{ref('bom_explosion_factor')}}
        WHERE bom_header_ean_code IS NOT NULL AND local_bom_type_description = 'VB'
        GROUP BY 1
    ) AS b
    ON a.ean_code = b.bom_header_ean_code
)

UNION ALL

SELECT 
    *, 
    'sellout_v3' AS source_table,
    CURRENT_TIMESTAMP() AS load_ts
FROM
(
    SELECT
        country,
        division,
        marketplace_code,
        signature_code,
        ean_code,
        sellout_year,
        sellout_month,
        sellout_date,
        sellout_date_code,        
        SUM(
            CASE
                WHEN order_status IN ('COMPLETED', 'DELIVERED') THEN bundle_quantity
            ELSE
                0
            END
        ) AS daily_delivered_units,
        SUM(
            CASE
                WHEN order_status IN ('CANCELLED', 'CANCELLATION IN PROGRESS','FAILED DELIVERY') THEN bundle_quantity
            ELSE
                0
            END
        ) AS daily_cancelled_units,
        SUM(
            CASE
                WHEN order_status IN ('RETURN APPROVED', 'RETURN IN PROGRESS', 'RETURN COMPLETED', 'RETURN INITIATED', 'RETURN REJECTED') THEN bundle_quantity
            ELSE
                0
            END
        ) AS daily_returned_units,
        SUM(
            CASE
                WHEN order_status IN ('COMPLETED', 'DELIVERED', 'MULTIPLE_STATUS', 'NEW', 'CANCELLED', 'FAILED DELIVERY', 'CANCELLATION IN PROGRESS', 'SHIPPED', 'READY TO SHIP') THEN bundle_quantity
            ELSE
                0
            END
        ) AS daily_gmv_units,
        SUM(COALESCE(net_sellout_value_loc_tax_included,0)) AS daily_net_sellout_value_local_tax_included,
        SUM(
            CASE
                WHEN order_status IN ('COMPLETED', 'MULTIPLE_STATUS', 'READY TO SHIP', 'PENDING', 'CANCELLED', 'SHIPPED', 'FAILED DELIVERY', 'DELIVERED', 'NEW', 'CANCELLATION IN PROGRESS') THEN net_sellout_value_loc_tax_included
            ELSE
                0
            END
        ) AS gmv,
        SUM(COALESCE(net_sellout_value_eur_tax_included,0)) AS daily_net_sellout_value_eural_tax_included,
        SUM(COALESCE(net_sellout_value_usd_tax_included,0)) AS daily_net_sellout_value_usdal_tax_included,
        SUM(COALESCE(net_sellout_value_loc_tax_excluded,0)) AS daily_net_sellout_value_local_tax_excluded,
        SUM(COALESCE(net_sellout_value_eur_tax_excluded,0)) AS daily_net_sellout_value_eural_tax_excluded,
        SUM(COALESCE(net_sellout_value_usd_tax_excluded,0)) AS daily_net_sellout_value_usdal_tax_excluded,
        SUM(COALESCE(gross_sellout_value_loc_tax_included,0)) AS daily_gross_sellout_value_local_tax_included,
        SUM(COALESCE(gross_sellout_value_eur_tax_included,0)) AS daily_gross_sellout_value_eural_tax_included,
        SUM(COALESCE(gross_sellout_value_usd_tax_included,0)) AS daily_gross_sellout_value_usdal_tax_included,
        SUM(COALESCE(gross_sellout_value_loc_tax_excluded,0)) AS daily_gross_sellout_value_local_tax_excluded,
        SUM(COALESCE(gross_sellout_value_eur_tax_excluded,0)) AS daily_gross_sellout_value_eural_tax_excluded,
        SUM(COALESCE(gross_sellout_value_usd_tax_excluded,0)) AS daily_gross_sellout_value_usdal_tax_excluded,
        -- SUM(COALESCE(nmv_doc,0)) AS nmv,
        SUM(
            CASE
                WHEN order_status IN ('COMPLETED', 'DELIVERED') THEN nmv_doc
            ELSE
                0
            END
        ) AS nmv,
        AVG(COALESCE(unit_price,0)) AS unit_price
    FROM {{ref('sellout_d2c_v3')}}
	WHERE DATE_TRUNC(sellout_date, MONTH) = DATE_TRUNC(CURRENT_DATE(), MONTH)
    GROUP BY
        country,
        division,
        marketplace_code,
        signature_code,
        ean_code,
        sellout_year,
        sellout_month,
        sellout_date,
        sellout_date_code

) WHERE NOT EXISTS (
    SELECT 1 FROM OMS
))