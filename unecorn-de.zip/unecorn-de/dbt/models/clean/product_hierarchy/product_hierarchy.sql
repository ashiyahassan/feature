{{ 
  config(
    materialized='incremental',
    unique_key=['sku_code','meta_validity_from']
  ) 
}}

WITH source_data AS (
    SELECT internal_product_code AS sku_code, 
    operational_division AS division, 
    CASE
      WHEN operational_signature_label IN {{variable_macro('mbl_brand_var')}} THEN {{variable_macro('mbl_title_var')}}
      WHEN operational_signature_label IN {{variable_macro('oap_brand_var')}} THEN {{variable_macro('oap_title_var')}}
      WHEN operational_signature_label IN {{variable_macro('grn_brand_var')}} THEN {{variable_macro('grn_title_var')}}
      WHEN operational_signature_label IN {{variable_macro('3ce_brand_var')}} THEN {{variable_macro('3ce_var')}}
      ELSE operational_signature_label
    END AS signature_label,
    -- operational_signature_label AS signature_label, 
    operational_brand_label AS brand_label, 
    operational_sub_brand_label AS sub_brand_label, 
    operational_reference_label AS reference_label, 
    operational_nuance_label AS nuance_label, 
    operational_axe_label AS axe_label, 
    operational_sub_axe_label AS sub_axe_label, 
    operational_metier_label AS metier_label, 
    operational_sub_metier_label AS sub_metier_label, 
    operational_signature_code AS signature_code, 
    operational_brand_code AS brand_code, 
    operational_sub_brand_code AS sub_brand_code, 
    operational_reference_code AS reference_code, 
    operational_nuance_code AS nuance_code, 
    operational_axe_code AS axe_code, 
    operational_sub_axe_code AS sub_axe_code, 
    operational_metier_code AS metier_code, 
    operational_sub_metier_code AS sub_metier_code, 
    full_hierarchy_code,
    source_system,
    a1257_supply_entity,
    meta_validity_from, 
    meta_validity_to,
    meta_loading_date,
    CURRENT_TIMESTAMP() AS load_ts
    FROM {{db_source('src_product_v3','sku_hierarchy_source_v5')}} AS a
    INNER JOIN (
      SELECT
        a0001_internal_product_code,
        a1257_supply_entity
      FROM
        {{db_source('src_product_v3','sku_location_v4')}} ) AS b
    ON
      a.internal_product_code = b.a0001_internal_product_code
    WHERE
      (a.source_system = {{variable_macro('elixpedia_var')}} OR
      a.source_system = {{variable_macro('ecc_var')}})
      AND a.operational_division IN {{variable_macro('division_var')}}
      AND b.a1257_supply_entity IN {{variable_macro('location_var')}}
    {% if is_incremental() %}

      -- this filter will only be applied on an incremental run
      -- (uses > to include records whose timestamp occurred since the last run of this model)
      AND meta_validity_from > (SELECT MAX(meta_validity_from) FROM {{ this }})

    {% endif %}
)

SELECT * FROM source_data