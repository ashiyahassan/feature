{{ config(materialized='table') }}

WITH source_data AS (
    SELECT material AS sku_code, 
    active_material AS active_sku_code,
    valid_from_date,
    valid_to_date,
    insert_timestamp,
    CURRENT_TIMESTAMP() AS load_ts
    FROM {{db_source('src_substitution','mm_substitution_v1')}}   
    WHERE plant IN {{variable_macro('location_var')}}
    {% if is_incremental() %}
    AND insert_timestamp > (select max(insert_timestamp) from {{ this }})
    {% endif %}
)

SELECT * FROM source_data
