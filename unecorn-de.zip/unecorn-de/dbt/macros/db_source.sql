{% macro db_source(source_name, table_name) %}

{% if target.name == 'pd' %} 
{{ source(source_name + '_pd', table_name)}}
{% elif target.name == 'qa' %}
{{ source(source_name + '_qa', table_name)}}
{% elif target.name == 'np' %}
{{ source(source_name + '_np', table_name)}}
{% else %}
{{ source(source_name, table_name)}}
{% endif %}

{% endmacro %}