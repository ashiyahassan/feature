{{ 
  config(
    materialized='table'
  ) 
}}

WITH source_data AS (
    SELECT
        LTRIM(ean, '0') AS ean_code,
        list_price_neo AS sales_price,
        sales_organization,
        distribution_channel,
        country_id,
        division,
        material_code as sku_code,
        start_date,
        end_date,
        insertion_time,
        CURRENT_TIMESTAMP() AS load_ts
    FROM {{db_source('src_rsp','list_price_v1')}}
    WHERE sales_organization IN {{variable_macro('sales_organization_var')}}
    AND country_id IN {{variable_macro('country_var')}}
    AND division IN {{variable_macro('division_var')}}
    AND ean IS NOT NULL
),

cast_data AS (
    SELECT
        ean_code,
        sales_price,
        sales_organization,
        distribution_channel,
        country_id,
        division,
        sku_code,
        start_date AS valid_from,
        end_date AS valid_to,
        (CASE WHEN start_date > '9000-01-01' THEN CURRENT_TIMESTAMP() ELSE start_date END) AS start_date,
        (CASE WHEN end_date > '9000-01-01' THEN CURRENT_TIMESTAMP() ELSE end_date END) AS end_date,
        insertion_time,
        load_ts
    FROM source_data
)

SELECT * FROM  cast_data 