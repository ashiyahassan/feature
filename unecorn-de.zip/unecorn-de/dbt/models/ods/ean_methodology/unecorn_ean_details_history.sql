{{ 
    config(
        materialized='incremental',
        pre_hook =[
            "{{ delete_current_month_data('cds_unecorn_process_zn', 'unecorn_ean_details_history', 'unecorn_ean_details') }}"
        ]       
    ) 
}}

SELECT
    CAST(DATE_TRUNC(load_ts, MONTH) AS DATE) AS forecast_gen_date,
    ean_code,
    marketplace_code,
    oms_platform_product_status,
    status_from_masterdata,
    launch_date,
    discontinuation_date,
    mm_status,
    sd_status,
    material_type,
    material_group,
    histroical_sales_flag,
    unecorn_status,
    scope_within_unecorn,
    unecorn_status_flag,
    unecorn_histroical_sales_flag,
    discontinue_flag,
    launch_flag,
    unecorn_lifecycle,
    d2c_unecorn_status,
    load_ts AS source_load_ts,
    CURRENT_TIMESTAMP() AS load_ts
FROM {{ref('unecorn_ean_details')}}