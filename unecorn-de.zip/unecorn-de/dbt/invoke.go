package main

import (
	"fmt"
	"log"
	"net/http"
	"os"
	"os/exec"
	"strings"
	"context"
    "io"
    "cloud.google.com/go/storage"
)

func handler(w http.ResponseWriter, r *http.Request) {
	log.Print("Unecorn DBT pipeline : received a request")
	str1 := r.URL.Query().Get("arg1") // Retrieve first argument from query parameter

	log.Print("Unecorn DBT pipeline : received a request")

	parts := strings.Split(str1, ",")

	arg1 := parts[0]
	arg2 := parts[1]
	arg3 := parts[2]
	var cmd *exec.Cmd
	arg4 := parts[3]
	arg5 := parts[4]
	arg6 := parts[5]
	
	// Retrieve second argument from query parameter
    log.Print("DBT arg1 | path: ",arg1)
	log.Print("DBT arg2 | workflow_id: ",arg2)
	log.Print("DBT arg3 | Date: ",arg3)
	log.Print("DBT arg4 | type: ",arg4)
	log.Print("DBT arg5 | ENV: ",arg5)
	log.Print("DBT arg6 | Bucket_name: ",arg6)
	
	// log.Print("DBT arg4: ",arg4)
	// Check if both arguments are provided
    if arg1 == "" || arg2 == "" ||  arg3 == "" || arg4 == "" ||  arg5 == "" ||  arg6 == "" {
		// if arg1 == "" {
		w.WriteHeader(http.StatusBadRequest)
		fmt.Fprintf(w, "Please provide arguments arg1, agr2, arg3, agr4, arg5, arg6")
		return
	}
	log.Print("DBT pipeline initialized")
	// cmd := exec.CommandContext(r.Context(), "/bin/sh", "script.sh", arg1, arg2)
    if arg4 == "I" {
		cmd = exec.CommandContext(r.Context(), "/bin/sh", "script.sh", arg1, arg2, arg3,arg5)
	} else if arg4 == "S" {
		cmd = exec.CommandContext(r.Context(), "/bin/sh", "script_static.sh", arg1, arg2, arg3,arg5)
	} else if arg4 == "V" {
		arg7 := parts[6]
		log.Print("DBT arg7 | var: ",arg7)
		cmd = exec.CommandContext(r.Context(), "/bin/sh", "script_var.sh", arg1, arg2, arg3, arg5, arg7)
	} else {
		cmd = exec.CommandContext(r.Context(), "/bin/sh", "script_reset.sh", arg1, arg2, arg3,arg5)		
	}

	
	cmd.Stderr = os.Stderr
	//Initialized log
	fmt.Printf("Initializing Logging mechanism")
	bucketName := arg6 //"un_de_setup_files_dev"
	objectName := "logs/"+arg2+"/"+arg1+"/"+arg3+"/dbt.log"
	filePath := "logs/"+arg2+"/"+arg1+"/"+arg3+"/dbt.log"
	fmt.Printf(bucketName) 
	fmt.Printf(filePath) 
	
	
	fmt.Printf("logfiles Uploaded")
	out, err := cmd.Output()
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
	
		err := uploadFileToGCS(bucketName, objectName, filePath)
		if err != nil {
			fmt.Printf("ERROR CREATEING LOG")
			// Handle error
		}
		fmt.Printf("LOG CREATED")
		fmt.Fprintf(w, "Error executing the script: %s", err)
		return
	}
	log.Print("DBT Pipeline Executed succesfully!")
	
	uploadFileToGCS(bucketName, objectName, filePath)
	fmt.Printf("LOG CREATED")
	
	w.Write(out)
}

// Simple cleanHandler that just runs dbt clean
func cleanHandler(w http.ResponseWriter, r *http.Request) {
	log.Print("DBT Clean: received a request")
	
	// Run dbt clean command directly
	cmd := exec.Command("dbt", "clean")
	
	// Capture the output
	output, err := cmd.CombinedOutput()
	
	// Log the output for debugging
	log.Printf("DBT Clean output: %s", string(output))
	
	if err != nil {
		log.Printf("Error running dbt clean: %v", err)
		w.WriteHeader(http.StatusInternalServerError)
		fmt.Fprintf(w, "Error running dbt clean: %v\n\nOutput: %s", err, string(output))
		return
	}
	
	log.Print("DBT Clean executed successfully")
	fmt.Fprintf(w, "DBT Clean executed successfully.\n\nOutput: %s", string(output))
}

func uploadFileToGCS(bucketName, objectName, filePath string) error {
    ctx := context.Background()

    // Create a GCS client.
    client, err := storage.NewClient(ctx)
    if err != nil {
        return fmt.Errorf("failed to create client: %v", err)
    }

    // Open the local file.
    f, err := os.Open(filePath)
    if err != nil {
        return fmt.Errorf("failed to open file: %v", err)
    }
    defer f.Close()

    // Get a reference to the GCS bucket.
    bucket := client.Bucket(bucketName)

    // Create a writer to the GCS object.
    wc := bucket.Object(objectName).NewWriter(ctx)

    // Copy the file to the GCS object.
    if _, err = io.Copy(wc, f); err != nil {
        return fmt.Errorf("failed to upload file: %v", err)
    }

    // Close the writer to finalize the upload.
    if err := wc.Close(); err != nil {
        return fmt.Errorf("failed to close writer: %v", err)
    }

    fmt.Printf("File uploaded to GCS bucket: %s, object: %s\n", bucketName, objectName)
    return nil
}

func main() {
	log.Print("UNeCORN DBT pipeline: starting server...")

	http.HandleFunc("/", handler)
	
	// Add the new clean endpoint
	http.HandleFunc("/clean", cleanHandler)

	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	log.Printf("UNeCORN DBT pipeline : listening on %s", port)
	log.Fatal(http.ListenAndServe(fmt.Sprintf(":%s", port), nil))
}