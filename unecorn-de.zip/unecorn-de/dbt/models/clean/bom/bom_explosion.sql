{{ config(materialized='incremental') }}

WITH source_data AS (
    SELECT bom_header_code,
    location,
    bom_alternative,
    bom_usage,
    item_position,
    component_code,
    bom_explosion_category,
    bom_level,
    parent_code,
    unit_of_measure,
    component_quantity,
    source_catalog_name,
    loading_date,
    source_system,
    CURRENT_TIMESTAMP() AS load_ts
    FROM {{db_source('src_product','sku_bom_explosion_v1')}}   
    WHERE location IN {{variable_macro('location_var')}}
    {% if is_incremental() %}

      -- this filter will only be applied on an incremental run
      -- (uses > to include records whose timestamp occurred since the last run of this model)
      AND loading_date > (select max(loading_date) from {{ this }})

    {% endif %}
)
SELECT * FROM source_data
