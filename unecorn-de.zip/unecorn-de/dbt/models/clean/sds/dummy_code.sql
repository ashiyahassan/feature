{{ config(materialized='table') }}
 
WITH source_data AS (
    SELECT 
        record_type,
        compass_product_code AS ean_code,
        product_label,
        fm_level_2,
        dummy_1,
        dummy_2,
        dummy_3,
        dummy_4,
        dummy_5,
        dummy_6,
        dummy_7,
        dummy_8,
        dummy_9,
        dummy_10,
        dummy_11,
        signature,
        signature_description,
        brand,
        brand_description,
        sub_brand,
        sub_brand_description,
        reference_code,
        reference_code_description,
        attribute_n_5,
        axe_code,
        axe_code_description,
        subaxe_code,
        subaxe_code_description,
        class_code,
        class_code_description,
        function_code,
        function_code_description,
        fm_material_type,
        fm_material_group,
        fm_sales_status,
        attribute_n_13,
        material,
        attribute_n_15,
        attribute_n_16,
        compass_product_code_1,
        attribute_n_18,
        business_units,
        compass_channel_code,
        country_code,
        active_status,
        hash_map,
        CURRENT_TIMESTAMP() AS load_ts
    FROM {{ db_source('src_manual_files','vn_cpd_dummy_code_file_data') }} 
    WHERE signature IN {{variable_macro('dummy_code_signature_var')}}
)

SELECT *,
{{variable_macro('shopee_vn_var')}} AS platform_code,
{{variable_macro('shp_upper_var')}} AS platform_name 
FROM source_data 

UNION ALL 

SELECT *,
{{variable_macro('lazada_vn_var')}} AS platform_code,
{{variable_macro('lzd_upper_var')}} AS platform_name
FROM source_data 

UNION ALL

SELECT *,
{{variable_macro('tiktok_vn_var')}} AS platform_code,
{{variable_macro('tiktok_upper_var')}} AS platform_name
FROM source_data 