import functions_framework
import pandas as pd
from google.cloud import storage
from google.cloud import bigquery
import holidays
import datetime
from dim_date_functions import *


@functions_framework.http
def http_hello(request):
    request_json = request.get_json(silent=True)
    try:
        max_end_date = get_end_date(request_json["project_id"],request_json["dataset_id"],request_json["table_name"],) + 1
        if request_json["table_name"] == "dim_holiday_calendar":
            if max_end_date - 1 == 2023:
                Holiday_calendar(request_json["project_id"],request_json["dataset_id"],request_json["bucket_name"],start_date=f"2020-01-01", end_date=f"2025-12-31"
                )
            else:
                Holiday_calendar(request_json["project_id"],request_json["dataset_id"],request_json["bucket_name"],
                    start_date=f"{max_end_date}-01-01",
                    end_date=f"{max_end_date}-12-31",
                )
        else:
            if max_end_date - 1 == 2025:
                dim_date(
                request_json["project_id"],
                request_json["dataset_id"],
                request_json["table_name"],
                start_date= datetime.date(2020,1,1), 
                end_date=datetime.date(max_end_date,12,31) 
                )
            else:
                dim_date(
                request_json["project_id"],
                request_json["dataset_id"],
                request_json["table_name"],
                start_date= datetime.date(max_end_date,1,1), 
                end_date=datetime.date(max_end_date,12,31) 
                )

        # save_to_gcs(request_json["project_id"],request_json["dataset_id"],request_json["bucket_name"])
        return "Successfully load into gcs and uploaded to bq"
    except Exception as e:
        print("Exception !!!", e)
        return "failed"

def get_end_date(project_id="spmena-unecorn-zn-apac-dv", dataset_id="dev_sa_test",table_name="dim_holiday_calendar"):
    print("inside get_end_date function with parameters",project_id,dataset_id,table_name)
    client = bigquery.Client()
    try:
        max_year_query = client.query(
            f"SELECT max(year) as year FROM `{project_id}.{dataset_id}.{table_name}`"
        )
        for max_year in max_year_query.result():
            return max_year["year"]
    except Exception as e:
        return 2023 if table_name == "dim_holiday_calendar" else 2025
    finally:
        client.close()


def Holiday_calendar(project_id, dataset_id,bucket_name,start_date, end_date):
    print("inside holiday_calendar function with parameters",project_id,dataset_id)
    print("start_date:", start_date, " end_date:", end_date)
    holiday_list = []
    us_holidays = holidays.country_holidays("US")
    cn_holidays = holidays.country_holidays("CN")
    vn_holidays = holidays.country_holidays("VN")
    for dt in pd.date_range(start=start_date, end=end_date):
        if vn_holidays.get(dt):
            holiday_list.append(["VN", dt, vn_holidays.get(dt)])
        if cn_holidays.get(dt):
            holiday_list.append(["CN", dt, cn_holidays.get(dt)])
        if us_holidays.get(dt):
            holiday_list.append(["US", dt, us_holidays.get(dt)])
    #   print(len(holiday_list))
    #   print(holiday_list)
    hdf = pd.DataFrame(holiday_list, columns=["country", "date", "holiday"])
    hdf["year"] = pd.to_datetime(hdf["date"]).dt.year
    hdf["file_path"] = f"gs://{bucket_name}/dim_holiday_calendar.csv"
    hdf['date_key'] = (hdf['date'].astype(str).str.replace('-', '')).astype(int)
    hdf["insert_time"] = pd.to_datetime(
        datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    )
    hdf["update_time"] = pd.to_datetime(
        datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    )
    hdf = hdf[
        [
            "country",
            "year",
            "date",
            "date_key",
            "holiday",
            "insert_time",
            "update_time",
            "file_path",
        ]
    ]
    try:
        odf = pd.read_csv(f"gs://{bucket_name}/dim_holiday_calendar.csv")
        odf = pd.concat([odf,hdf])
        odf.to_csv(f"gs://{bucket_name}/dim_holiday_calendar.csv", index=False)
    except Exception as e:
        print("Exception !!!",e)
        hdf.to_csv(f"gs://{bucket_name}/dim_holiday_calendar.csv", index=False)
    print("end holiday_calendar function with parameters")
    load_to_bq(hdf,project_id,dataset_id)


# def save_to_gcs(project_id,dataset_id,bucket_name):
#     print("inside save_to_gcs function with parameters",project_id,dataset_id,bucket_name)
#     bucket_name = bucket_name
#     blob_name = "dim_holiday_calendar.csv"
#     try:
#         client = storage.Client()
#         bucket = client.bucket(bucket_name)
#         blob = bucket.blob(blob_name)
#         blob.upload_from_filename("./dim_holiday_calendar.csv")
#         print("uploaded to GCS successfully..............")
#     except Exception as e:
#         print("Exception !!!",e)

def load_to_bq(hdf, project_id="spmena-unecorn-zn-apac-dv", dataset_id="dev_sa_test"):
    print("inside load_to_bq function with parameters",project_id,dataset_id)
    client = bigquery.Client()
    table_id = "dim_holiday_calendar"
    try:
        job_config = bigquery.LoadJobConfig(
            schema=[
                bigquery.SchemaField("country", bigquery.enums.SqlTypeNames.STRING),
                bigquery.SchemaField("year", bigquery.enums.SqlTypeNames.INT64),
                bigquery.SchemaField("date", bigquery.enums.SqlTypeNames.DATE),
                bigquery.SchemaField("date_key", bigquery.enums.SqlTypeNames.INT64),
                bigquery.SchemaField("holiday", bigquery.enums.SqlTypeNames.STRING),
                bigquery.SchemaField("insert_time", bigquery.enums.SqlTypeNames.TIMESTAMP),
                bigquery.SchemaField("update_time", bigquery.enums.SqlTypeNames.TIMESTAMP),
                bigquery.SchemaField("file_path", bigquery.enums.SqlTypeNames.STRING),
            ],
            write_disposition=bigquery.WriteDisposition.WRITE_APPEND,
        )
        query_job = client.load_table_from_dataframe(
            hdf, f"{project_id}.{dataset_id}.{table_id}", job_config=job_config
        )
        query_job.result()
        print("Inserted into BQ successfully..............")
    except Exception as e:
        print("Exception !!!",e)
    finally:
        client.close()

def dim_date(project_id, dataset_id, table_id, start_date, end_date):
    ll = [
        "Date_Key",
        "Date",
        "Year",
        "Start_of_Year",
        "End_of_Year",
        "Month",
        "Start_of_Month",
        "End_of_Month",
        "Days_in_Month",
        "Day",
        "Day_Name",
        "Day_of_Week",
        "Day_of_Year",
        "Month_Name",
        "Quarter",
        "Start_of_Quarter",
        "End_of_Quarter",
        "Week_of_Year",
        "Week_of_Month",
        "Start_of_Week",
        "End_of_Week",
        "Year_Month",
        "Year_Month_Code",
        "Year_Month_space",
        "Day_Number_space",
        "Week_No_of_Year",
        "Week_Number_Space",
        "Month_short_name",
        "Month_Year",
        "Week_Year_sort",
        "Week_Year",
        "Month_Year_FH",
        "CALENDAR_YEAR_QUARTER_NUMBER",
        "CALENDAR_YEAR",
        "CALENDAR_QUARTER",
        "load_ts",
    ]

    date_cols = [i.lower() for i in ll]
    df = pd.DataFrame(columns=date_cols)
    try:
        for i in range((end_date - start_date).days + 1):
            current_date = start_date + dt.timedelta(days=i)
            df.loc[i] = [
                datekey(current_date),
                pd.to_datetime(current_date),
                int(current_date.year),
                pd.to_datetime(start_of_year(current_date)),
                pd.to_datetime(end_of_year(current_date)),
                int(current_date.month),
                pd.to_datetime(start_of_month(current_date)),
                pd.to_datetime(end_of_month(current_date)),
                int(days_in_month(current_date)),
                int(current_date.day),
                day_name(current_date),
                int(day_of_week(current_date)),
                int(day_of_year(current_date)),
                calendar_month_name(current_date),
                int(calendar_quarter(current_date)),
                pd.to_datetime(start_of_quarter(current_date)),
                pd.to_datetime(end_of_quarter(current_date)),
                int(week_number_in_year(current_date)),
                int(week_of_month(current_date)),
                pd.to_datetime(start_of_week(current_date)),
                pd.to_datetime(end_of_week(current_date)),
                calendar_year_month(current_date),
                int(calendar_year_month_code(current_date)),
                "year_month_space",
                "day_number_space",
                calendar_week_number_in_year(current_date),
                "week_number_space",
                calendar_month_short_name(current_date),
                month_year_format(current_date),
                week_year_sort(current_date),
                week_year(current_date),
                month_year_fh(current_date),
                calendar_year_quarter_number(current_date),
                int(current_date.year),
                calendar_quarter(current_date),
                pd.to_datetime("2024-04-26 07:49:41.496930 UTC"),
            ]
    except Exception as e:
        # traceback.print_exc()
        print("Exception at dim_date for loop !!!", e)
        # print("line at: ",traceback.tb_lineno)
        # exit(0)
    print("df completed")
    try:
        append_flag = False if end_date == 2027 else True
        load_to_bq_dim_date(df,append_flag, project_id, dataset_id, table_id)
    except Exception as e:
        # traceback.print_exc()
        print("exception at load to bq")
        # print("line at: ",traceback.tb_lineno)
        # exit(0)
    try:
        dim_date_query(project_id, dataset_id, table_id)
    except Exception as e:
        # traceback.print_exc()
        print("exception at update",e)
        # print("line at: ",traceback.tb_lineno)
        # exit(0)


def dim_date_query(project_id, dataset_id, table_id):
    client = bigquery.Client()
    max_year_query = client.query(
            f"SELECT max(year) as year FROM `{project_id}.{dataset_id}.{table_id}`"
        )
    for max_year in max_year_query.result():
        last_year = max_year["year"]
    print("max_year for update: ", last_year)
    # query = f"""update `{project_id}.{dataset_id}.{table_id}` set week_number_space = CONCAT('    ', WEEK_NO_OF_YEAR, '    '),year_month_space = CONCAT('    ', CONCAT(month_short_name, ' ', SUBSTRING(CAST(year AS STRING),3,2)), '    '),day_number_space = CONCAT('     ',DAY,'     '),load_ts = CURRENT_TIMESTAMP() where 1=1"""
    query = f"""
    UPDATE `{project_id}.{dataset_id}.{table_id}` 
    SET 
        week_number_space = CONCAT('    ', WEEK_NO_OF_YEAR, '    '),
        year_month_space = CONCAT('    ', CONCAT(month_short_name, ' ', SUBSTR(CAST(year AS STRING), 3, 2)), '    '),
        day_number_space = CONCAT('     ', DAY, '     '),
        load_ts = CURRENT_TIMESTAMP()
    WHERE year = {last_year}
    """
    print("query: ",query)
    try:
        query_job = client.query(query)  # Submit the query
        query_job.result()  # Wait for query to finish
        print("Query updated successfully.")
        print(f"Rows affected: {query_job.num_dml_affected_rows}")
        print(f"Query job state: {query_job.state}")
        print(f"Job ID: {query_job.job_id}")

    except BadRequest as e:
        print("Query failed:", e)
    finally:
        client.close()

def load_to_bq_dim_date(
    df,append_flag, project_id="spmena-unecorn-zn-apac-dv", dataset_id="dev_sa_test", table_id = "dim_date"
):
    # print(df.head())
    # print(df.dtypes)
    print("inside load_to_bq_dim_date function with parameters", project_id, dataset_id, table_id)
    client = bigquery.Client()
    # table_id = "dim_date"
    try:
        job_config = bigquery.LoadJobConfig(
            schema=[
                bigquery.SchemaField("date_key", bigquery.enums.SqlTypeNames.INT64),
                bigquery.SchemaField("date", bigquery.enums.SqlTypeNames.DATE),
                bigquery.SchemaField("year", bigquery.enums.SqlTypeNames.INT64),
                bigquery.SchemaField("start_of_year", bigquery.enums.SqlTypeNames.DATE),
                bigquery.SchemaField("end_of_year", bigquery.enums.SqlTypeNames.DATE),
                bigquery.SchemaField("month", bigquery.enums.SqlTypeNames.INT64),
                bigquery.SchemaField(
                    "start_of_month", bigquery.enums.SqlTypeNames.DATE
                ),
                bigquery.SchemaField("end_of_month", bigquery.enums.SqlTypeNames.DATE),
                bigquery.SchemaField(
                    "days_in_month", bigquery.enums.SqlTypeNames.INT64
                ),
                bigquery.SchemaField("day", bigquery.enums.SqlTypeNames.INT64),
                bigquery.SchemaField("day_name", bigquery.enums.SqlTypeNames.STRING),
                bigquery.SchemaField("day_of_week", bigquery.enums.SqlTypeNames.INT64),
                bigquery.SchemaField("day_of_year", bigquery.enums.SqlTypeNames.INT64),
                bigquery.SchemaField("month_name", bigquery.enums.SqlTypeNames.STRING),
                bigquery.SchemaField("quarter", bigquery.enums.SqlTypeNames.INT64),
                bigquery.SchemaField(
                    "start_of_quarter", bigquery.enums.SqlTypeNames.DATE
                ),
                bigquery.SchemaField(
                    "end_of_quarter", bigquery.enums.SqlTypeNames.DATE
                ),
                bigquery.SchemaField("week_of_year", bigquery.enums.SqlTypeNames.INT64),
                bigquery.SchemaField(
                    "week_of_month", bigquery.enums.SqlTypeNames.INT64
                ),
                bigquery.SchemaField("start_of_week", bigquery.enums.SqlTypeNames.DATE),
                bigquery.SchemaField("end_of_week", bigquery.enums.SqlTypeNames.DATE),
                bigquery.SchemaField("year_month", bigquery.enums.SqlTypeNames.STRING),
                bigquery.SchemaField(
                    "year_month_code", bigquery.enums.SqlTypeNames.INT64
                ),
                bigquery.SchemaField(
                    "year_month_space", bigquery.enums.SqlTypeNames.STRING
                ),
                bigquery.SchemaField(
                    "day_number_space", bigquery.enums.SqlTypeNames.STRING
                ),
                bigquery.SchemaField(
                    "week_no_of_year", bigquery.enums.SqlTypeNames.STRING
                ),
                bigquery.SchemaField(
                    "week_number_space", bigquery.enums.SqlTypeNames.STRING
                ),
                bigquery.SchemaField(
                    "month_short_name", bigquery.enums.SqlTypeNames.STRING
                ),
                bigquery.SchemaField("month_year", bigquery.enums.SqlTypeNames.STRING),
                bigquery.SchemaField(
                    "week_year_sort", bigquery.enums.SqlTypeNames.INT64
                ),
                bigquery.SchemaField("week_year", bigquery.enums.SqlTypeNames.STRING),
                bigquery.SchemaField(
                    "month_year_fh", bigquery.enums.SqlTypeNames.STRING
                ),
                bigquery.SchemaField(
                    "calendar_year_quarter_number", bigquery.enums.SqlTypeNames.STRING
                ),
                bigquery.SchemaField(
                    "calendar_year", bigquery.enums.SqlTypeNames.INT64
                ),
                bigquery.SchemaField(
                    "calendar_quarter", bigquery.enums.SqlTypeNames.INT64
                ),
                bigquery.SchemaField("load_ts", bigquery.enums.SqlTypeNames.TIMESTAMP),
            ],
            write_disposition=bigquery.WriteDisposition.WRITE_APPEND if append_flag else bigquery.WriteDisposition.WRITE_TRUNCATE,
        )
        query_job = client.load_table_from_dataframe(
            df, f"{project_id}.{dataset_id}.{table_id}", job_config=job_config
        )
        query_job.result()
        
        print("Inserted into BQ successfully..............")
    except Exception as e:
        # traceback.print_exc()
        print("Exception at load_to_bq_dim_date !!!", e)
        # print("line at: ",trace?back.tb_lineno)
        # exit(0)
    finally:
        client.close()