{{ config(materialized='table') }}

WITH source_data AS (
    SELECT
        source_system,
        system_id,
        destination_system,
        destination_system_id,
        id,
        fm_customer_level_5,
        fm_customer_level_4,
        fm_customer_level_3,
        hub_plant,
        forecast_plant,
        sales_org,
        material_code AS sku_code,
        customer_circuit,
        start_month,
        day,
        month,
        year,
        month_m_quantity,
        month_m1_quantity,
        month_m2_quantity,
        month_m3_quantity,
        month_m4_quantity,
        month_m5_quantity,
        month_m6_quantity,
        month_m7_quantity,
        month_m8_quantity,
        month_m9_quantity,
        month_m10_quantity,
        month_m11_quantity,
        month_m12_quantity,
        month_m13_quantity,
        month_m14_quantity,
        month_m15_quantity,
        month_m16_quantity,
        month_m17_quantity,
        month_m18_quantity,
        month_m19_quantity,
        file_name,
        plant_country_code,
        plant_hub_country_code,
        plant_zone_code,
        plant_country_code_desc,
        plant_hub_country_code_desc,
        plant_zone_code_desc,
        division_amaas,
        insert_timestamp,
        unique_load_id,
        CURRENT_TIMESTAMP() AS load_ts
    FROM {{db_source('src_inventory','sales_forecast_daily_v1')}}
    WHERE plant_country_code IN {{variable_macro('country_var2')}}
    AND division_amaas IN {{variable_macro('division_var')}}
)

SELECT * FROM source_data