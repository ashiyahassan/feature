{{ 
    config(
        materialized='incremental',
        pre_hook = [
            "{{ update_active_flag('cds_unecorn_process_zn','fact_daily_forecast_explosion') }}"
        ], 
        post_hook =[
             "{{ upd_active_ver_flag('cds_unecorn_process_zn','fact_daily_forecast_explosion') }}"

        ],
        partition_by = {
            "field": "forecast_gen_date",
            "data_type": "date",
            "granularity": "day"
        }
    ) 
}}

WITH valid_kpi_date AS (
    SELECT  DISTINCT
        forecast_gen_date,
        forecast_gen_month,
		active_version_flag,
        active_month_flag,
        MAX(source_load_ts) OVER (PARTITION BY forecast_gen_date ORDER BY source_load_ts DESC) AS max_load_ts
    FROM
    (
        SELECT DISTINCT
            forecast_gen_date,
            FORMAT_DATE('%Y-%m', forecast_gen_date) AS forecast_gen_month,
            source_load_ts,
			active_version_flag,
            active_month_flag
        FROM {{ref('fact_daily_forecast')}}
    )    
    {% if is_incremental() %}
    WHERE  forecast_gen_date >= (SELECT MAX(forecast_gen_date) FROM {{ref('fact_daily_forecast')}})
    AND active_version_flag = 1 AND active_month_flag = 1
    {% else %}    
    WHERE  active_version_flag = 1
    -- AND forecast_gen_date > DATE_TRUNC(DATE_SUB(CURRENT_DATE(), INTERVAL 15 MONTH), MONTH)
    --AND active_month_flag = 1   
    {% endif %} 
),

daily_forecast AS (
    SELECT  
        forecast_sk,
        a.ean_code,
        a.forecast_gen_date,
        forecast_date,
        a.platform_code,
        a.platform_name,
        a.country_code,
        a.division_code,
        a.campaign_type,
        ai_model_forecast,  
        consensus_forecast,
        validated_forecast,
        m_1_ai_fc,
        m_1_validated_fc,  
        m_1_consensus_fc,
        m_3_ai_fc,
        m_3_validated_fc,
        m_3_consensus_fc,
        comments_consensus,
        comments_validated,
        file_name,
        source_load_ts,
        time_flag,
        updated_date,
        user_name       
    FROM
    (
        (
            SELECT DISTINCT 
                forecast_sk,
                ean_code,
                a.forecast_gen_date,
                forecast_date,
                platform_code,
                platform_name,
                country_code,
                division_code,
                campaign_type,
                ai_model_forecast,
                consensus_forecast,
                validated_forecast,
                m_1_ai_fc,
                m_1_validated_fc,
                m_1_consensus_fc,
                m_3_ai_fc,
                m_3_validated_fc,
                m_3_consensus_fc,
                comments_consensus,
                comments_validated,
                file_name,
                source_load_ts,
                time_flag,
                updated_date,
                user_name
            FROM {{ref('fact_daily_forecast')}} AS a
            INNER JOIN valid_kpi_date AS b
            ON a.forecast_gen_date=b.forecast_gen_date
            WHERE a.active_version_flag = 1
            AND b.active_version_flag = 1
        ) 
       
    ) AS A
),
bom_type AS (
    SELECT DISTINCT
        bom_header_ean_code,
        local_bom_type_description
    FROM {{ref('dim_bom_explosion_factor')}}
),
bom_explosion AS (
    SELECT DISTINCT
        bom_header_ean_code,
        component_ean_code,
        m_factor*component_quantity AS mf,
        local_bom_type_description
    FROM {{ref('dim_bom_explosion_factor')}}
    WHERE component_ean_code NOT IN (' ','')
),
unecorn_details AS (
    SELECT 
        unecorn_lifecycle,
        ean_code,
        marketplace_code,   
        CASE
            WHEN marketplace_code = {{variable_macro('shopee_vn_var')}} THEN {{variable_macro('shp_lower_var')}}
            WHEN marketplace_code = {{variable_macro('lazada_vn_var')}} THEN {{variable_macro('lzd_lower_var')}}
            WHEN  marketplace_code={{variable_macro('tiktok_vn_var')}} THEN {{variable_macro('tiktok_lower_var')}}
        ELSE
            marketplace_code
        END AS marketplace_name,        
        forecast_gen_date
    FROM           
        {{ref('unecorn_ean_details_history')}}      
),
all_forecasts AS (
----------------------------Single+PB+VB ---------------------------
 SELECT
    ean_code,
    a.forecast_gen_date,
    forecast_date,
    platform_code,
    platform_name,
    country_code,
    division_code,
    campaign_type,
    COALESCE(b.local_bom_type_description,'Single') AS bundle_type,
    'Single+PB+VB' AS bundle_explosion,
    ai_model_forecast,
    consensus_forecast,  
    validated_forecast,
    m_1_ai_fc,
    m_1_validated_fc,
    m_1_consensus_fc,
    m_3_ai_fc,
    m_3_validated_fc,  
    m_3_consensus_fc,
    comments_consensus,
    comments_validated,
    file_name,
    source_load_ts,
    time_flag,
    updated_date,
    user_name
FROM daily_forecast AS a
LEFT JOIN bom_type AS b
ON ean_code=bom_header_ean_code
 
UNION ALL
----------------------------VB+Single---------------------------
SELECT  
    ean_code,
    forecast_gen_date,
    forecast_date,
    platform_code,
    platform_name,
    country_code,
    division_code,
    campaign_type,
    bundle_type,
    bundle_explosion,
    SUM(ai_model_forecast),
    SUM(consensus_forecast),  
    SUM(validated_forecast),
    SUM(m_1_ai_fc),
    SUM(m_1_validated_fc),
    SUM(m_1_consensus_fc),
    SUM(m_3_ai_fc),
    SUM(m_3_validated_fc),  
    SUM(m_3_consensus_fc),
    MAX(comments_consensus),
    MAX(comments_validated),
    MAX(file_name),
    MAX(source_load_ts),
    time_flag,
    MAX(updated_date),
    MAX(user_name)
FROM
(
    SELECT  
        ean_code,
        a.forecast_gen_date,
        forecast_date,
        platform_code,
        platform_name,
        country_code,
        division_code,
        campaign_type,
        ai_model_forecast,
        consensus_forecast,  
        validated_forecast,
        m_1_ai_fc,
        m_1_validated_fc,
        m_1_consensus_fc,
        m_3_ai_fc,
        m_3_validated_fc,  
        m_3_consensus_fc,
        comments_consensus,
        comments_validated,
        COALESCE(b.local_bom_type_description,'Single') AS bundle_type,
        'VB+Single' AS bundle_explosion,
        file_name,
        source_load_ts,
        time_flag,
        updated_date,
        user_name  
    FROM daily_forecast AS a
    LEFT JOIN bom_type AS b
    ON ean_code=bom_header_ean_code
    WHERE b.local_bom_type_description <>'PB' or b.local_bom_type_description is null
 
    UNION ALL
 
    SELECT
        component_ean_code,
        a.forecast_gen_date,
        forecast_date,
        platform_code,
        platform_name,
        country_code,
        division_code,
        campaign_type,
        mf*ai_model_forecast AS ai_model_forecast,
        mf*consensus_forecast AS consensus_forecast,  
        mf*validated_forecast AS validated_forecast,
        mf*m_1_ai_fc AS m_1_ai_fc,
        mf*m_1_validated_fc AS m_1_validated_fc,
        mf*m_1_consensus_fc AS m_1_consensus_fc,
        mf*m_3_ai_fc AS m_3_ai_fc,
        mf*m_3_validated_fc AS m_3_validated_fc,
        mf*m_3_consensus_fc AS m_3_consensus_fc,
        comments_consensus,
        comments_validated,
        'Single' AS bundle_type,
        'VB+Single' AS bundle_explosion,
        file_name,
        source_load_ts,
        time_flag,
        updated_date,
        user_name 
    FROM daily_forecast AS a
    LEFT JOIN bom_explosion AS b
    ON ean_code=bom_header_ean_code
    WHERE b.local_bom_type_description = 'PB'
)
GROUP BY  ean_code, forecast_gen_date,forecast_date,platform_code,platform_name, country_code,division_code,campaign_type,bundle_type , bundle_explosion,
time_flag
 
----------------------------PB+Single---------------------------
 
UNION ALL
 
SELECT  
    ean_code,
    forecast_gen_date,
    forecast_date,
    platform_code,
    platform_name,
    country_code,
    division_code,
    campaign_type,
    bundle_type,
    bundle_explosion,
    SUM(ai_model_forecast),
    SUM(consensus_forecast),  
    SUM(validated_forecast),
    SUM(m_1_ai_fc),
    SUM(m_1_validated_fc),
    SUM(m_1_consensus_fc),
    SUM(m_3_ai_fc),
    SUM(m_3_validated_fc),  
    SUM(m_3_consensus_fc),
    MAX(comments_consensus),
    MAX(comments_validated),
    MAX(file_name),
    MAX(source_load_ts),
    time_flag,
    MAX(updated_date),
    MAX(user_name) 
FROM
(
    SELECT  
        ean_code,
        a.forecast_gen_date,
        forecast_date,
        platform_code,
        platform_name,
        country_code,
        division_code,
        campaign_type,
        ai_model_forecast,
        consensus_forecast,  
        validated_forecast,
        m_1_ai_fc,
        m_1_validated_fc,
        m_1_consensus_fc,
        m_3_ai_fc,
        m_3_validated_fc,  
        m_3_consensus_fc,
        comments_consensus,
        comments_validated,
        COALESCE(b.local_bom_type_description,'Single') AS bundle_type,
        'PB+Single' AS bundle_explosion,
        file_name,
        source_load_ts,
        time_flag,
        updated_date,
        user_name 
    FROM daily_forecast AS a
    LEFT JOIN bom_type AS b
    ON ean_code=bom_header_ean_code
    WHERE b.local_bom_type_description <>'VB'or b.local_bom_type_description is null
 
    UNION ALL
 
    SELECT
        component_ean_code,
        a.forecast_gen_date,
        forecast_date,
        platform_code,
        platform_name,
        country_code,
        division_code,
        campaign_type,
        mf*ai_model_forecast AS ai_model_forecast,
        mf*consensus_forecast AS consensus_forecast,  
        mf*validated_forecast AS validated_forecast,
        mf*m_1_ai_fc AS m_1_ai_fc,
        mf*m_1_validated_fc AS m_1_validated_fc,
        mf*m_1_consensus_fc AS m_1_consensus_fc,
        mf*m_3_ai_fc As m_3_ai_fc,
        mf*m_3_validated_fc AS m_3_validated_fc,
        mf*m_3_consensus_fc AS m_3_consensus_fc,
        comments_consensus,
        comments_validated,
        'Single' AS bundle_type,
        'PB+Single' AS bundle_explosion,
        file_name,
        source_load_ts,
        time_flag,
        updated_date,
        user_name 
    FROM daily_forecast AS a
    LEFT JOIN bom_explosion AS b
    ON ean_code=bom_header_ean_code
    WHERE b.local_bom_type_description = 'VB'
)
GROUP BY  ean_code, forecast_gen_date,forecast_date,platform_code,platform_name, country_code,division_code,campaign_type,bundle_type , bundle_explosion,
time_flag
 
 
----------------------------Single---------------------------
 
UNION ALL
 
SELECT  
    ean_code,
    forecast_gen_date,
    forecast_date,
    platform_code,
    platform_name,
    country_code,
    division_code,
    campaign_type,
    bundle_type,
    bundle_explosion,
    SUM(ai_model_forecast),
    SUM(consensus_forecast),  
    SUM(validated_forecast),
    SUM(m_1_ai_fc),
    SUM(m_1_validated_fc),
    SUM(m_1_consensus_fc),
    SUM(m_3_ai_fc),
    SUM(m_3_validated_fc),  
    SUM(m_3_consensus_fc),
    MAX(comments_consensus),
    MAX(comments_validated),
    MAX(file_name),
    MAX(source_load_ts),
    time_flag,
    MAX(updated_date),
    MAX(user_name)
FROM
(
    SELECT  
        ean_code,
        a.forecast_gen_date,
        forecast_date,
        platform_code,
        platform_name,
        country_code,
        division_code,
        campaign_type,
        ai_model_forecast,
        consensus_forecast,  
        validated_forecast,
        m_1_ai_fc,
        m_1_validated_fc,
        m_1_consensus_fc,
        m_3_ai_fc,
        m_3_validated_fc,  
        m_3_consensus_fc,
        (comments_consensus),
        (comments_validated),
        COALESCE(b.local_bom_type_description,'Single') AS bundle_type,
        'Single' AS bundle_explosion,
        file_name,
        source_load_ts,
        time_flag,
        updated_date,
        user_name   
    FROM daily_forecast AS a
    LEFT JOIN bom_type AS b
    ON ean_code=bom_header_ean_code
    WHERE b.local_bom_type_description NOT IN ('VB','PB') or b.local_bom_type_description is null
 
    UNION ALL
 
    SELECT
        component_ean_code,
        a.forecast_gen_date,
        forecast_date,
        platform_code,
        platform_name,
        country_code,
        division_code,
        campaign_type,
        mf*ai_model_forecast AS ai_model_forecast,
        mf*consensus_forecast AS consensus_forecast,  
        mf*validated_forecast As validated_forecast,
        mf*m_1_ai_fc AS m_1_ai_fc,
        mf*m_1_validated_fc AS m_1_validated_fc,
        mf*m_1_consensus_fc AS m_1_consensus_fc,
        mf*m_3_ai_fc AS m_3_ai_fc,
        mf*m_3_validated_fc AS m_3_validated_fc,
        mf*m_3_consensus_fc AS m_3_consensus_fc,
        comments_consensus,
        comments_validated,
        'Single' AS bundle_type,
        'Single' AS bundle_explosion,
        file_name,
        source_load_ts,
        time_flag,
        updated_date,
        user_name   
    FROM daily_forecast AS a
    LEFT JOIN bom_explosion AS b
    ON ean_code=bom_header_ean_code
    WHERE b.local_bom_type_description IN ('VB','PB') 
)
GROUP BY  ean_code,forecast_gen_date,forecast_date,platform_code,platform_name, country_code,division_code,campaign_type,bundle_type , bundle_explosion,
time_flag
 
),
 
final AS (
    SELECT
        dp.forecast_sk,
        sd.*,
        ud.unecorn_lifecycle AS lifecycle,
        CASE 
            WHEN ud.unecorn_lifecycle IN ('Ongoing (modelled)','To be Discont. (modelled)','New Launch (<3M sales)','Do not show in tool','Active & Not Modelled') AND promo_discount_percentage IS NULL THEN COALESCE(nmv_avg,rs.final_rsp,0)
            WHEN ud.unecorn_lifecycle IN ('Ongoing (modelled)','To be Discont. (modelled)','New Launch (<3M sales)','Do not show in tool','Active & Not Modelled') AND promo_discount_percentage IS NOT NULL THEN promo_discount_price*rs.final_rsp
            WHEN ud.unecorn_lifecycle IN ('Future Launch') AND promo_franchise_discount_price IS NULL THEN COALESCE(rs.final_rsp,0)
            WHEN ud.unecorn_lifecycle IN ('Future Launch') AND promo_franchise_discount_price IS NOT NULL  THEN promo_franchise_discount_price*rs.final_rsp
            WHEN ud.unecorn_lifecycle IN ('Discont.') AND promo_discount_percentage IS NULL THEN COALESCE(rs.final_rsp,0)
            WHEN ud.unecorn_lifecycle IN ('Discont.') AND promo_discount_percentage IS NOT NULL THEN promo_discount_price*rs.final_rsp
        END AS expected_sales_price,
        --ean_price.final_nmv AS expected_sales_price,
        rs.final_rsp AS retail_sales_price,
        bet.bundle_sk,
        dp.signature_code,
        dp.signature_name,
        dp.ean_description
    FROM all_forecasts AS sd 
    JOIN 
    (
        SELECT 
            product_sk AS forecast_sk,
            ean_code,
            platform_name,
            country_code,
            division_code,
            signature_code,
            signature_name,
            ean_description
        FROM {{ref('dim_product')}}
    ) AS dp
    ON sd.ean_code=dp.ean_code
    AND UPPER(sd.platform_name) = UPPER(dp.platform_name)
    AND sd.country_code = dp.country_code
    AND sd.division_code = dp.division_code
    LEFT JOIN unecorn_details AS ud 
    ON sd.ean_code = ud.ean_code AND sd.platform_name = ud.marketplace_name
    AND sd.forecast_gen_date = ud.forecast_gen_date
    LEFT JOIN
    (
        SELECT DISTINCT
            ean_code,
            platform_code,
            promo_discount_percentage,
            promo_discount_price,
            promo_franchise_discount_price,
            nmv_avg,
            gmv_avg,
            final_nmv,
            final_gmv,
            campaign_type,
            lifecycle_status
        FROM {{ref('dim_ean_valorisation')}} 
    ) AS ean_price
    ON sd.ean_code = ean_price.ean_code
    AND sd.platform_code = ean_price.platform_code
    AND sd.campaign_type = ean_price.campaign_type
    LEFT JOIN
    (
        SELECT 
            bundle_sk,
            bundle_type,
            bundle_explosion
        FROM {{ref('bundle_explosion_type')}}
    ) AS bet
    ON sd.bundle_type = bet.bundle_type
    AND sd.bundle_explosion = bet.bundle_explosion
    LEFT JOIN {{ref('dim_rsp_valorization')}} AS rs
    ON sd.ean_code = rs.ean_code
    AND sd.platform_code = rs.platform_code
    AND DATE_TRUNC(sd.forecast_date, MONTH) = month_date
)

SELECT
    forecast_sk,
    ean_code,
    ean_description,
    forecast_gen_date,
    forecast_date,
    final.platform_code,
    final.platform_name,
    final.signature_code,
    final.signature_name,
    final.country_code,
    final.division_code,
    final.campaign_type,
    final.bundle_type,
    bundle_explosion,
    ai_model_forecast,
    consensus_forecast,  
    validated_forecast,
    m_1_ai_fc,
    m_1_validated_fc,
    m_1_consensus_fc,
    m_3_ai_fc,
    m_3_validated_fc,  
    m_3_consensus_fc,
    comments_consensus,
    comments_validated,
    lifecycle,
    expected_sales_price,
    retail_sales_price,
    bundle_sk,    
    time_flag,    
    dc.campaign_sk,
    dim_date.date_key AS date_sk,
    expected_sales_price * ai_model_forecast AS nmv_ai_model_forecast_value,
    expected_sales_price * validated_forecast AS nmv_validated_forecast_value,
    expected_sales_price * consensus_forecast AS nmv_consensus_forecast_value,
    retail_sales_price * ai_model_forecast AS retail_ai_model_forecast_value,
    retail_sales_price * validated_forecast AS retail_validated_forecast_value,
    retail_sales_price * consensus_forecast AS retail_consensus_forecast_value,
    expected_sales_price * m_1_ai_fc AS nmv_ai_model_forecast_value_m_1,
    expected_sales_price * m_1_validated_fc AS nmv_validated_forecast_value_m_1,
    expected_sales_price * m_1_consensus_fc AS nmv_consensus_forecast_value_m_1,
    retail_sales_price * m_1_ai_fc AS retail_ai_model_forecast_value_m_1,
    retail_sales_price * m_1_validated_fc AS retail_validated_forecast_value_m_1,
    retail_sales_price * m_1_consensus_fc AS retail_consensus_forecast_value_m_1,      
   CASE 
     WHEN forecast_gen_date = (SELECT MAX(forecast_gen_date) FROM {{ref('fact_daily_forecast')}} ) THEN 1
            ELSE 0 
    END AS active_month_flag,
    1 AS active_version_flag,
    final.file_name,
    source_load_ts,
    final.updated_date,
    user_name,
    CURRENT_TIMESTAMP() AS load_ts
FROM final
LEFT JOIN {{ref('dim_campaign')}} AS dc
ON forecast_date=CAST(`date` AS DATE)
AND final.platform_code=dc.platform_code
AND final.signature_code = dc.signature_code
LEFT JOIN {{ref('dim_date')}} AS dim_date 
ON final.forecast_date = dim_date.date