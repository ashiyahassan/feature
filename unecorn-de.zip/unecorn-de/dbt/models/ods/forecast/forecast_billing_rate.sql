{{ config(materialized='table') }}

WITH source_data AS (
    SELECT * 
    FROM 
    (
        SELECT DISTINCT 
            country,
            division,
            marketplace_code,
            day_to_invoice,
            ROUND(AVG(percentage_dist),2) AS avg_dist,
            'D' conversion_type
        FROM 
        (
            SELECT DISTINCT 
                country,
                division,
                marketplace_code,
                sellout_year,
                sellout_month,
                day_to_invoice,
                SUM(invoice_qty) OVER (PARTITION BY country,division,marketplace_code,sellout_year,sellout_month,day_to_invoice) AS day_wise_sum,
                SUM(invoice_qty) OVER (PARTITION BY country,division,marketplace_code,sellout_year,sellout_month) AS total_sum,
                (SUM(invoice_qty) OVER (PARTITION BY country,division,marketplace_code,sellout_year,sellout_month,day_to_invoice)/SUM(invoice_qty) OVER (PARTITION BY country,division,marketplace_code,sellout_year,sellout_month )) AS percentage_dist
            FROM 
            (
                SELECT DISTINCT 
                    country,
                    division,
                    marketplace_code,
                    sellout_year,
                    sellout_month,
                    ean_code,
                    sellout_date,
                    SUM(bundle_quantity) OVER (PARTITION BY country, division, marketplace_code, ean_code, sellout_date) AS delivered_units,
                    invoice_date,
                    SUM(bundle_quantity) OVER (PARTITION BY country, division, marketplace_code, ean_code, sellout_date, invoice_date) AS invoice_qty,
                    CASE 
                        WHEN DATE_DIFF(invoice_date,sellout_date,DAY) > 10 THEN 10 
                        ELSE DATE_DIFF(invoice_date,sellout_date,DAY) 
                    END AS day_to_invoice
                FROM {{ref('sellout_d2c_v3')}}
                WHERE order_status IN ('COMPLETED', 'DELIVERED')
                AND invoice_date IS NOT NULL 
                AND sellout_date >=DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 5 MONTH) 
                AND sellout_date < DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 1 MONTH)
            )
        )
        GROUP BY 1,2,3,4
        UNION ALL
        SELECT DISTINCT 
            country,
            division,
            marketplace_code,
            month_difference,
            AVG(percentage_dist) AS avg_dist,
            'M' conversion_type
        FROM 
        (
            SELECT  DISTINCT 
                country,
                division,
                marketplace_code,
                sellout_year,
                sellout_month,
                month_difference,
                SUM(invoice_qty) OVER (PARTITION BY country,division,marketplace_code,sellout_year,sellout_month,month_difference) AS month_wise_sum,
                SUM(invoice_qty) OVER (PARTITION BY country,division,marketplace_code,sellout_year,sellout_month) AS total_sum,
                (SUM(invoice_qty) OVER (PARTITION BY country,division,marketplace_code,sellout_year,sellout_month,month_difference)/SUM(invoice_qty) OVER (PARTITION BY country,division,marketplace_code,sellout_year,sellout_month)) AS percentage_dist
            FROM 
            (
                SELECT DISTINCT 
                    country,
                    division,
                    marketplace_code,
                    sellout_year,
                    sellout_month,
                    SUM(bundle_quantity) OVER (PARTITION BY country, division, marketplace_code,sellout_year,sellout_month) AS delivered_units,
                    SUM(bundle_quantity) OVER (PARTITION BY country, division, marketplace_code,sellout_year,sellout_month, EXTRACT(YEAR FROM invoice_date), EXTRACT(MONTH FROM invoice_date)) AS invoice_qty,
                    CASE 
                        WHEN DATE_DIFF(invoice_date,sellout_date,MONTH) > 1 THEN 1 
                        ELSE DATE_DIFF(invoice_date,sellout_date,MONTH) 
                    END AS month_difference
                FROM {{ref('sellout_d2c_v3')}}
                WHERE order_status IN ('COMPLETED', 'DELIVERED')
                AND invoice_date IS NOT NULL 
                AND sellout_date >= DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 5 MONTH) 
                AND sellout_date < DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 1 MONTH)
            )
        )
        GROUP BY 1,2,3,4
    )
    ORDER BY 3,6,4,6
)

SELECT *, CURRENT_TIMESTAMP() AS load_ts FROM source_data
UNION ALL
SELECT 
    country, 
    division, 
    {{variable_macro('tiktok_vn_var')}} AS marketplace_code, 
    day_to_invoice, 
    avg_dist, 
    conversion_type, 
    CURRENT_TIMESTAMP() AS load_ts
FROM (
    SELECT * FROM source_data 
    WHERE conversion_type = 'M' AND marketplace_code = {{variable_macro('lazada_vn_var')}} AND country = {{variable_macro('country_var')}}
)
WHERE NOT EXISTS (
    SELECT 1 FROM source_data
    WHERE conversion_type = 'M' AND marketplace_code = {{variable_macro('tiktok_vn_var')}} AND country = {{variable_macro('country_var')}}
)