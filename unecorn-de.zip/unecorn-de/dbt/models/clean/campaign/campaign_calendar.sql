{{ config(materialized='table') }}

WITH source_data AS (
    SELECT *
    FROM {{ ref('stg_campaign') }} 
)

SELECT * FROM source_data