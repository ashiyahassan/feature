import functions_framework
import io
import json
import pandas as pd
from google.cloud import storage, bigquery
from config import *
from datetime import datetime

bigquery_client = bigquery.Client()
storage_client = storage.Client()


# Triggered by a change in a storage bucket
@functions_framework.cloud_event
def http_hello(cloud_event):
    data = cloud_event.data

    event_id = cloud_event["id"]
    event_type = cloud_event["type"]

    bucket = data["bucket"]
    name = data["name"]
    metageneration = data["metageneration"]
    timeCreated = data["timeCreated"]
    updated = data["updated"]

    print(f"Event ID: {event_id}")
    print(f"Event type: {event_type}")
    print(f"Bucket: {bucket}")
    print(f"File: {name}")
    print(f"Metageneration: {metageneration}")
    print(f"Created: {timeCreated}")
    print(f"Updated: {updated}")
    try:
        process_excel_file(bucket, name)
    except Exception as e:
        print(e)

def process_excel_file(bucket_name, file_path):
    # Extracting file details from the event
    file_name = file_path.split("/")[-1]

    table_id = f'{project_id}.{dataset_id}.{file_name.split(".")[0]}_file_data'
    print(f"Manual files Ingestion :{file_name} : file_path - ", file_path)
    print(f"Manual files Ingestion :{file_name} : bucket_name - ", bucket_name)
    print(f"Manual files Ingestion :{file_name} : table_id - ", table_id)

    with open(schema_file_path, 'r') as file:
        schema = json.load(file)
    print(schema)
    df = read_csv(schema=schema, bucket_name=bucket_name, file_path=file_path)
    print(df)
    if df is not "200":
        if not validate_folder(file_name, file_path):
            move_to_archive(error_bucket, file_path, "error", file_name)
            # audit(file_name, 'error', table_id)
            raise ValueError(f"Manual files Ingestion :{file_name} :",
                             "Invalid Folder. Please retry and place file in the correct location.")
        print(f"Manual files Ingestion :{file_name} :", "Folder Validated")
        if not validate_file(schema, file_name):
            move_to_archive(error_bucket, file_path, "error", file_name)
            # audit(file_name, 'error', table_id)
            raise ValueError(f"Manual files Ingestion :{file_name} :",
                             "Invalid File type or file name. Please retry with correct file.")
        print(f"Manual files Ingestion :{file_name} :", "File Type and Name Validated")

        if not validate_schema(df, schema, file_name):
            move_to_archive(error_bucket, file_path, "error", file_name)
            # audit(file_name, 'error', table_id)
            raise ValueError(f"Manual files Ingestion :{file_name} :", "Invalid schema. Missing expected columns.")
        print(f"Manual files Ingestion :{file_name} :", "File Schema Validated")

        df = validate_data_types(df, schema, file_name)
        print(f"Manual files Ingestion :{file_name} :", "File Data_type updated")

        df = add_meta_columns(df, file_name)

        # Upload DataFrame to BigQuery
        try:
            insert_job(df, table_id, file_name, schema)
            print(f"Manual files Ingestion :{file_name} : ", "Manual File to BQ")
            audit(file_name, 'success', table_id)
            move_to_archive(archive_bucket, file_path, archive_folder, file_name)
            print(f"Manual files Ingestion :{file_name} : ", "Manual File moved to Archive")
        except Exception as e:

            audit(file_name, 'failed', table_id)
            move_to_archive(error_bucket, file_path, 'error', file_name)
            raise ValueError(f"Manual files Ingestion :{file_name} : ", "Invalid schema. Missing expected columns.", e)
    else:
        print(f"Manual files Ingestion :{file_name} : ", "Manual File to BQ")
        audit(file_name, 'success', table_id)
        move_to_archive(archive_bucket, file_path, archive_folder, file_name)
        print(f"Manual files Ingestion :{file_name} : ", "Manual File moved to Archive")

def master_data_file(schema, file_path, file_data_bytes):
    # data = pd.read_excel(file_data_bytes, sheet_name="masterdata", usecols="B:BQ", nrows=2959, skiprows=5)
    data = pd.read_excel(file_data_bytes, sheet_name="masterdata")
    data["country_code"] = None
    for ind in schema:
        if ind in data.columns:
            pass
        else:
            print("SCHEMA ERROR : MASTER DATA FILES")
            return None

    return data[schema]


def read_csv(schema, bucket_name, file_path):
    file = file_path.split("/")[-1].split(".")[0]
    bucket = storage_client.get_bucket(bucket_name)
    blob = bucket.get_blob(file_path)
    file_data_bytes = io.BytesIO(blob.download_as_string())
    print("READ CSV")
    if file_path.split(".")[1] == "xlsx":

        file_data_bytes = blob.download_as_bytes()
        # df = master_data_file(schema[file], file_path, file_data_bytes)
        print("Started Excell")
        try :
            df =  get_excel(bucket_name, file_path)["status"] == "200"
        except Exception as e:
            print(e)
        print("Read ExcelENDl")
    else:
        df = pd.read_csv(file_data_bytes)

    return df


def validate_folder(file_name, filepath):
    try:
        if filepath.split("/")[0] == 'raw':
            return True
        else:
            return False
    except Exception as e:
        raise ValueError(f"Manual files Ingestion :{file_name} :", "Invalid folder name please place file")


def validate_file(schema, file_name):
    try:
        if file_name.split(".")[1] == 'csv' or file_name.split(".")[1] == 'xlsx':
            print("FILE NAME : ",file_name)
            if file_name.split(".")[0] in schema:
                return True
            else:
                return False
        else:
            return False
    except Exception as e:
        raise ValueError(f"Manual files Ingestion :{file_name} :",
                         "Invalid file name or No such file added to Configuration")


def validate_schema(df, schema, file_name):
    try:
        expected_columns = schema[file_name.split(".")[0]]
        if not set(expected_columns).issubset(df.columns):
            return False
        return True
    except Exception as e:
        raise ValueError(f"Manual files Ingestion :{file_name} :",
                         "Invalid Schema name or No such columns added in the file")

def validate_schema_master_data(df, schema):
    df['sub_category'] = df['sub-category']
    df['sub_group'] = df['sub-group']
    df = df[schema]
    print("SCHEMA VALIDATED")
    return to_string(df, schema)


def to_string(df, schema):
    for i in schema:
        print(i)
        df[i] = df[i].astype(str)

        # if df[i].dtype == 'float':
        #     df[i] = df[i].astype(str)
        # elif df[i].dtype == 'object':
        #     df[i] = df[i].astype(str)
        # elif df[i].dtype == 'int':
        #     df[i] = df[i].astype(str)
    df['modified_date'] = df['modified_date'].astype(object)
    print("schema conversion done")
    
    return df

def validate_data_types(df, schema, file_name):
    try:
        print(schema)
        df = to_string(df, schema[file_name.split(".")[0]])
        return df
    except Exception as e:
        raise ValueError(f"Manual files Ingestion :{file_name} :",
                         "Invalid Data Type")

    # for col, expected_type in expected_data_types.items():
    #     if df[col].dtype != expected_type:
    #         raise ValueError(f"Invalid data type for column {col}. Expected {expected_type}.")


def validate_timestamp_columns(df, file_name):
    timestamp_columns = ['timestamp_column1', 'timestamp_column2']
    for col in timestamp_columns:
        try:
            pd.to_datetime(df[col], errors='raise')
        except ValueError:
            raise ValueError(f"Manual files Ingestion :{file_name} : ", f"Invalid timestamp values in column {col}.")


def move_to_archive(bucket_name, file_path, destination_folder, file_name):
    source_blob_path = f"{file_path}"
    destination_blob_path = f"{destination_folder + file_path}/{file_name}"
    print(destination_blob_path)
    # source_bucket = storage_client.bucket(bucket_name)
    # source_blob = source_bucket.blob(source_blob_path)

    # Copy the blob to the destination
    # destination_bucket = storage_client.bucket(bucket_name)
    # destination_blob = destination_bucket.blob(destination_blob_path)
    # destination_blob.upload_from_string(source_blob.download_as_text())

    # Delete the original blob
    # source_blob.delete()
    print(f"Manual files Ingestion :{file_name} : ", f"File {file_name} moved from {file_path} to {destination_folder}")

def add_meta_columns(df, file_name):
    df['insert_time'] = datetime.utcnow()
    df['update_time'] = datetime.utcnow()  # Set to None initially
    df['file_path'] = file_name
    return df


def insert_job(df, table_id, file_name, schema):
    print("ENTERD INSERT")

    # Upload the DataFrame to BigQuery
    # print(df)
    # print(df['sub_category'])
    print(table_id)
    print(file_name)
    schema = schema[file_name.split('.')[0]]

    try:
        schema_val = []
        print(schema)
        for sch in schema:
            schema_val.append(bigquery.SchemaField(sch, "STRING"))
        print(schema_val)
        job_config = bigquery.LoadJobConfig(
            write_disposition="WRITE_TRUNCATE",
            schema=schema_val  # Define schema fields
        )
        print("JOB load table created")
        job = bigquery_client.load_table_from_dataframe(df, table_id, job_config=job_config)
        job.result()
        print("TABLE INSERTED")

        # df.to_gbq(table_id, **gbq_config)
    except Exception as e :
        raise ValueError(e)
    print(f"Manual files Ingestion :{file_name} : ", f"File {file_name} loaded into BigQuery table {table_id}")


def audit(file_name, status, table_id):
    # Prepare the audit data
    audit_data = [
        {
            'batch_id': get_batch_id() + 1,
            'table_name': file_name,
            'column': table_id,
            'inc_start_date':None ,
            'inc_end_date': None,
            'status':status,
            'load_type':'I'
        }
    ]

    # Insert the audit data into the audit table
    table_ref = bigquery_client.dataset(audit_dataset_id).table(audit_table_id)
    table = bigquery_client.get_table(table_ref)
    errors = bigquery_client.insert_rows(table, audit_data)
    audit_batch(file_name, status, table_id)
    if errors:
        print(f"Manual files Ingestion :{file_name} : ", f"Error inserting audit data: {errors}")
    else:
        print(f"Manual files Ingestion :{file_name} : ", f"Audit data inserted successfully.")


def audit_batch(file_name, status, table_id):
    # Prepare the batch data
    batch_data = [
        {
            'batch_id': get_batch_id() + 1,
            'batch_name': 'ucn_manual_ingestion',
            'batch_type': 'I',
            'state': status,
            'start_time': datetime.now(),
            'end_time': datetime.now(),
            'frequency' : 'Daily',
            'phase': 'ingestion'
        }
    ]

    # Insert the audit data into the audit table
    table_ref = bigquery_client.dataset(audit_dataset_id).table(batch_table_id)
    table = bigquery_client.get_table(table_ref)
    errors = bigquery_client.insert_rows(table, batch_data)
    if errors:
        print(f"Manual files Ingestion :{file_name} : ", f"Error inserting Batch data: {errors}")
    else:
        print(f"Manual files Ingestion :{file_name} : ", f"Batch data inserted successfully.")



def get_batch_id():
    query = f"""
        SELECT MAX(batch_id) as last_batch_id
        FROM `{audit_dataset_id}.{batch_table_id}`
    """
    query_job = bigquery_client.query(query)
    result = query_job.result()

    # Extract the last batch ID
    last_batch_id = None
    for row in result:
        if row.last_batch_id is None:
            last_batch_id = 0
        else:
            last_batch_id = row.last_batch_id
    return int(last_batch_id)
















def get_excel(bucket_name, file_path):
    """
    get_excel function orchestrates :
        -read files
        -add columns
        -file validations
        -insert staging table
        -upsert logic for comparisons
        -file archival
        -feature table deletion

    :param bucket_name: bucket_name from event
    :param file_path: file_path from event
    :return: Status
    """
    # Declare variables
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(file_path)
    data_bytes = io.BytesIO(blob.download_as_string())
    file_name = file_path.split("/")[-1]
    stage_table_id = f'{project_id}.{dataset_id}.stage_{file_name.split(".")[0]}_file_data'
    # schema = ["ean", "material_des", "shp_status", "shp_launch_month", "shp_dc_month", "lzd_status", "lzd_launch_month",
    #           "lzd_dc_month", "category", "sub_category", "group", "sub_group"]
    schema = ["ean","signature","brand","Sub Brand","category","sub_category","group","sub_group","hero","bundle","material_type","material_des","Old EAN","lzd_status","lzd_launch_month","lzd_dc_month","shp_status","shp_launch_month","shp_dc_month", "unecorn_shp_status","unecorn_lzd_status"]
    # Step 1 : Read Master_data_file
    # df = pd.read_excel(data_bytes, sheet_name="masterdata", usecols="B:BQ", skiprows=5)
    df = pd.read_excel(data_bytes, sheet_name="masterdata")

    # Step 2 : Add columns
    df = add_columns(df, schema)

    # Step 3 : Add Validations
    df = validate_schema_master_data(df, schema)
    print("ENETRING INSERT")
    # Step 4 : insert table
    insert_job(df, stage_table_id, file_name,schema)
    print("INSERT DONE")
    # Step 5 : Update Logic
    update_hash(stage_table_id, file_name, schema)
    print("UPDATE HASH DONE DONE")
    # Step 6 : Upsert Logic
    upsert_logic(stage_table_id, stage_table_id.replace('stage_', ''), schema)

    # Step 7 : Delete Feature table
    # delete_feature_table(stage_table_id)
    return {"status": "200"}






def get_wid():
    try:
        query = f"""
                SELECT MAX(wid) as wid
                FROM `practicebigdataanalytics.loreal_raw_zone.master_data_forecast`
            """
        query_job = bigquery.Client().query(query)
        result = query_job.result()

        # Extract the last batch ID
        wid = None
        for row in result:
            if row.wid is None:
                wid = 0
            else:
                wid = row.wid
        return int(wid) + 1
    except:
        return 1


def add_columns(df, schema):
    schema.append('wid')
    schema.append('country_code')
    schema.append('created_date')
    schema.append('modified_date')
    schema.append('active_status')
    # schema.append('hash_map')

    df['wid'] = get_wid()
    df['country_code'] = 'VN'
    df['created_date'] = datetime.now()
    df['modified_date'] = datetime.now()
    df['active_status'] = 'Y'
    # df['hash_map'] = 0

    print("COLUMNS ADDED")
    return df


def update_hash(table_id, file_name, schema):
    schema = ",".join(schema)
    print(schema)
    query = f"""
ALTER TABLE {table_id} 
ADD COLUMN hash_map INT64;

update {table_id} 
set hash_map = FARM_FINGERPRINT(TO_JSON_STRING(STRUCT({schema.replace(',group,', ',`group`,').replace(',sub_group,', ',`sub_group`,').replace(',sub_category,', ',`sub_category`,').replace('Sub Brand','`Sub Brand`').replace('Old EAN','`Old EAN`')}))) 
Where 1=1;
        """
    print(query)
    query_job = bigquery_client.query(query)
    result = query_job.result()

    print(f"Master Data files Ingestion :{file_name} : ", f"File {file_name} loaded into BigQuery table {table_id}")


def upsert_logic(stage_table, master_table, schema):
    schema = ",".join(schema)
    schema = schema.replace(',group,', ',`group`,').replace(',sub_group,', ',`sub_group`,').replace(',sub_category,',
                                                                                                 ',`sub_category`,').replace('Sub Brand','`Sub Brand`').replace('Old EAN','`Old EAN`')
    # schematext = schema.split(',')
    query = f"""
    MERGE INTO `{master_table}` AS target
USING (
   SELECT 
       `{stage_table}`.ean AS join_key,
       `{stage_table}`.*
   FROM `{stage_table}`
   UNION ALL
   SELECT
       NULL AS join_key,
       `{stage_table}`.*
   FROM `{stage_table}`
   JOIN `{master_table}`
       ON `{stage_table}`.ean = `{master_table}`.ean
   WHERE `{stage_table}`.hash_map <> `{master_table}`.hash_map
) AS source
ON source.join_key = target.ean

WHEN MATCHED AND
   source.hash_map <> target.hash_map AND target.active_status = 'Y'
THEN
   UPDATE SET
       active_status = 'N',
       modified_date = CURRENT_TIMESTAMP()

WHEN NOT MATCHED THEN
   INSERT ({schema},hash_map)
   VALUES (
       source.ean, source.signature,source.brand, source.`sub brand`, source.hero, source.bundle, source.material_type, source.`Old EAN`, source.material_des,source.lzd_status, source.lzd_launch_month, source.lzd_dc_month, source.shp_status, source.shp_launch_month, source.shp_dc_month , source.unecorn_shp_status, source.unecorn_lzd_status, source.category, source.`sub_category`, source.group, source.`sub_group`, 1, source.country_code, CURRENT_TIMESTAMP(), NULL, 'Y',  source.hash_map)

WHEN NOT MATCHED BY SOURCE THEN
   UPDATE SET
       active_status = 'N',
       modified_date = CURRENT_TIMESTAMP()
    """
    query_job = bigquery_client.query(query)
    print(query)
    result = query_job.result()
    print(result)


def delete_feature_table(table_id):
    bigquery_client.delete_table(table_id, not_found_ok=True)
    print("Table {} deleted.".format(table_id))


