project_id = "spmena-unecorn-zn-apac-dv"
dataset_id = "cds_unecorn_process_zn"
temp_dataset_id = "cds_unecorn_raw_zn"
daily_forecast_table = "fact_daily_forecast"
monthly_forecast_table = "fact_monthly_forecast"

rollback_query_daily = f"""
UPDATE {project_id}.{dataset_id}.{daily_forecast_table} AS target_table
SET
consensus_forecast = main.consensus_forecast,
validated_forecast = main.validated_forecast,
comments_consensus = main.comments_consensus,
comments_validated = main.comments_validated 
-- - add campiagn column and use timestamp
FROM (
  SELECT forecast_gen_date, ean_code, platform_code, country_code, division_code,campaign_type, forecast_date, consensus_forecast,validated_forecast,comments_consensus,comments_validated, load_ts
  FROM {project_id}.{dataset_id}.{daily_forecast_table}
  WHERE load_ts = (
    SELECT MAX(load_ts)
    FROM {project_id}.{dataset_id}.{daily_forecast_table}
    WHERE
    forecast_gen_date = (SELECT MAX(forecast_gen_date) FROM {project_id}.{dataset_id}.{daily_forecast_table} ) AND
    load_ts < (
      SELECT MAX(load_ts)
      FROM {project_id}.{dataset_id}.{daily_forecast_table}
    )
  )) as main

WHERE 
target_table.ean_code = main.ean_code
AND target_table.forecast_date = main.forecast_date
AND target_table.forecast_gen_date = main.forecast_gen_date
AND target_table.platform_code = main.platform_code
AND target_table.country_code = main.country_code
AND target_table.division_code = main.division_code
AND target_table.campaign_type = main.campaign_type
AND active_month_flag = 1
AND active_version_flag = 1;
"""

rollback_query_monthly = f"""
UPDATE {project_id}.{dataset_id}.{monthly_forecast_table} AS target_table
SET
consensus_forecast = main.consensus_forecast,
validated_forecast = main.validated_forecast,
comments_consensus = main.comments_consensus,
comments_validated = main.comments_validated 
-- - add campiagn column and use timestamp
FROM (
  SELECT forecast_gen_date, ean_code, platform_code, country_code, division_code,campaign_type, forecast_date, consensus_forecast,validated_forecast,comments_consensus,comments_validated, load_ts
  FROM {project_id}.{dataset_id}.{monthly_forecast_table}
  WHERE load_ts = (
    SELECT MAX(load_ts)
    FROM {project_id}.{dataset_id}.{monthly_forecast_table}
    WHERE
    forecast_gen_date = (SELECT MAX(forecast_gen_date) FROM {project_id}.{dataset_id}.{monthly_forecast_table} ) AND
    load_ts < (
      SELECT MAX(load_ts)
      FROM {project_id}.{dataset_id}.{monthly_forecast_table}
    )
  )) as main

WHERE 
target_table.ean_code = main.ean_code
AND target_table.forecast_date = main.forecast_date
AND target_table.forecast_gen_date = main.forecast_gen_date
AND target_table.platform_code = main.platform_code
AND target_table.country_code = main.country_code
AND target_table.division_code = main.division_code
AND target_table.campaign_type = main.campaign_type
AND active_month_flag = 1
AND active_version_flag = 1;
"""

query_dict = {
    "ForecastAdjustment_VN_CPD_ST_Consensus_D": f"""
    UPDATE
  {project_id}.{dataset_id}.{daily_forecast_table} AS o
SET
  o.consensus_forecast = CAST(t.consensus_forecast as INT64),
  o.validated_forecast =   CAST(t.consensus_forecast as INT64),
  comments_consensus = t.`comments_consensus`

FROM

  (select *, 
  CAST(`ai_model_forecast` as INT64) as a_forecast,
  CAST(`consensus_forecast` as INT64) as c_forecast,
  CAST(`validated_forecast` as INT64) as v_forecast, 
    SAFE_DIVIDE(CAST(`consensus_forecast` as INT64), CAST(`ai_model_forecast` as INT64))  as c_forecast_power,
   SAFE_DIVIDE(CAST(`validated_forecast` as INT64), CAST(`ai_model_forecast` as INT64) )  as v_forecast_power, 

 from (SELECT Distinct *  FROM {project_id}.{temp_dataset_id}.ForecastAdjustment_VN_CPD_ST_Consensus_D )) AS t
WHERE
  o.ean_code = t.ean_code
  AND o.country_code = t.country_code 
  AND o.platform_code = t.platform_code
    AND o.campaign_type = t.campaign_type
  AND o.forecast_gen_date = PARSE_DATE('%Y-%m-%d',t.`forecast_version`) 
  AND o.forecast_date =  PARSE_DATE('%Y-%m-%d', t.`forecast_date`);    """,

    "ForecastAdjustment_VN_CPD_ST_Validated_D": f"""
    UPDATE
  {project_id}.{dataset_id}.{daily_forecast_table} AS o
SET

  o.validated_forecast = CAST(t.validated_forecast as INT64),
    comments_validated = t.`comments_validated`

FROM
 (
  select *, 
  CAST(`ai_model_forecast` as INT64) as a_forecast,
  CAST(`consensus_forecast` as INT64) as c_forecast,
  CAST(`validated_forecast` as INT64) as v_forecast, 
    SAFE_DIVIDE(CAST(`consensus_forecast` as INT64), CAST(`ai_model_forecast` as INT64))  as c_forecast_power,
   SAFE_DIVIDE(CAST(`validated_forecast` as INT64), CAST(`ai_model_forecast` as INT64) )  as v_forecast_power, 

 from {project_id}.{temp_dataset_id}.ForecastAdjustment_VN_CPD_ST_Validated_D ) AS t
WHERE
  o.ean_code = t.ean_code
  AND o.country_code = t.country_code
  AND o.platform_code = t.platform_code
  AND o.campaign_type = t.campaign_type
  AND o.forecast_gen_date = PARSE_DATE('%Y-%m-%d',t.`forecast_version`) 
  AND o.forecast_date =  PARSE_DATE('%Y-%m-%d', t.`forecast_date`);
    """,

    "ForecastAdjustment_VN_CPD_ST_Consensus_W": f"""
--Consensus
UPDATE
   {project_id}.{dataset_id}.{daily_forecast_table} AS o
SET

  o.consensus_forecast = CASE 
  WHEN main_rec.ai_model_forecast is not NULL and main_rec.c_forecast_power is not NULL   THEN CAST(o.ai_model_forecast  * main_rec.c_forecast_power as INT64 )
  ELSE o.consensus_forecast  END,



  o.validated_forecast = CASE 
  WHEN main_rec.ai_model_forecast is not NULL and main_rec.c_forecast_power is not NULL   THEN CAST(o.ai_model_forecast  * main_rec.c_forecast_power as INT64 )
  ELSE o.consensus_forecast  END,
  comments_consensus = main_rec.`comments_consensus`  


FROM
(
  select *,
  CAST(`ai_model_forecast` as INT64)  as a_forecast ,
  CAST(`consensus_forecast` as INT64) as c_forecast,
  CAST(`validated_forecast` as INT64) as v_forecast, 
  SAFE_DIVIDE(CAST(`consensus_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as c_forecast_power,
    SAFE_DIVIDE(CAST(`validated_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as v_forecast_power

  FROM(
  select *

 FROM (SELECT * FROM (SELECT  distinct * FROM {project_id}.{temp_dataset_id}.ForecastAdjustment_VN_CPD_ST_Consensus_W) AS t
 LEFT JOIN
 (SELECT `date`,start_of_week,week_no_of_year,year, week_of_year  FROM spmena-unecorn-zn-apac-dv.cds_unecorn_process_zn.dim_date) AS dkey
  ON `forecast_week` = dkey.week_no_of_year and `date` >= PARSE_DATE('%Y-%m-%d',forecast_version) )) AS tdata
  LEFT JOIN
  (SELECT 
ean_code as e_code, 
country_code as c_code,
platform_code as p_code, 
campaign_type as ct_code,
forecast_gen_date as gen_date, 
EXTRACT(Year FROM forecast_date) as forecast_year, 
EXTRACT( ISOWEEK FROM forecast_date) as forecast_week
FROM   
{project_id}.{dataset_id}.{daily_forecast_table}
GROUP BY 
ean_code, country_code, platform_code, campaign_type, forecast_gen_date, forecast_year, forecast_week) as main
ON 
tdata.ean_code = main.e_code AND
tdata.country_code = main.c_code AND 
tdata.platform_code = main.p_code AND
PARSE_DATE('%Y-%m-%d', tdata.`forecast_version`) = main.gen_date AND
EXTRACT( ISOWEEK FROM tdata.`date`) = main.forecast_week
) main_rec


WHERE
  o.ean_code = main_rec.ean_code
  AND o.country_code = main_rec.country_code
  AND o.platform_code = main_rec.platform_code
  AND o.campaign_type = main_rec.ct_code
  AND o.forecast_gen_date = PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`) 
  AND o.forecast_date =  main_rec.`date` 

  -- -- Condition to check forecast_date is not of the same month as generation date
  AND   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`)) <=   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', CAST(o.forecast_date  as STRING)));
    """,

    "ForecastAdjustment_VN_CPD_ST_Validated_W": f"""
--Validated Weekly
UPDATE
   {project_id}.{dataset_id}.{daily_forecast_table} AS o
SET

  -- CASE TO update validated as well if not null
  o.validated_forecast = CASE 
  WHEN main_rec.ai_model_forecast is not NULL and main_rec.v_forecast_power is not NULL   THEN CAST(o.ai_model_forecast  * main_rec.v_forecast_power as INT64 )
  ELSE o.validated_forecast  END,
  comments_validated = main_rec.`comments_validated`  
FROM
(
  select *,
  CAST(`ai_model_forecast` as INT64)  as a_forecast ,
  CAST(`consensus_forecast` as INT64) as c_forecast,
  CAST(`validated_forecast` as INT64) as v_forecast, 
  SAFE_DIVIDE(CAST(`consensus_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as c_forecast_power,
    SAFE_DIVIDE(CAST(`validated_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as v_forecast_power

  FROM(
  select *

 FROM (SELECT * FROM (SELECT  * FROM {project_id}.{temp_dataset_id}.ForecastAdjustment_VN_CPD_ST_Validated_W) AS t
 LEFT JOIN
 (SELECT `date`,start_of_week,week_no_of_year,year, week_of_year  FROM spmena-unecorn-zn-apac-dv.cds_unecorn_process_zn.dim_date) AS dkey
  ON `forecast_week` = dkey.week_no_of_year and `date` >= PARSE_DATE('%Y-%m-%d',forecast_version) )) AS tdata
  LEFT JOIN
  (SELECT 
ean_code as e_code, 
country_code as c_code,
platform_code as p_code, 
campaign_type as ct_code,
forecast_gen_date as gen_date, 
EXTRACT(Year FROM forecast_date) as forecast_year, 
EXTRACT( ISOWEEK FROM forecast_date) as forecast_week
FROM   
{project_id}.{dataset_id}.{daily_forecast_table}
GROUP BY 
ean_code, country_code, platform_code, campaign_type, forecast_gen_date, forecast_year, forecast_week) as main
ON 
tdata.ean_code = main.e_code AND
tdata.country_code = main.c_code AND 
tdata.platform_code = main.p_code AND
PARSE_DATE('%Y-%m-%d', tdata.`forecast_version`) = main.gen_date AND
EXTRACT( ISOWEEK FROM tdata.`date`) = main.forecast_week
) main_rec


WHERE
  o.ean_code = main_rec.ean_code
  AND o.country_code = main_rec.country_code
  AND o.platform_code = main_rec.platform_code
 AND o.campaign_type = main_rec.ct_code
  AND o.forecast_gen_date = PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`) 
  AND o.forecast_date =  main_rec.`date` 

  -- -- Condition to check forecast_date is not of the same month as generation date
  AND   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`)) <=   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', CAST(o.forecast_date  as STRING)));
    """,

    "ForecastAdjustment_VN_CPD_ST_Consensus_M": f""" 
--Consensus
UPDATE
  {project_id}.{dataset_id}.{daily_forecast_table} AS o
SET

  o.consensus_forecast = CASE 
  WHEN main_rec.ai_model_forecast is not NULL and main_rec.c_forecast_power is not NULL   THEN CAST(o.ai_model_forecast  * main_rec.c_forecast_power as INT64 )
  ELSE o.consensus_forecast  END,



  o.validated_forecast = CASE 
  WHEN main_rec.ai_model_forecast is not NULL and main_rec.c_forecast_power is not NULL   THEN CAST(o.ai_model_forecast  * main_rec.c_forecast_power as INT64 )
  ELSE o.consensus_forecast  END,
  comments_consensus = main_rec.`comments_consensus`  

FROM
(
  select *,
  CAST(`ai_model_forecast` as INT64)  as a_forecast ,
  CAST(`consensus_forecast` as INT64) as c_forecast,
  CAST(`validated_forecast` as INT64) as v_forecast, 
  SAFE_DIVIDE(CAST(`consensus_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as c_forecast_power,
    SAFE_DIVIDE(CAST(`validated_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as v_forecast_power

  FROM(
  select *

 FROM (SELECT * FROM (SELECT  distinct * FROM   {project_id}.{temp_dataset_id}.ForecastAdjustment_VN_CPD_ST_Consensus_M) AS t
 LEFT JOIN
 (SELECT `date`,start_of_month, year_month FROM spmena-unecorn-zn-apac-dv.cds_unecorn_process_zn.dim_date) AS dkey
  ON CONCAT(SUBSTR(forecast_month, 1, 3), ' 20', SUBSTR(forecast_month, LENGTH(forecast_month)-1,LENGTH(forecast_month)-2)) = dkey.year_month and `date` >= PARSE_DATE('%Y-%m-%d',forecast_version) )) AS tdata
  LEFT JOIN
  (SELECT 
ean_code as e_code, 
country_code as c_code,
platform_code as p_code, 
campaign_type as ct_code,
forecast_gen_date as gen_date, 
EXTRACT(Year FROM forecast_date) as forecast_year, 
EXTRACT( MONTH FROM forecast_date) as forecast_month
FROM   
  {project_id}.{dataset_id}.{daily_forecast_table}
GROUP BY 
ean_code, country_code, platform_code, campaign_type, forecast_gen_date, forecast_year, forecast_month) as main
ON 
tdata.ean_code = main.e_code AND
tdata.country_code = main.c_code AND 
tdata.platform_code = main.p_code AND
PARSE_DATE('%Y-%m-%d', tdata.`forecast_version`) = main.gen_date AND
EXTRACT( MONTH FROM tdata.`date`) = main.forecast_month) main_rec


WHERE
  o.ean_code = main_rec.ean_code
  AND o.country_code = main_rec.country_code
  AND o.platform_code = main_rec.platform_code
    AND o.campaign_type = main_rec.ct_code
  AND o.forecast_gen_date = PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`) 
  AND o.forecast_date =  main_rec.`date` 

  -- -- Condition to check forecast_date is not of the same month as generation date
  AND   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`)) <=   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', CAST(o.forecast_date  as STRING)));
    """,

    "ForecastAdjustment_VN_CPD_ST_Validated_M": f""" 
--Consensus
UPDATE
  {project_id}.{dataset_id}.{daily_forecast_table} AS o
SET

  o.validated_forecast = CASE 
  WHEN main_rec.ai_model_forecast is not NULL and main_rec.v_forecast_power is not NULL   THEN CAST(o.ai_model_forecast  * main_rec.v_forecast_power as INT64 )
  ELSE o.ai_model_forecast  END,
  comments_validated = main_rec.`comments_validated`


FROM
(
  select *,
  CAST(`ai_model_forecast` as INT64)  as a_forecast ,
  CAST(`consensus_forecast` as INT64) as c_forecast,
  CAST(`validated_forecast` as INT64) as v_forecast, 
  SAFE_DIVIDE(CAST(`consensus_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as c_forecast_power,
    SAFE_DIVIDE(CAST(`validated_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as v_forecast_power

  FROM(
  select *

 FROM (SELECT * FROM (SELECT  distinct * FROM   {project_id}.{temp_dataset_id}.ForecastAdjustment_VN_CPD_ST_Validated_M) AS t
 LEFT JOIN
 (SELECT `date`,start_of_month, year_month FROM spmena-unecorn-zn-apac-dv.cds_unecorn_process_zn.dim_date) AS dkey
  ON CONCAT(SUBSTR(forecast_month, 1, 3), ' 20', SUBSTR(forecast_month, LENGTH(forecast_month)-1,LENGTH(forecast_month)-2)) = dkey.year_month and `date` >= PARSE_DATE('%Y-%m-%d',forecast_version) )) AS tdata
  LEFT JOIN
  (SELECT 
ean_code as e_code, 
country_code as c_code,
platform_code as p_code, 
campaign_type as ct_code,
forecast_gen_date as gen_date, 
EXTRACT(Year FROM forecast_date) as forecast_year, 
EXTRACT( MONTH FROM forecast_date) as forecast_month 
FROM   
  {project_id}.{dataset_id}.{daily_forecast_table}
GROUP BY 
ean_code, country_code, platform_code, campaign_type, forecast_gen_date, forecast_year, forecast_month) as main
ON 
tdata.ean_code = main.e_code AND
tdata.country_code = main.c_code AND 
tdata.platform_code = main.p_code AND
PARSE_DATE('%Y-%m-%d', tdata.`forecast_version`) = main.gen_date AND
EXTRACT( MONTH FROM tdata.`date`) = main.forecast_month) main_rec



WHERE
  o.ean_code = main_rec.ean_code
  AND o.country_code = main_rec.country_code
  AND o.platform_code = main_rec.platform_code
      AND o.campaign_type = main_rec.ct_code
  AND o.forecast_gen_date = PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`) 
  AND o.forecast_date =  main_rec.`date` 

  -- -- Condition to check forecast_date is not of the same month as generation date
  AND   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`)) <=   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', CAST(o.forecast_date  as STRING)));
    """,

    "ForecastAdjustment_VN_CPD_MT_Consensus_W": f"""
--Consensus
UPDATE
   {project_id}.{dataset_id}.{daily_forecast_table} AS o
SET

  o.consensus_forecast = CASE 
  WHEN main_rec.ai_model_forecast is not NULL and main_rec.c_forecast_power is not NULL   THEN CAST(o.ai_model_forecast  * main_rec.c_forecast_power as INT64 )
  ELSE o.consensus_forecast  END,



  o.validated_forecast = CASE 
  WHEN main_rec.ai_model_forecast is not NULL and main_rec.c_forecast_power is not NULL   THEN CAST(o.ai_model_forecast  * main_rec.c_forecast_power as INT64 )
  ELSE o.consensus_forecast  END,
  comments_consensus = main_rec.`comments_consensus`  

FROM
(
  select *,
  CAST(`ai_model_forecast` as INT64)  as a_forecast ,
  CAST(`consensus_forecast` as INT64) as c_forecast,
  CAST(`validated_forecast` as INT64) as v_forecast, 
  SAFE_DIVIDE(CAST(`consensus_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as c_forecast_power,
    SAFE_DIVIDE(CAST(`validated_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as v_forecast_power

  FROM(
  select *

 FROM (SELECT * FROM (SELECT distinct * FROM {project_id}.{temp_dataset_id}.ForecastAdjustment_VN_CPD_MT_Consensus_W) AS t
 LEFT JOIN
 (SELECT `date`,start_of_week,week_no_of_year,year, week_of_year  FROM spmena-unecorn-zn-apac-dv.cds_unecorn_process_zn.dim_date) AS dkey
  ON `forecast_week` = dkey.week_no_of_year and `date` >= PARSE_DATE('%Y-%m-%d',forecast_version) )) AS tdata
  LEFT JOIN
  (SELECT 
ean_code as e_code, 
country_code as c_code,
platform_code as p_code, 
campaign_type as ct_code,
forecast_gen_date as gen_date, 
EXTRACT(Year FROM forecast_date) as forecast_year, 
EXTRACT( ISOWEEK FROM forecast_date) as forecast_week
FROM   
{project_id}.{dataset_id}.{daily_forecast_table}
GROUP BY 
ean_code, country_code, platform_code, campaign_type, forecast_gen_date, forecast_year, forecast_week) as main
ON 
tdata.ean_code = main.e_code AND
tdata.country_code = main.c_code AND 
tdata.platform_code = main.p_code AND
PARSE_DATE('%Y-%m-%d', tdata.`forecast_version`) = main.gen_date AND
EXTRACT( ISOWEEK FROM tdata.`date`) = main.forecast_week) main_rec


WHERE
  o.ean_code = main_rec.ean_code
  AND o.country_code = main_rec.country_code
  AND o.platform_code = main_rec.platform_code
    AND o.campaign_type = main_rec.ct_code 
  AND o.forecast_gen_date = PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`) 
  AND o.forecast_date =  main_rec.`date` 

  -- -- Condition to check forecast_date is not of the same month as generation date
  AND   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`)) <=   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', CAST(o.forecast_date  as STRING)));
    """,

    "ForecastAdjustment_VN_CPD_MT_Validated_W": f"""
--Validated Weekly
UPDATE
   {project_id}.{dataset_id}.{daily_forecast_table} AS o
SET

  -- CASE TO update validated as well if not null
  o.validated_forecast = CASE 
  WHEN main_rec.ai_model_forecast is not NULL and main_rec.v_forecast_power is not NULL   THEN CAST(o.ai_model_forecast  * main_rec.v_forecast_power as INT64 )
  ELSE o.validated_forecast  END,
  comments_validated = main_rec.`comments_validated`  
FROM
(
  select *,
  CAST(`ai_model_forecast` as INT64)  as a_forecast ,
  CAST(`consensus_forecast` as INT64) as c_forecast,
  CAST(`validated_forecast` as INT64) as v_forecast, 
  SAFE_DIVIDE(CAST(`consensus_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as c_forecast_power,
    SAFE_DIVIDE(CAST(`validated_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as v_forecast_power

  FROM(
  select *

 FROM (SELECT * FROM (SELECT  distinct * FROM {project_id}.{temp_dataset_id}.ForecastAdjustment_VN_CPD_MT_Validated_W) AS t
 LEFT JOIN
 (SELECT `date`,start_of_week,week_no_of_year,year, week_of_year  FROM spmena-unecorn-zn-apac-dv.cds_unecorn_process_zn.dim_date) AS dkey
  ON `forecast_week` = dkey.week_no_of_year and `date` >= PARSE_DATE('%Y-%m-%d',forecast_version) )) AS tdata
  LEFT JOIN
  (SELECT 
ean_code as e_code, 
country_code as c_code,
platform_code as p_code, 
campaign_type as ct_code,
forecast_gen_date as gen_date, 
EXTRACT(Year FROM forecast_date) as forecast_year, 
EXTRACT( ISOWEEK FROM forecast_date) as forecast_week
FROM   
{project_id}.{dataset_id}.{daily_forecast_table}
GROUP BY 
ean_code, country_code, platform_code, campaign_type, forecast_gen_date, forecast_year, forecast_week) as main
ON 
tdata.ean_code = main.e_code AND
tdata.country_code = main.c_code AND 
tdata.platform_code = main.p_code AND
PARSE_DATE('%Y-%m-%d', tdata.`forecast_version`) = main.gen_date AND
EXTRACT( ISOWEEK FROM tdata.`date`) = main.forecast_week) main_rec



WHERE
  o.ean_code = main_rec.ean_code
  AND o.country_code = main_rec.country_code
  AND o.platform_code = main_rec.platform_code
  AND o.campaign_type = main_rec.ct_code 
  AND o.forecast_gen_date = PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`) 
  AND o.forecast_date =  main_rec.`date` 

  -- -- Condition to check forecast_date is not of the same month as generation date
  AND   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`)) <=   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', CAST(o.forecast_date  as STRING)));
    """,

    "ForecastAdjustment_VN_CPD_MT_Consensus_M": f""" 
--Consensus
UPDATE
  {project_id}.{dataset_id}.{daily_forecast_table} AS o
SET

  o.consensus_forecast = CASE 
  WHEN main_rec.ai_model_forecast is not NULL and main_rec.c_forecast_power is not NULL   THEN CAST(o.ai_model_forecast  * main_rec.c_forecast_power as INT64 )
  ELSE o.consensus_forecast  END,



  o.validated_forecast = CASE 
  WHEN main_rec.ai_model_forecast is not NULL and main_rec.c_forecast_power is not NULL   THEN CAST(o.ai_model_forecast  * main_rec.c_forecast_power as INT64 )
  ELSE o.consensus_forecast  END,
  comments_consensus = main_rec.`comments_consensus`  

FROM
(
  select *,
  CAST(`ai_model_forecast` as INT64)  as a_forecast ,
  CAST(`consensus_forecast` as INT64) as c_forecast,
  CAST(`validated_forecast` as INT64) as v_forecast, 
  SAFE_DIVIDE(CAST(`consensus_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as c_forecast_power,
    SAFE_DIVIDE(CAST(`validated_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as v_forecast_power

  FROM(
  select *

 FROM (SELECT * FROM (SELECT  distinct * FROM   {project_id}.{temp_dataset_id}.ForecastAdjustment_VN_CPD_MT_Consensus_M) AS t
 LEFT JOIN
 (SELECT `date`,start_of_month, year_month FROM spmena-unecorn-zn-apac-dv.cds_unecorn_process_zn.dim_date) AS dkey
  ON CONCAT(SUBSTR(forecast_month, 1, 3), ' 20', SUBSTR(forecast_month, LENGTH(forecast_month)-1,LENGTH(forecast_month)-2)) = dkey.year_month and `date` >= PARSE_DATE('%Y-%m-%d',forecast_version) )) AS tdata
   LEFT JOIN
  (SELECT 
ean_code as e_code, 
country_code as c_code,
platform_code as p_code, 
campaign_type as ct_code,
forecast_gen_date as gen_date, 
EXTRACT(Year FROM forecast_date) as forecast_year, 
EXTRACT( MONTH FROM forecast_date) as forecast_month
FROM   
  {project_id}.{dataset_id}.{daily_forecast_table}
GROUP BY 
ean_code, country_code, platform_code, campaign_type, forecast_gen_date, forecast_year, forecast_month) as main
ON 
tdata.ean_code = main.e_code AND
tdata.country_code = main.c_code AND 
tdata.platform_code = main.p_code AND
PARSE_DATE('%Y-%m-%d', tdata.`forecast_version`) = main.gen_date AND
EXTRACT( MONTH FROM tdata.`date`) = main.forecast_month) main_rec



WHERE
  o.ean_code = main_rec.ean_code
  AND o.country_code = main_rec.country_code
  AND o.platform_code = main_rec.platform_code
  AND o.campaign_type = main_rec.ct_code 
  AND o.forecast_gen_date = PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`) 
  AND o.forecast_date =  main_rec.`date` 

  -- -- Condition to check forecast_date is not of the same month as generation date
  AND   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`)) <=   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', CAST(o.forecast_date  as STRING)));
    """,

    "ForecastAdjustment_VN_CPD_MT_Validated_M": f""" --Consensus
UPDATE
  {project_id}.{dataset_id}.{daily_forecast_table} AS o
SET

  o.validated_forecast = CASE 
  WHEN main_rec.ai_model_forecast is not NULL and main_rec.v_forecast_power is not NULL   THEN CAST(o.ai_model_forecast  * main_rec.v_forecast_power as INT64 )
  ELSE o.ai_model_forecast  END,
  comments_validated = main_rec.`comments_validated` 




FROM
(
  select *,
  CAST(`ai_model_forecast` as INT64)  as a_forecast ,
  CAST(`consensus_forecast` as INT64) as c_forecast,
  CAST(`validated_forecast` as INT64) as v_forecast, 
  SAFE_DIVIDE(CAST(`consensus_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as c_forecast_power,
    SAFE_DIVIDE(CAST(`validated_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as v_forecast_power

  FROM(
  select *

 FROM (SELECT * FROM (SELECT  distinct * FROM   {project_id}.{temp_dataset_id}.ForecastAdjustment_VN_CPD_MT_Validated_M) AS t
 LEFT JOIN
 (SELECT `date`,start_of_month, year_month FROM spmena-unecorn-zn-apac-dv.cds_unecorn_process_zn.dim_date) AS dkey
  ON CONCAT(SUBSTR(forecast_month, 1, 3), ' 20', SUBSTR(forecast_month, LENGTH(forecast_month)-1,LENGTH(forecast_month)-2)) = dkey.year_month and `date` >= PARSE_DATE('%Y-%m-%d',forecast_version) )) AS tdata
   LEFT JOIN
  (SELECT 
ean_code as e_code, 
country_code as c_code,
platform_code as p_code, 
campaign_type as ct_code,
forecast_gen_date as gen_date, 
EXTRACT(Year FROM forecast_date) as forecast_year, 
EXTRACT( MONTH FROM forecast_date) as forecast_month
FROM   
  {project_id}.{dataset_id}.{daily_forecast_table}
GROUP BY 
ean_code, country_code, platform_code, campaign_type, forecast_gen_date, forecast_year, forecast_month) as main
ON 
tdata.ean_code = main.e_code AND
tdata.country_code = main.c_code AND 
tdata.platform_code = main.p_code AND
PARSE_DATE('%Y-%m-%d', tdata.`forecast_version`) = main.gen_date AND
EXTRACT( MONTH FROM tdata.`date`) = main.forecast_month) main_rec



WHERE
  o.ean_code = main_rec.ean_code
  AND o.country_code = main_rec.country_code
  AND o.platform_code = main_rec.platform_code
    AND o.campaign_type = main_rec.ct_code 
  AND o.forecast_gen_date = PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`) 
  AND o.forecast_date =  main_rec.`date` 

  -- -- Condition to check forecast_date is not of the same month as generation date
  AND   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`)) <=   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', CAST(o.forecast_date  as STRING)));

    """,

    "ForecastAdjustment_VN_CPD_FH_Consensus_M": f""" 


-- CONSENSUS ST LT TABLE >  SOURCE ForecastAdjustment_VN_CPD_FH_Consensus_M
-- TARGET >   {project_id}.{dataset_id}.{daily_forecast_table} 

UPDATE
  {project_id}.{dataset_id}.{daily_forecast_table} AS o
SET

  o.consensus_forecast = CASE 
  WHEN main_rec.ai_model_forecast is not NULL and main_rec.c_forecast_power is not NULL   THEN CAST(o.ai_model_forecast  * main_rec.c_forecast_power as INT64 )
  ELSE o.consensus_forecast  END,



  o.validated_forecast = CASE 
  WHEN main_rec.ai_model_forecast is not NULL and main_rec.c_forecast_power is not NULL   THEN CAST(o.ai_model_forecast  * main_rec.c_forecast_power as INT64 )
  ELSE o.consensus_forecast  END,
  comments_consensus = main_rec.`comments_consensus`  

FROM
(
  select *,
  CAST(`ai_model_forecast` as INT64)  as a_forecast ,
  CAST(`consensus_forecast` as INT64) as c_forecast,
  CAST(`validated_forecast` as INT64) as v_forecast, 
  SAFE_DIVIDE(CAST(`consensus_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as c_forecast_power,
    SAFE_DIVIDE(CAST(`validated_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as v_forecast_power

  FROM(
  select *

 FROM (SELECT * FROM (SELECT  distinct * FROM   {project_id}.{temp_dataset_id}.ForecastAdjustment_VN_CPD_FH_Consensus_M) AS t
 LEFT JOIN
 (SELECT `date`,start_of_month, year_month FROM spmena-unecorn-zn-apac-dv.cds_unecorn_process_zn.dim_date) AS dkey
  ON CONCAT(SUBSTR(forecast_month, 1, 3), ' 20', SUBSTR(forecast_month, LENGTH(forecast_month)-1,LENGTH(forecast_month)-2)) = dkey.year_month and `date` >= PARSE_DATE('%Y-%m-%d',forecast_version) )) AS tdata
    LEFT JOIN
  (SELECT 
ean_code as e_code, 
country_code as c_code,
platform_code as p_code, 
campaign_type as ct_code,
forecast_gen_date as gen_date, 
EXTRACT(Year FROM forecast_date) as forecast_year, 
EXTRACT( MONTH FROM forecast_date) as forecast_month
FROM   
  {project_id}.{dataset_id}.{daily_forecast_table}
GROUP BY 
ean_code, country_code, platform_code, campaign_type, forecast_gen_date, forecast_year, forecast_month) as main
ON 
tdata.ean_code = main.e_code AND
tdata.country_code = main.c_code AND 
tdata.platform_code = main.p_code AND
PARSE_DATE('%Y-%m-%d', tdata.`forecast_version`) = main.gen_date AND
EXTRACT( MONTH FROM tdata.`date`) = main.forecast_month) main_rec



WHERE
  o.ean_code = main_rec.ean_code
  AND o.country_code = main_rec.country_code
  AND o.platform_code = main_rec.platform_code
    AND o.campaign_type = main_rec.ct_code
  AND o.forecast_gen_date = PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`) 
  AND o.forecast_date =  main_rec.`date` 

  -- -- Condition to check forecast_date is not of the same month as generation date
  AND   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`)) <=   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', CAST(o.forecast_date  as STRING)));





-- CONSENSUS FH LT TABLE > SOURCE ForecastAdjustment_VN_CPD_FH_Consensus_M
-- TARGET >   {project_id}.{dataset_id}.{monthly_forecast_table}


UPDATE
  {project_id}.{dataset_id}.{monthly_forecast_table} AS o
SET

  o.consensus_forecast = CASE 
  WHEN main_rec.ai_model_forecast is not NULL and main_rec.c_forecast_power is not NULL   THEN CAST(o.ai_model_forecast  * main_rec.c_forecast_power as INT64 )
  ELSE o.consensus_forecast  END,



  o.validated_forecast = CASE 
  WHEN main_rec.ai_model_forecast is not NULL and main_rec.c_forecast_power is not NULL   THEN CAST(o.ai_model_forecast  * main_rec.c_forecast_power as INT64 )
  ELSE o.consensus_forecast  END,
  comments_consensus = main_rec.`comments_consensus`  

FROM
(
  select *,
  CAST(`ai_model_forecast` as INT64)  as a_forecast ,
  CAST(`consensus_forecast` as INT64) as c_forecast,
  CAST(`validated_forecast` as INT64) as v_forecast, 
  SAFE_DIVIDE(CAST(`consensus_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as c_forecast_power,
    SAFE_DIVIDE(CAST(`validated_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as v_forecast_power

  FROM(
  select *

 FROM (SELECT * FROM (SELECT  distinct * FROM   {project_id}.{temp_dataset_id}.ForecastAdjustment_VN_CPD_FH_Consensus_M) AS t
 LEFT JOIN
 (SELECT `date`,start_of_month, year_month FROM spmena-unecorn-zn-apac-dv.cds_unecorn_process_zn.dim_date) AS dkey
  ON CONCAT(SUBSTR(forecast_month, 1, 3), ' 20', SUBSTR(forecast_month, LENGTH(forecast_month)-1,LENGTH(forecast_month)-2)) = dkey.year_month and `date` >= PARSE_DATE('%Y-%m-%d',forecast_version) )) AS tdata
  LEFT JOIN
  (SELECT 
ean_code as e_code, 
country_code as c_code,
platform_code as p_code, 
campaign_type as ct_code,
forecast_gen_date as gen_date, 
EXTRACT(Year FROM forecast_date) as forecast_year, 
EXTRACT( MONTH FROM forecast_date) as forecast_month
FROM   
  {project_id}.{dataset_id}.{monthly_forecast_table}
GROUP BY 
ean_code, country_code, platform_code, campaign_type, forecast_gen_date, forecast_year, forecast_month) as main
ON 
tdata.ean_code = main.e_code AND
tdata.country_code = main.c_code AND 
tdata.platform_code = main.p_code AND
PARSE_DATE('%Y-%m-%d', tdata.`forecast_version`) = main.gen_date AND
EXTRACT( MONTH FROM tdata.`date`) = main.forecast_month) main_rec


WHERE
  o.ean_code = main_rec.ean_code
  AND o.country_code = main_rec.country_code
  AND o.platform_code = main_rec.platform_code
      AND o.campaign_type = main_rec.ct_code
  AND o.forecast_gen_date = PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`) 
  AND o.forecast_date =  main_rec.`date` 

  -- -- Condition to check forecast_date is not of the same month as generation date
  AND   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`)) <=   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', CAST(o.forecast_date  as STRING)));


    """,

    "ForecastAdjustment_VN_CPD_FH_Validated_M": f""" 
-- CONSENSUS FH LT TABLE > SOURCE ForecastAdjustment_VN_CPD_FH_Validated_M
-- TARGET >   {project_id}.{dataset_id}.{daily_forecast_table}

UPDATE
  {project_id}.{dataset_id}.{daily_forecast_table} AS o
SET

  o.validated_forecast = CASE 
  WHEN main_rec.ai_model_forecast is not NULL and main_rec.v_forecast_power is not NULL   THEN CAST(o.ai_model_forecast  * main_rec.v_forecast_power as INT64 )
  ELSE o.ai_model_forecast  END,
  comments_validated = main_rec.`comments_validated`  

FROM
(
  select *,
  CAST(`ai_model_forecast` as INT64)  as a_forecast ,
  CAST(`consensus_forecast` as INT64) as c_forecast,
  CAST(`validated_forecast` as INT64) as v_forecast, 
  SAFE_DIVIDE(CAST(`consensus_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as c_forecast_power,
    SAFE_DIVIDE(CAST(`validated_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as v_forecast_power

  FROM(
  select *

 FROM (SELECT * FROM (SELECT  distinct * FROM   {project_id}.{temp_dataset_id}.ForecastAdjustment_VN_CPD_FH_Validated_M) AS t
 LEFT JOIN
 (SELECT `date`,start_of_month, year_month FROM spmena-unecorn-zn-apac-dv.cds_unecorn_process_zn.dim_date) AS dkey
  ON CONCAT(SUBSTR(forecast_month, 1, 3), ' 20', SUBSTR(forecast_month, LENGTH(forecast_month)-1,LENGTH(forecast_month)-2)) = dkey.year_month and `date` >= PARSE_DATE('%Y-%m-%d',forecast_version) )) AS tdata
    LEFT JOIN
  (SELECT 
ean_code as e_code, 
country_code as c_code,
platform_code as p_code, 
campaign_type as ct_code,
forecast_gen_date as gen_date, 
EXTRACT(Year FROM forecast_date) as forecast_year, 
EXTRACT( MONTH FROM forecast_date) as forecast_month
FROM   
  {project_id}.{dataset_id}.{daily_forecast_table}
GROUP BY 
ean_code, country_code, platform_code, campaign_type, forecast_gen_date, forecast_year, forecast_month) as main
ON 
tdata.ean_code = main.e_code AND
tdata.country_code = main.c_code AND 
tdata.platform_code = main.p_code AND
PARSE_DATE('%Y-%m-%d', tdata.`forecast_version`) = main.gen_date AND
EXTRACT( MONTH FROM tdata.`date`) = main.forecast_month) main_rec



WHERE
  o.ean_code = main_rec.ean_code
  AND o.country_code = main_rec.country_code
  AND o.platform_code = main_rec.platform_code
    AND o.campaign_type = main_rec.ct_code
  AND o.forecast_gen_date = PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`) 
  AND o.forecast_date =  main_rec.`date` 

  -- -- Condition to check forecast_date is not of the same month as generation date
  AND   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`)) <=   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', CAST(o.forecast_date  as STRING)));




-- CONSENSUS FH LT TABLE > SOURCE ForecastAdjustment_VN_CPD_FH_Validated_M
-- TARGET >   {project_id}.{dataset_id}.{monthly_forecast_table}



UPDATE
  {project_id}.{dataset_id}.{monthly_forecast_table} AS o
SET

  o.validated_forecast = CASE 
  WHEN main_rec.ai_model_forecast is not NULL and main_rec.v_forecast_power is not NULL   THEN CAST(o.ai_model_forecast  * main_rec.v_forecast_power as INT64 )
  ELSE o.ai_model_forecast  END,
  comments_validated = main_rec.`comments_validated`  


FROM
(
  select *,
  CAST(`ai_model_forecast` as INT64)  as a_forecast ,
  CAST(`consensus_forecast` as INT64) as c_forecast,
  CAST(`validated_forecast` as INT64) as v_forecast, 
  SAFE_DIVIDE(CAST(`consensus_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as c_forecast_power,
    SAFE_DIVIDE(CAST(`validated_forecast` as INT64), CAST(`ai_model_forecast` as INT64) ) as v_forecast_power

  FROM(
  select *

 FROM (SELECT * FROM (SELECT  distinct * FROM   {project_id}.{temp_dataset_id}.ForecastAdjustment_VN_CPD_FH_Validated_M) AS t
 LEFT JOIN
 (SELECT `date`,start_of_month, year_month FROM spmena-unecorn-zn-apac-dv.cds_unecorn_process_zn.dim_date) AS dkey
  ON CONCAT(SUBSTR(forecast_month, 1, 3), ' 20', SUBSTR(forecast_month, LENGTH(forecast_month)-1,LENGTH(forecast_month)-2)) = dkey.year_month and `date` >= PARSE_DATE('%Y-%m-%d',forecast_version) )) AS tdata
   LEFT JOIN
  (SELECT 
ean_code as e_code, 
country_code as c_code,
platform_code as p_code, 
campaign_type as ct_code,
forecast_gen_date as gen_date, 
EXTRACT(Year FROM forecast_date) as forecast_year, 
EXTRACT( MONTH FROM forecast_date) as forecast_month 
FROM   
  {project_id}.{dataset_id}.{monthly_forecast_table}
GROUP BY 
ean_code, country_code, platform_code, campaign_type, forecast_gen_date, forecast_year, forecast_month) as main
ON 
tdata.ean_code = main.e_code AND
tdata.country_code = main.c_code AND 
tdata.platform_code = main.p_code AND
PARSE_DATE('%Y-%m-%d', tdata.`forecast_version`) = main.gen_date AND
EXTRACT( MONTH FROM tdata.`date`) = main.forecast_month) main_rec



WHERE
  o.ean_code = main_rec.ean_code
  AND o.country_code = main_rec.country_code
  AND o.platform_code = main_rec.platform_code
    AND o.campaign_type = main_rec.ct_code
  AND o.forecast_gen_date = PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`) 
  AND o.forecast_date =  main_rec.`date` 

  -- -- Condition to check forecast_date is not of the same month as generation date
  AND   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', main_rec.`forecast_version`)) <=   FORMAT_TIMESTAMP('%Y%m', PARSE_DATE('%Y-%m-%d', CAST(o.forecast_date  as STRING)));
    """,
}
