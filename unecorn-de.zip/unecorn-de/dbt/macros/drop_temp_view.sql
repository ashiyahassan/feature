{% macro drop_temp_view(dataset_name, view_name) %}

{% set project_id = target.project %}
-- {% set dataset_id = dataset_name %}
{{ print("Running some_macro: "~ dataset_name ~", "~ view_name) }}
{% if execute %}

  EXECUTE IMMEDIATE 'DROP VIEW IF EXISTS `{{ project_id }}.{{ dataset_name }}.{{ view_name }}`'

{% endif %}

{% endmacro %}
