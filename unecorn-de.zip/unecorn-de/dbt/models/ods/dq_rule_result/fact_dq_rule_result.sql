-- depends_on: {{ ref('daily_sellout_d2c_v3') }}
-- depends_on: {{ ref('master_data_forecast_file_data') }}

-- depends_on: {{ ref('rsp') }}
-- depends_on: {{ ref('media_plan') }}
-- depends_on: {{ ref('future_price') }}

-- depends_on: {{ ref('promo_discount') }}
-- depends_on: {{ ref('unecorn_ean_details') }}
-- depends_on: {{ ref('dim_rsp_valorization') }}

-- depends_on: {{ ref('sellout_d2c_v3') }}
-- depends_on: {{ ref('promo_voucher') }}
-- depends_on: {{ ref('fact_daily_forecast_explosion') }}
-- depends_on: {{ ref('stock_snapshot_daily') }}

-- depends_on: {{ ref('fact_sellout_daily_explosion') }}
-- depends_on: {{ ref('vw_product_classification_abc') }}
-- depends_on: {{ ref('vw_product_classification_xyz') }}
-- depends_on: {{ ref('dim_fm_ean_sku_mapping') }}

-- depends_on: {{ ref('dim_master_data_forecast') }}
-- depends_on: {{ ref('dim_product_platform') }}
-- depends_on: {{ ref('dim_product') }}

-- depends_on: {{ ref('product_hierarchy') }}

-- depends_on: {{ ref('int_campaign_calendar') }}
-- depends_on: {{ ref('int_promo_plan') }}

-- depends_on: {{ ref('bom_explosion_factor') }}
-- depends_on: {{ ref('vw_dq_sellout_data') }}
-- depends_on: {{ ref('platform_product') }}

{{ config(materialized='incremental') }}

SELECT  * FROM ( {{dq_rule_completeness() }} )
UNION ALL
SELECT  * FROM ( {{dq_rule_validity() }} )
UNION ALL
SELECT  * FROM ( {{dq_rule_timeliness() }} )
UNION ALL
SELECT  * FROM ( {{dq_rule_uniqueness() }} )
UNION ALL
SELECT  * FROM ( {{dq_rule_consistency() }} )